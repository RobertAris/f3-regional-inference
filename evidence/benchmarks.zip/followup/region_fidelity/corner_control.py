"""On the observed failure packets, replace the preview gains with dense gains."""
import argparse
import json
from pathlib import Path

import numpy as np
import torch

from followup.fresh import gather, packet
from followup.precision.measure import host, CubicPreview, SIZES, SOURCES, import_file, sha, predict
from query_f3.depth_context import prefix, Context
from query_f3.engine import trace
from query_f3.quadrature.batch import batched_suffix
from .measure import HERE, BRANCH, errors


@torch.inference_mode()
def run(root):
    archive=root/'archive/binary-occupancy'
    upstream=archive/'fast-feature-fields'
    weights=archive/'project/checkpoints'
    loaders=BRANCH/'query_f3/inference/loaders'
    ck=weights/'f3/patchff_fullcardaym3ed_small_20ms.pth'
    enc=import_file(loaders/'published_f3.py').load_published_f3(upstream,ck,'mps').eval()
    head=import_file(loaders/'released_flow.py').load_head(upstream,weights/'flow/last.pth',weights/'flow/flow_config.yaml',ck,'mps').eval()
    enc.return_logits,enc.return_feat=False,True
    records=HERE/'results.json'
    out=[]
    for row in json.loads(records.read_text())['records']:
        bad=[i for i,(a,b) in enumerate(zip(row['region_flow_px'],row['region_field_relative'],strict=True))
             if a>.5 or b>.015]
        if not bad:
            continue
        d,n=row['domain'],row['name']
        old=json.loads((HERE.parent/'precision_policy/records'/d/(n+'.json')).read_text())
        size=SIZES[d]
        enc.w,enc.h=size
        enc.frame_sizes=[*size,20]
        source=root/'datasets'/SOURCES[d]/(n+'.npz')
        assert sha(source)==old['packet']
        with np.load(source) as z:
            events=z['w'+str(old['window'])]
        rects=[tuple(r) for r in old['regions']]
        grid=packet(events,size).grid(enc)
        state,initial=prefix(enc,grid,(5,))[5]
        dense_field,dense_flow,gains=trace(enc,head,grid)
        matched=host(gather(dense_field,rects),gather(dense_flow,rects))
        full= predict(events,size,rects,enc,enc,head,{},'released-gather',torch.float32)
        exact=host(*batched_suffix(enc,head,Context(5,state,torch.stack(gains)),rects))
        preview=CubicPreview().context(enc,head,state,initial,2,True,True)
        approx=host(*batched_suffix(enc,head,preview,rects))
        res={}
        for key,reference,candidate in [('preview_vs_released',full,approx),('exact_vs_released',full,exact),
                                        ('exact_vs_matched',matched,exact),('preview_vs_exact',exact,approx)]:
            flow,field,_,_=errors(reference,candidate)
            res[key]=dict(flow_px=flow.tolist(),field_relative=field.tolist())
        out.append(dict(domain=d,name=n,failure_indices=bad,errors=res))
    return dict(selection_sha256=sha(records),script_sha256=sha(Path(__file__)),records=out)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('local_root',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    args.output.write_text(json.dumps(run(args.local_root),indent=2,allow_nan=False)+'\n')
