# Does averaging over a request hide individual errors?

We reran the fixed FP32 bicubic policy against the released FP32 dense gather on the same 43 earliest packets. Each packet has ten regions. A region passes at flow-component RMS of at most 0.50 px and feature RMS of at most 1.5% relative to its own dense feature signal. These are limits on disagreement with F3. The packet-level comparison also reports latency by camera panel. [Individual-region protocol](protocol.md) · [All measurements](results.json) · [Original comparison](../precision_policy/README.md)

| Camera panel | Individual regions within both limits | Packets with all ten within limits |
|---|---:|---:|
| Prophesee EVIMO2v2 | 140/140 | 14/14 |
| Samsung EVIMO2v2 | 158/160 | 14/16 |
| M3ED | 60/60 | 6/6 |
| E-MOTION | 68/70 | 6/7 |

Across the 430 region occurrences, the largest relative feature RMS was 0.215%. Four flow discrepancies exceeded 0.50 px. The upper-left region reached 2.0885 px on Samsung scene_04_04_000000 and 1.0138 px on Samsung scene_05_03_000000. The two designated corners on E-MOTION square_traj_2 reached 0.9778 and 0.7646 px. Six region slots per resolution have fixed coordinates, and regions can overlap. These counts describe this workload.

As a diagnostic after locating the failures, we substituted the full-frame normalization gains for the five estimated gain vectors. We kept the native prefix, region coordinates and cropped suffix fixed and used all ten regions on each of the three packets containing a failure. The resulting cropped flow and feature outputs agreed exactly with the matched full-frame implementation on these regions. Maximum flow-component RMS against the released dense gather was 0.00000490 px. The dense-gain control requires full-frame computation and provides no speed measurement. [Control implementation](corner_control.py) · [All four comparisons](corner-control.json)

From the branch root, run the first command to replay the saved records with standard Python. To repeat inference on MPS, provide the same data layout, weights and dependencies as the precision study. The second command writes a new receipt outside the source tree. The third selects its three packets using the committed individual-region measurements. [Data and weights](../REPRODUCE.md)

```sh
python -m followup.region_fidelity.replay
python -m followup.region_fidelity.measure /path/to/local/data-root /tmp/region-results.json
python -m followup.region_fidelity.corner_control /path/to/local/data-root /tmp/region-control.json
```
