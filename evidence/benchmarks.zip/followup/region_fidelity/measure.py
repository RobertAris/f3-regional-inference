"""Compare each of the ten regions with its own dense reference on previously scored packets."""
import argparse
import json
from pathlib import Path

import numpy as np
import torch

from followup.precision.measure import CubicPreview, SIZES, SOURCES, import_file, predict, regions, sha

HERE = Path(__file__).resolve().parent
BRANCH = HERE.parents[1]


def errors(reference, candidate):
    delta = np.square(candidate.astype(np.float64) - reference)
    signal = np.square(reference[:, :32].astype(np.float64))
    def rms(error, axes):
        return np.sqrt(error.mean(axis=axes))
    per = (1, 2, 3)
    if not np.all(signal.mean(axis=per) > 0):
        raise ValueError("A dense region has zero feature signal")
    return (rms(delta[:, 32:], per), rms(delta[:, :32], per) / rms(signal, per),
            float(rms(delta[:, 32:], None)), float(rms(delta[:, :32], None) / rms(signal, None)))


@torch.inference_mode()
def run(root):
    data = root / 'datasets'
    arch = root / 'archive/binary-occupancy'
    weights = arch / 'project/checkpoints'
    upstream = arch / 'fast-feature-fields'
    loaders = BRANCH / 'query_f3/inference/loaders'
    ck = weights / 'f3/patchff_fullcardaym3ed_small_20ms.pth'
    encoder = import_file(loaders/'published_f3.py').load_published_f3(upstream, ck, 'mps').eval()
    head = import_file(loaders/'released_flow.py').load_head(upstream, weights/'flow/last.pth', weights/'flow/flow_config.yaml', ck, 'mps').eval()
    encoder.return_logits, encoder.return_feat = False, True
    results = []
    for domain, expected in [('evimo', 14), ('samsung', 16), ('m3ed', 6), ('emotion', 7)]:
        records = sorted((HERE.parent/'precision_policy/records'/domain).glob('*.json'))
        assert len(records) == expected
        size = SIZES[domain]
        encoder.w, encoder.h = size
        encoder.frame_sizes = [*size, 20]
        for rec in records:
            old = json.loads(rec.read_text())
            path = data/SOURCES[domain]/(rec.stem+'.npz')
            assert old['packet'] == sha(path)
            with np.load(path) as z:
                events = z['w'+str(old['window'])]
            rects = regions(events, size)
            assert np.array_equal(rects, old['regions'])
            def call(mode):
                return predict(events, size, rects, encoder, encoder, head, {'bicubic': CubicPreview()}, mode, torch.float32)
            dense, test = call('released-gather'), call('bicubic')
            assert dense.shape == test.shape == (10,34,32,32) and np.isfinite(dense).all() and np.isfinite(test).all()
            flow, field, packet_flow, packet_field = errors(dense, test)
            results.append(dict(domain=domain,name=rec.stem,source_sha256=sha(rec),rectangles=old['regions'],
                                region_flow_px=flow.tolist(),region_field_relative=field.tolist(),
                                packet_flow_px=packet_flow,packet_field_relative=packet_field,
                                original_flow_px=old['arms']['32/bicubic']['flow'],
                                original_field_relative=old['arms']['32/bicubic']['field']))
    return dict(protocol_sha256=sha(HERE/'protocol.md'),script_sha256=sha(Path(__file__)),torch=str(torch.__version__),records=results)


if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('local_root',type=Path)
    p.add_argument('output',type=Path)
    args=p.parse_args()
    report=run(args.local_root)
    args.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
