"""Replay individual region counts and the gain-substitution control from the receipts."""
import hashlib
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def main():
    path = HERE / "results.json"
    primary = read(path)
    assert primary["script_sha256"] == digest(HERE / "measure.py")
    assert primary["protocol_sha256"] == digest(HERE / "protocol.md")
    sources = HERE.parent / "precision_policy" / "records"
    rows = primary["records"]
    keys = {(r["domain"], r["name"]) for r in rows}
    assert len(rows) == len(keys) == 43
    assert keys == {(p.parent.name, p.stem) for p in sources.glob("*/*.json")}
    failures = {}
    per_packet = []
    n_ok = 0
    for row in rows:
        key = row["domain"], row["name"]
        original = sources / key[0] / (key[1] + ".json")
        assert digest(original) == row["source_sha256"]
        record = read(original)
        assert row["rectangles"] == record["regions"] and len(row["rectangles"]) == 10
        flow, field = row["region_flow_px"], row["region_field_relative"]
        assert len(flow) == len(field) == 10 and all(math.isfinite(v) and v >= 0 for v in flow + field)
        assert math.isclose(math.sqrt(sum(v*v for v in flow)/10), row["packet_flow_px"], rel_tol=1e-12)
        reference = record["arms"]["32/bicubic"]
        assert abs(row["packet_flow_px"] - reference["flow"]) < .000012
        assert abs(row["packet_field_relative"] - reference["field"]) < .000001
        bad = [i for i,(a,b) in enumerate(zip(flow,field)) if a > .50 or b > .015]
        n_ok += 10 - len(bad)
        if bad:
            failures[key] = bad
        per_packet.append(row["packet_flow_px"] <= .50 and row["packet_field_relative"] <= .015)
    control = read(HERE / "corner-control.json")
    assert control["selection_sha256"] == digest(path)
    assert control["script_sha256"] == digest(HERE / "corner_control.py")
    selected = {(r["domain"],r["name"]):r["failure_indices"] for r in control["records"]}
    assert len(selected) == len(control["records"]) and selected == failures
    maxima = []
    for row in control["records"]:
        err = row["errors"]
        assert max(err["exact_vs_matched"]["flow_px"]) == 0
        assert max(err["exact_vs_matched"]["field_relative"]) == 0
        maxima.extend(err["exact_vs_released"]["flow_px"])
        assert all(err["preview_vs_released"]["flow_px"][i] > .5 for i in row["failure_indices"])
    print(f"Packet averages {sum(per_packet)}/43; all regions {43-len(failures)}/43; regions {n_ok}/430")
    print(f"Maximum flow RMS with dense gains on selected packets: {max(maxima):.9g} px")
    assert (sum(per_packet),43-len(failures),n_ok) == (42,40,426)
    assert max(maxima) < .000005


if __name__ == "__main__":
    main()
