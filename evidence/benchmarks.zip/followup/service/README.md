# Real motion under a deadline

The primary comparison covers 16 short contiguous Samsung EVIMO SfM streams from four physical setups (765 timestamps, 732 labelled frames, 4,364,373 valid pixel--times). Faster service yielded fresher answers. At the query timestamp, with no added wait, the faster dense reference averaged 70.857 px endpoint error, the bilinear regional path 69.658 px, bicubic 69.783 px and zero motion 75.840 px. The bilinear regional method reduced endpoint error by 1.20 px, or 1.69% relative to dense as a ratio of four setup means, or 2.38% as the mean of four paired relative reductions (bootstrap interval 0.48–4.27%). Conditional P90 answer age fell from 182.28 to 146.22 ms. Source clips reuse the same setups as the Samsung replication. Service was measured on one Mac and replayed causally. [Protocol](protocol.md) · [Released-scatter comparison](official_protocol.md) · [Six-arm results](official.json)

Each archived NPZ holds the two unrounded duration measurements for each method and packet, true target timestamps, ROI rectangles, valid label counts, zero-flow error sums and one matrix of summed endpoint errors per method. Its target row and source column allow a reader to score any causal source choice on the fixed observations. The archive includes SHA-256 hashes of the contributing raw measurement and label files, plus per-file hashes in the manifest. The first four-arm experiment remains available. With the fastest of its two dense implementations the primary relative reduction was 0.84%. Released full/gathered dense paths were faster in all 16 captures when included. [Initial comparison](captures.json) · [Portable calculation](replay.py)

## Replay and regeneration

From the branch root with Python 3.11+ and NumPy, run:

```sh
python followup/service/replay.py
```

To generate new physical measurements, install the dependencies and obtain the released checkpoints as described in the branch inference guide. The source downloader writes the original Samsung training captures under `datasets/f3-next-samsung`. The optical-flow generator is pinned and checked against its recorded SHA-256. Set the four paths below to your local checkout and checkpoint files. Each timing command runs on the Mac with the model resident. Absolute times vary with the machine and its software.

```sh
export F3_CHECKOUT=/path/to/fast-feature-fields
export F3_ENCODER_WEIGHTS=/path/to/patchff_fullcardaym3ed_small_20ms.pth
export F3_HEAD_WEIGHTS=/path/to/last.pth
export F3_HEAD_CONFIG=/path/to/flow_config.yaml
python -m followup.sources.samsung
for part in 0 1 2 3; do python -m followup.service.data "$part"; done
for f in datasets/f3-service/*.json; do
  name=$(basename "$f" .json)
  python -m followup.service.trace "$name"
  python -m followup.service.official "$name"
done
python -m followup.service.result
python -m followup.service.final
python followup/service/pack.py datasets/f3-service runs/f3-service/official runs/repacked-official
```

Use a fresh output directory when regenerating measurements. Repeating a run with existing receipts checks their identity.
