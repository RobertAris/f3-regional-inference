"""Add the publisher's event scatter as a dense service path with interleaved controls."""
import json
import sys
from pathlib import Path

import numpy as np
import torch
from followup.sources.samsung import BASE
from .runtime import configure,packet
from query_f3.binding import digest
from .runtime import models,reference,timed
from .runtime import host,gathered,predict
from query_f3.scale.preview import Preview
from query_f3.scale.prior import CubicPreview
from .data import OUT as LABELS,events
from .trace import OUT

MODES=('released-full','released-gather','dense-gather','dense-full','regional','bicubic')

@torch.inference_mode()
def run(name):
    gt=LABELS/(name+'.npz');meta=json.loads(gt.with_suffix('.json').read_text());assert digest(gt)==meta['sha']
    with np.load(gt) as z:ts=z['ts'];coords=z['coords'];rs=[tuple(map(int,r)) for r in z['regions']]
    folder=BASE/'train'/name;root=OUT/'official';root.mkdir(exist_ok=True,parents=True)
    f=root/(name+'.npz');rec=f.with_suffix('.json')
    lock=dict(official=digest(__file__),protocol=digest(Path(__file__).with_name('official_protocol.md')),labels=meta['sha'])
    if rec.exists():
        s=json.loads(rec.read_text());assert s['sha']==digest(f) and s['lock']==lock;return
    point={}
    for i,(x,y,w,h) in enumerate(rs):
        for dx in range(w):
            for dy in range(h):point.setdefault((x+dx,y+dy),(i,dx,dy))
    a,b,c=np.asarray([point[tuple(q)] for q in coords]).T
    t=np.load(folder/'dataset_events_t.npy',mmap_mode='r');xy=np.load(folder/'dataset_events_xy.npy',mmap_mode='r')
    enc,head=models();configure(enc,(640,480));bil=Preview();cubic=CubicPreview()
    rng=np.random.default_rng(9328);out={k:[] for k in MODES};times={k:[] for k in MODES}
    from .runtime import native_encoder
    for j,s in enumerate(ts):
        def call(k):
            p=packet(events(t,xy,s),(640,480))
            if k.startswith('released'):
                full=reference(enc,head,p)
                return host(full if k.endswith('full') else gathered(full,rs))
            if k=='dense-full':
                field=native_encoder(enc,p);return host((field,head(field.transpose(2,3)).transpose(2,3)))
            if k=='dense-gather':return host(predict(enc,head,p,rs,'dense-matched'))
            return host((bil if k=='regional' else cubic).predict(enc,head,p,rs,'5/2/1/1'))
        if not j:
            for k in rng.permutation(MODES):timed(lambda:call(k))
        for k in MODES:times[k].append([])
        for rep in range(2):
            for k in rng.permutation(MODES):
                u,ms=timed(lambda:call(k));times[k][-1].append(ms)
                if not rep:
                    v=u[0,32:].transpose(1,2,0)[coords[:,0],coords[:,1]] if k.endswith('full') else u[:,32:].transpose(0,2,3,1)[a,b,c]
                    assert np.isfinite(v).all();out[k].append(v.copy())
        for k in ('released-full','released-gather','dense-full'):
            d=out[k][-1]-out['dense-gather'][-1]
            if (d.astype('d')**2).mean()>.025**2:
                np.savez_compressed(root/f'{name}-{j}-{k}-parity.npz',candidate=out[k][-1],matched=out['dense-gather'][-1])
                raise ValueError(('dense path parity',name,j,k,float((d*d).mean()**.5)))
    tmp=f.with_suffix('.pending.npz');np.savez_compressed(tmp,ts=ts,coords=coords,**{k:np.stack(v) for k,v in out.items()},**{k+'_ms':v for k,v in times.items()});tmp.replace(f)
    rec.write_text(json.dumps(dict(sha=digest(f),name=name,group=meta['group'],lock=lock))+'\n')
    print(name,len(ts),flush=True)

if __name__=='__main__':run(sys.argv[1])
