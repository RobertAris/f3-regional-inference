"""Standalone released and matched dense adapters for the Mac timing experiment."""
import os
import time
from pathlib import Path
import torch
from followup.fresh import gather,import_file,packet
from query_f3.binding import ROOT


def models():
    a=ROOT/'query_f3/inference/loaders'
    repo,w,head,config=[Path(os.environ[k]) for k in ('F3_CHECKOUT','F3_ENCODER_WEIGHTS','F3_HEAD_WEIGHTS','F3_HEAD_CONFIG')]
    enc=import_file(a/'published_f3.py').load_published_f3(repo,w,'mps').eval().requires_grad_(False)
    reader=import_file(a/'released_flow.py').load_head(repo,head,config,w,'mps').eval().requires_grad_(False)
    enc.return_logits=False;enc.return_feat=True
    return enc,reader


def configure(enc,size):
    enc.w,enc.h=size;enc.frame_sizes=[*size,20]


def native_encoder(enc,p):
    field=p.grid(enc)
    for stem,stage in zip(enc.downsample_layers,enc.stages,strict=True):field=stage(stem(field))
    return field


def reference(enc,head,p):
    if len(p.ev):
        t=torch.from_numpy(p.ev).to('mps')
        field=enc(t,torch.tensor([len(t)],device='mps')).permute(0,3,1,2)
    else:field=native_encoder(enc,p)
    return field,head(field.transpose(2,3)).transpose(2,3)


def gathered(pair,regions):
    return tuple(gather(v,regions) for v in pair)


def predict(enc,head,p,regions,mode):
    assert mode=='dense-matched'
    f=native_encoder(enc,p)
    return gathered((f,head(f.transpose(2,3)).transpose(2,3)),regions)


def host(pair):
    return torch.cat(pair,dim=1).contiguous().float().cpu().numpy()


def timed(call):
    torch.mps.synchronize();start=time.perf_counter();v=call();torch.mps.synchronize()
    return v,(time.perf_counter()-start)*1000
