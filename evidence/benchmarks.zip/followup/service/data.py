"""Freeze contiguous intervals and generate native displacement only at the fixed query locations."""
import importlib.util
import json
import sys
import tempfile
from pathlib import Path

import numpy as np
from numpy.lib import npyio,_npyio_impl
from followup.sources.samsung import BASE
from followup.fresh import regions
from query_f3.binding import digest,ROOT
from query_f3.external import sources

OUT=ROOT/'datasets/f3-service'


def events(t,xy,ts):
    cut=int(round((ts+.010)*1e6))
    a,b=np.searchsorted(t,[(cut-20001)/1e6,(cut+1)/1e6])
    a0=np.rint(t[a:b].astype('d')*1e6).astype('i8')-cut
    use=(a0>=-20000)&(a0<0)
    return np.column_stack((a0[use],xy[a:b][use])).astype('i4')


def run(part):
    source=json.loads((BASE/'sources.json').read_text())
    if not hasattr(npyio,'zipfile_factory'):npyio.zipfile_factory=_npyio_impl.zipfile_factory
    sources.source();script=sources.BASE/'vendor/evimo_flow.py';assert digest(script)==sources.FLOW_SHA
    sp=importlib.util.spec_from_file_location('evimo_flow_service',script);official=importlib.util.module_from_spec(sp);sp.loader.exec_module(official)
    OUT.mkdir(exist_ok=True,parents=True)
    for i,(name,group) in enumerate(source['roster'].items()):
        if i%4!=part:continue
        f=BASE/'train'/name;out=OUT/(name+'.npz');record=out.with_suffix('.json')
        if record.exists():
            m=json.loads(record.read_text());assert m['sha']==digest(out) and m['code']==digest(__file__);continue
        info=f/'dataset_info.npz';meta=np.load(info,allow_pickle=True)['meta'].item()
        t=np.load(f/'dataset_events_t.npy',mmap_mode='r');xy=np.load(f/'dataset_events_xy.npy',mmap_mode='r')
        lo=float(t[0])+.010;hi=min(float(t[-1])-.010,max(v['ts'] for v in meta['full_trajectory'] if 'cam' in v)-.100)
        first=meta['frames'][0]['id']
        with np.load(f/'dataset_depth.npz') as dep,np.load(f/'dataset_mask.npz') as masks,tempfile.TemporaryDirectory() as tmp:
            dk,mk=set(dep.files),set(masks.files);eligible=[]
            for row in meta['frames']:
                k=str(row['id']-first).zfill(10)
                if 'cam' in row and lo<=row['cam']['ts']<=hi and 'depth_'+k in dk and 'mask_'+k in mk:
                    eligible.append((float(row['cam']['ts']),k))
            eligible.sort();ts=np.array([s for s,_ in eligible])
            runs=np.split(np.arange(len(ts)),np.flatnonzero(np.diff(ts)>.026)+1);ids=max(runs,key=len)
            length=min(48,len(ids));assert length>=12,(name,length);start=(len(ids)-length)//2;ids=ids[start:start+length]
            rows=[eligible[q] for q in ids];dz={'depth_'+k:dep['depth_'+k] for _,k in rows}
            temp=Path(tmp);(temp/info.name).symlink_to(info);np.savez(temp/'dataset_depth.npz',**dz)
            np.savez(temp/'dataset_mask.npz',**{'mask_'+k:masks['mask_'+k] for _,k in rows})
            official.convert(str(temp),.100,quiet=True,showflow=False,format='evimo2v2')
            rectangles=regions(events(t,xy,rows[0][0]),(640,480));ct=set();coords=[]
            for x,y,w,h in rectangles:
                for ax in range(x,x+w):
                    for ay in range(y,y+h):
                        if (ax,ay) not in ct:coords.append((ax,ay));ct.add((ax,ay))
            xx,yy=np.asarray(coords).T
            with np.load(temp/'dataset_flow.npz') as gt:
                assert np.allclose(gt['t'],[s for s,_ in rows],atol=1e-7,rtol=0)
                assert np.max(np.abs(gt['t_end']-gt['t']-.1))<1e-8
                uv=np.stack([gt['flow_'+k][yy,xx] for _,k in rows])
                valid=np.stack([dz['depth_'+k][yy,xx]>0 for _,k in rows])&np.isfinite(uv).all(-1)
        temp=out.with_suffix('.pending.npz');np.savez_compressed(temp,ts=np.asarray([s for s,_ in rows]),regions=rectangles,coords=np.asarray(coords,dtype='i2'),target=uv,valid=valid);temp.replace(out)
        record.write_text(json.dumps(dict(name=name,group=group,sha=digest(out),source=digest(BASE/'sources.json'),code=digest(__file__),
            frames=length,eligible=len(eligible),longest=len(max(runs,key=len)),interval=[rows[0][0],rows[-1][0]],empty_labels=int((~valid.any(1)).sum())))+'\n')
        print(name,length,flush=True)

if __name__=='__main__':run(int(sys.argv[1]))
