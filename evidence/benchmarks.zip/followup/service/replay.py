"""Verify the archived latency and error calculations without raw recordings or F3."""
import hashlib
import json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent


def times(ts,durations,period=0):
    # Quantize only the packet clock. Measured call durations retain their native precision.
    ready=ts+.010; free=ready[0]; last=-1; served=[]; finished=[]
    while last+1<len(ts):
        start=max(free,ready[last+1])
        if period:
            start=ready[0]+np.ceil((start-ready[0])/period-1e-10)*period
        last=int(np.searchsorted(ready,start+1e-9,'right'))-1
        free=start+durations[last]/1000
        served.append(last);finished.append(free)
    return np.array(served),np.array(finished)


def replay(tag):
    expected=json.loads((ROOT/(tag+'.json')).read_text())
    files=sorted((ROOT/tag).glob('*.npz'))
    assert len(files)==16
    groups={}; rows={}; covered=0; total=0; labelled=0
    for f in files:
        with np.load(f) as z:
            ts=z['ts'];cnt=z['counts'];covered+=sum(cnt);total+=len(ts);labelled+=np.count_nonzero(cnt)
            idx=np.arange(len(ts));new={}
            clocks={k[:-3]:np.median(z[k],axis=1) for k in z if k.endswith('_ms')}
            best=min((k for k in clocks if k.startswith(('released','dense'))),key=lambda k:np.median(clocks[k]))
            assert best==expected['execution'][f.stem]['fastest']
            entries={k:(k,times(ts,c)) for k,c in clocks.items()}
            entries.update(dense=(best,times(ts,clocks[best])),**{'periodic-dense':(best,times(ts,clocks[best],.1))})
            entries['zero']=(best,None);entries['fresh-dense']=(best,None)
            frozen=expected['captures'][f.stem];g=str(z['group']);groups.setdefault(g,[]).append(f.stem)
            for d in (0,33,67,100):
                new[str(d)]={}
                for kind,(path,trace) in entries.items():
                    if kind=='zero':chosen=np.full(len(ts),-1)
                    elif kind=='fresh-dense':chosen=idx
                    else:
                        inputs,fin=trace
                        done=np.searchsorted(fin,ts+d/1000,'right')-1
                        causal=np.searchsorted(ts[inputs],ts+1e-10,'right')-1
                        loc=np.minimum(done,causal)
                        chosen=np.where(loc<0,-1,inputs[loc])
                    ok=chosen>=0
                    loss=np.where(ok,z[path][idx,chosen],z['zero'])
                    warm=np.rint(ts*1e6)-round(ts[0]*1e6)>=150000
                    metrics=dict(epe=loss.sum()/cnt.sum(),warm_epe=loss[warm].sum()/cnt[warm].sum(),
                                 fallback=np.mean(~ok),covered=int(cnt.sum()),
                                 p90_age=np.quantile((ts[ok]-ts[chosen[ok]])*1000,.9) if ok.any() else None)
                    target=frozen[str(d)][kind]
                    for k,value in metrics.items():
                        if value is None: assert target[k] is None
                        else: np.testing.assert_allclose(value,target[k],atol=1e-7,rtol=0)
                    new[str(d)][kind]=metrics
            rows[f.stem]=new
    source_groups=groups
    for d in ('0','33','67','100'):
        def vector(method,metric):
            return np.array([np.mean([rows[n][d][method][metric] for n in group]) for group in groups])
        groups=[source_groups[k] for k in expected['groups'][d]]
        rng=np.random.default_rng(9327);ix=rng.integers(len(groups),size=(20000,len(groups)))
        for method in ('regional','bicubic','periodic-dense'):
            e1=vector('dense','epe');e2=vector(method,'epe');gain=1-e2/e1
            eff=expected['effects'][d][method]
            np.testing.assert_allclose([gain.mean(),*np.quantile(gain[ix].mean(1),[.025,.975])],eff['gain'],atol=1e-9)
            np.testing.assert_allclose(1-e2.mean()/e1.mean(),eff['ratio_of_group_means'],atol=1e-9)
    print(tag, len(files),'recordings,',total,'frames,',labelled,'with truth,',covered,'observations')
    print('Zero-delay regional percentage reduction and setup bootstrap:',np.round(100*np.array(expected['effects']['0']['regional']['gain']),3))


if __name__=='__main__':
    manifest=json.loads((ROOT/'manifest.json').read_text())
    for p,fingerprint in manifest.items():
        with (ROOT/p).open('rb') as f:
            assert hashlib.file_digest(f,'sha256').hexdigest()==fingerprint,p
    replay('captures');replay('official')
