"""Measure each candidate request on resident data, through host-visible delivery."""
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import torch

from .runtime import configure, packet
from followup.sources.samsung import BASE
from query_f3.binding import digest, ROOT
from .runtime import models, timed
from .runtime import host,native_encoder,predict
from query_f3.scale.preview import Preview
from query_f3.scale.prior import CubicPreview
from .data import OUT as LABELS,events

OUT=ROOT/'runs/f3-service'
MODES=('dense-full','dense-gather','regional','bicubic')


@torch.inference_mode()
def run(name):
    gt=LABELS/(name+'.npz');meta=json.loads(gt.with_suffix('.json').read_text());assert digest(gt)==meta['sha']
    folder=BASE/'train'/name;dest=OUT/'captures';dest.mkdir(exist_ok=True,parents=True)
    data=dest/(name+'.npz');receipt=data.with_suffix('.json')
    lock=dict(trace=digest(__file__),protocol=digest(Path(__file__).with_name('protocol.md')),labels=meta['sha'])
    if receipt.exists():
        saved=json.loads(receipt.read_text());assert saved['lock']==lock and saved['sha']==digest(data);return
    with np.load(gt) as z:ts=z['ts'];coords=z['coords'];rs=[tuple(map(int,r)) for r in z['regions']]
    # Map the packed region tensors back to one copy of each physical pixel.
    by_point={}
    for i,(x,y,w,h) in enumerate(rs):
        for dx in range(w):
            for dy in range(h):by_point.setdefault((x+dx,y+dy),(i,dx,dy))
    group,dx,dy=np.asarray([by_point[tuple(q)] for q in coords]).T
    t=np.load(folder/'dataset_events_t.npy',mmap_mode='r');xy=np.load(folder/'dataset_events_xy.npy',mmap_mode='r')
    enc,head=models();configure(enc,(640,480));bil=Preview();cubic=CubicPreview()
    rng=np.random.default_rng(9327);output={k:[] for k in MODES};ms={k:[] for k in MODES}
    for j,s in enumerate(ts):
        def serve(k):
            p=packet(events(t,xy,s),(640,480))
            if k=='dense-full':
                f=native_encoder(enc,p);m=head(f.transpose(2,3)).transpose(2,3);return host((f,m))
            if k=='dense-gather':return host(predict(enc,head,p,rs,'dense-matched'))
            return host((bil if k=='regional' else cubic).predict(enc,head,p,rs,'5/2/1/1'))
        if not j:
            for k in rng.permutation(MODES):timed(lambda:serve(k))
        for k in MODES:ms[k].append([])
        for rep in range(2):
            for k in rng.permutation(MODES):
                a,duration=timed(lambda:serve(k));ms[k][-1].append(duration)
                if not rep:
                    if k=='dense-full':u=a[0,32:].transpose(1,2,0)[coords[:,0],coords[:,1]]
                    else:u=a[:,32:].transpose(0,2,3,1)[group,dx,dy]
                    assert np.isfinite(u).all();output[k].append(u.copy())
        d=output['dense-full'][-1]-output['dense-gather'][-1]
        if np.mean(d.astype('d')**2)>.025**2:
            np.savez_compressed(dest/f'{name}-{j}-parity.npz',full=output['dense-full'][-1],gather=output['dense-gather'][-1])
            raise ValueError(('dense parity',name,j,float(np.mean(d*d)**.5)))
    tmp=data.with_suffix('.pending.npz')
    np.savez_compressed(tmp,ts=ts,coords=coords,**{k:np.stack(v) for k,v in output.items()},**{k+'_ms':ms[k] for k in MODES});tmp.replace(data)
    receipt.write_text(json.dumps(dict(sha=digest(data),name=name,group=meta['group'],lock=lock,
        mode_order_seed=9327,timestamp_sha=digest(folder/'dataset_events_t.npy'),coord_sha=digest(folder/'dataset_events_xy.npy'))) + '\n')
    print(name,len(ts),{k:round(float(np.median(v)),1) for k,v in ms.items()},flush=True)


if __name__=='__main__':run(sys.argv[1])
