"""Causal replay of a nonpreemptive single-server stream of timestamped requests."""
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

from query_f3.binding import digest
from .data import OUT as LABELS
from .trace import OUT,MODES


def schedule(ts,durations,period=None):
    ready=ts+.010
    server=ready[0]
    i=-1;finished=[];inputs=[]
    while i+1<len(ts):
        if period is None:
            server=max(server,ready[i+1])
        else:
            tick=max(0,int(np.ceil((max(server,ready[i+1])-ready[0])/period-1e-10)))
            server=ready[0]+tick*period
        j=int(np.searchsorted(ready,server+1e-9,'right')-1)
        if j<=i:raise AssertionError('server reused an already-served input')
        i=j;server+=durations[j]/1000;finished.append(server);inputs.append(j)
    return np.asarray(inputs),np.asarray(finished)


def choices(ts,served,finished,deadline):
    completed=np.searchsorted(finished,ts+deadline,side='right')-1
    causal=np.searchsorted(ts[served],ts+1e-10,side='right')-1
    idx=np.minimum(completed,causal);out=np.full(len(ts),-1)
    valid=idx>=0;out[valid]=served[idx[valid]]
    assert np.all(ts[out[valid]]<=ts[valid]+1e-10)
    return out


def run(official=False):
    if official:
        from .official import MODES as modes
    else:
        modes=MODES
    directory='official' if official else 'captures'
    files=sorted((OUT/directory).glob('*.json'));assert len(files)==16
    captures={};groups=defaultdict(list);traces={}
    for f in files:
        doc=json.loads(f.read_text());name=doc['name'];groups[doc['group']].append(name)
        file=f.with_suffix('.npz');assert digest(file)==doc['sha']
        label=LABELS/(name+'.npz');assert digest(label)==doc['lock']['labels']
        with np.load(label) as z:gt=z['target'];valid=z['valid'];ts=z['ts'];coords=z['coords']
        with np.load(file) as z:
            assert np.array_equal(z['coords'],coords) and np.array_equal(z['ts'],ts)
            pred={k:z[k] for k in modes};times={k:np.median(z[k+'_ms'],1) for k in modes}
        fastest=min((k for k in modes if k.startswith(('dense','released'))),key=lambda k:np.median(times[k]))
        maps={k:schedule(ts,times[k]) for k in modes};maps['dense']=maps[fastest];maps['periodic-dense']=schedule(ts,times[fastest],.1)
        pred['dense']=pred['periodic-dense']=pred[fastest]
        captures[name]=res={};traces[name]=dict(fastest=fastest,
            median_ms={k:float(np.median(v)) for k,v in times.items()},served={k:v[0].tolist() for k,v in maps.items()},
            completed={k:v[1].tolist() for k,v in maps.items()},empty_frames=int((~valid.any(1)).sum()))
        for deadline in (0,33,67,100):
            res[str(deadline)]={}
            for k in (*maps,'zero','fresh-dense'):
                if k=='zero':ids=np.full(len(ts),-1)
                elif k=='fresh-dense':ids=np.arange(len(ts))
                else:ids=choices(ts,*maps[k],deadline/1000)
                seen=ids>=0;a=np.zeros_like(gt)
                if seen.any():a[seen]=pred['dense' if k=='fresh-dense' else k][ids[seen]]
                dif=np.linalg.norm(a-gt,axis=-1)
                ages=(ts[seen]-ts[ids[seen]])*1000
                after=valid & ((np.rint(ts*1e6).astype(np.int64)-round(ts[0]*1e6))[:,None]>=150000)
                res[str(deadline)][k]=dict(epe=float(dif[valid].mean(dtype='d')),warm_epe=float(dif[after].mean(dtype='d')),
                    p90_age=float(np.quantile(ages,.9)) if len(ages) else None,fallback=float((~seen).mean()),covered=int(valid.sum()))
    scene={};summary={};effects={}
    for d in ('0','33','67','100'):
        scene[d]={g:{k:{m:float(np.mean([captures[n][d][k][m] for n in ns if captures[n][d][k][m] is not None]))
                          for m in ('epe','warm_epe','p90_age','fallback') if m!='p90_age' or k!='zero'}
                     for k in captures[ns[0]][d]} for g,ns in groups.items()}
        def vec(k,m):return np.array([r[k][m] for r in scene[d].values()])
        ix=np.random.default_rng(9327).integers(len(groups),size=(20000,len(groups)))
        def ci(v):return [float(v.mean()),*np.quantile(v[ix].mean(1),[.025,.975]).tolist()]
        summary[d]={k:{m:float(vec(k,m).mean()) for m in r} for k,r in next(iter(scene[d].values())).items()}
        effects[d]={k:dict(gain=ci(1-vec(k,'epe')/vec('dense','epe')),px=ci(vec('dense','epe')-vec(k,'epe')),
                           p90_age_saved_ms=ci(vec('dense','p90_age')-vec(k,'p90_age'))) for k in ('regional','bicubic','periodic-dense')}
    for d in effects:
        for k in effects[d]:
            effects[d][k]['ratio_of_group_means']=1-summary[d][k]['epe']/summary[d]['dense']['epe']
    primary=effects['0']['regional'];advance=bool(primary['ratio_of_group_means']>=.03 and primary['gain'][0]>=.03 and primary['gain'][1]>0 and primary['p90_age_saved_ms'][0]>0 and summary['0']['dense']['epe']<summary['0']['zero']['epe'])
    result=dict(advance=advance,summary=summary,effects=effects,groups=scene,captures=captures,execution=traces,code=digest(__file__))
    (OUT/('official-summary.json' if official else 'summary.json')).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    for d in summary:print(d,{k:round(v['epe'],3) for k,v in summary[d].items()},effects[d]['regional'])
    print('advance',advance)


if __name__=='__main__':run()
