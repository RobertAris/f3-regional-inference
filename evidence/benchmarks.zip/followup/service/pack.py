"""Export complete per-target/per-source EPE sums and service times for public replay."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np


def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()


def pack(labels,traces,out):
    out.mkdir(parents=True,exist_ok=True)
    for receipt in sorted(traces.glob('*.json')):
        identity=json.loads(receipt.read_text())
        name=identity['name']
        label=labels/(name+'.npz')
        trace=receipt.with_suffix('.npz')
        assert sha(label)==identity['lock']['labels'] and sha(trace)==identity['sha']
        dest=out/(name+'.npz')
        with np.load(label) as target, np.load(trace) as z:
            ts=target['ts']; gt=target['target']; valid=target['valid']
            assert np.array_equal(ts,z['ts']) and np.array_equal(target['coords'],z['coords'])
            a=dict(ts=ts,counts=valid.sum(1),group=identity['group'],trace_sha=sha(trace),
                   label_sha=sha(label),regions=target['regions'])
            a['zero']=np.sum(np.where(valid,np.linalg.norm(gt,axis=-1),0),axis=1,dtype='d')
            for clock in [k for k in z if k.endswith('_ms')]:
                method=clock[:-3];p=z[method];a[clock]=z[clock]
                e=np.empty((len(ts),len(ts)),'d')
                for t,mask in enumerate(valid):
                    delta=p[:,mask,:]-gt[t,mask,:]
                    e[t]=np.linalg.norm(delta,axis=-1).sum(1,dtype='d')
                a[method]=e
            np.savez_compressed(dest,**a)
        print(name,flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    for name in ('labels','traces','out'):ap.add_argument(name,type=Path)
    p=ap.parse_args();pack(p.labels,p.traces,p.out)
