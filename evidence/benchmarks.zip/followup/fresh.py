"""Reproduce the frozen native-camera comparison from per-capture packet NPZs."""
import argparse
import hashlib
import json
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch

from query_f3.engine import Packet, halo
from query_f3.inference.demo import import_file
from query_f3.scale.preview import Preview
from query_f3.scale.prior import CubicPreview

MODES = ('dense', 'dense-matched', 'crop16', 'crop32', 'crop64', 'plain', 'bicubic', 'thumbnail6', 'regional')
CONFIG = {'regional':'5/2/1/1', 'bicubic':'5/2/1/1', 'plain':'5/2/0/0', 'thumbnail6':'6/2/1/1'}
SIZES = {'samsung':(640,480), 'emotion':(1280,720)}
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def packet(e,size):
    xy=e[:,1:].astype('i8');age=(-1-e[:,0].astype('i8'))//1000
    return Packet(xy,np.column_stack((xy/np.asarray(size),age/20)).astype('f'),size,None)
def regions(e,size):
    w,h=size;rng=np.random.default_rng(8242)
    pos=[(0,0),(w-32,h-32),(w//2-16,h//2-16)]
    pos.extend(rng.integers((0,0),(w-31,h-31)) for _ in range(3))
    if len(e):
        pos.extend(np.clip(e[i,1:]-16,(0,0),(w-32,h-32)) for i in rng.integers(len(e),size=4))
    else:pos.extend(rng.integers((0,0),(w-31,h-31)) for _ in range(4))
    return [(*map(int,q),32,32) for q in pos]
def gather(x,rs):
    return torch.cat([x[:,:,a:a+w,b:b+h] for a,b,w,h in rs])
def service(enc,head,preview,cubic,e,size,rs,mode):
    p=packet(e,size)
    if mode in CONFIG:
        a,b=(cubic if mode=='bicubic' else preview).predict(enc,head,p,rs,CONFIG[mode])
    else:
        if mode=='dense' and len(e):
            t=torch.from_numpy(p.ev).to(next(enc.parameters()))
            field=enc(t,torch.tensor([len(t)],device=t.device)).permute(0,3,1,2)
        else:
            field=p.grid(enc)
            for s,l in zip(enc.downsample_layers,enc.stages,strict=True):field=l(s(field))
        a=gather(field,rs)
        if mode.startswith('crop'):
            groups=defaultdict(list);result=[None]*len(rs)
            for i,r in enumerate(rs):
                x,y,w,h=halo(r,size,int(mode[4:]));groups[w,h].append((i,x,y))
            for (w,h),items in groups.items():
                crops=torch.cat([field[:,:,x:x+w,y:y+h] for _,x,y in items])
                v=head(crops.transpose(2,3)).transpose(2,3)
                for k,(i,x,y) in enumerate(items):
                    u,t,r,s=rs[i];result[i]=v[k:k+1,:,u-x:u-x+r,t-y:t-y+s]
            b=torch.cat(result)
        else:b=gather(head(field.transpose(2,3)).transpose(2,3),rs)
    return torch.cat((a,b),dim=1).contiguous().float().cpu().numpy()
def truth(z,j,domain,rs,size):
    w,h=size
    if domain=='samsung':
        uv=np.zeros((h,w,2),'f');valid=np.zeros((h,w),bool)
        x,y=z[f'xy{j}'].T;valid[y,x]=True;uv[y,x]=z[f'gt{j}']
        assert int(z[f'dt{j}'])==100000
    else:uv=z[f'velocity{j}'];valid=z[f'valid{j}'].copy()
    chunks=[]
    for i,(x,y,r,s) in enumerate(rs):
        mask=valid[y:y+s,x:x+r];dy,dx=np.where(mask)
        chunks.append((i,dx,dy,uv[y+dy,x+dx].astype('f')));mask[:]=False
    return chunks
def labelled(out,chunks,scale):
    total=np.zeros(3)
    for i,dx,dy,gt in chunks:
        v=out[i,32:][:,dx,dy].T*scale
        total += (len(gt),np.linalg.norm(v-gt,axis=1).sum(dtype='d'),np.linalg.norm(gt,axis=1).sum(dtype='d'))
    return total.tolist()
@torch.inference_mode()
def run(opt):
    size=SIZES[opt.domain];adapters=Path(__file__).resolve().parents[1]/'query_f3/inference/loaders'
    enc=import_file(adapters/'published_f3.py').load_published_f3(opt.f3_repo,opt.encoder_weights,'mps').eval()
    head=import_file(adapters/'released_flow.py').load_head(opt.f3_repo,opt.head_weights,opt.head_config,opt.encoder_weights,'mps').eval()
    enc.return_logits=False;enc.return_feat=True;enc.w,enc.h=size;enc.frame_sizes=[*size,20]
    preview,cubic=Preview(),CubicPreview();source=Path(__file__).resolve()
    opt.out.mkdir(exist_ok=True,parents=True)
    for name in opt.names:
        f=opt.data/(name+'.npz');meta=opt.data/(name+'.json');record=json.loads(meta.read_text())
        packet_sha=sha(f);assert packet_sha==record.get('packet',record.get('sha'))
        path=opt.out/(name+'.json')
        if path.exists():
            saved=json.loads(path.read_text());assert saved['input']==packet_sha and saved['code']==sha(source);continue
        rng=np.random.default_rng(731+int.from_bytes(hashlib.sha256(name.encode()).digest()[:3],'big'));windows=[]
        with np.load(f) as z:
            for j in range(5):
                e=z[f'w{j}'];rs=regions(e,size);chunks=truth(z,j,opt.domain,rs,size)
                def call(k):return service(enc,head,preview,cubic,e,size,rs,k)
                ref=call('dense');rows={}
                for k in MODES:
                    v=call(k);d=v-ref
                    if not np.isfinite(d).all():raise ValueError((name,j,k,'nonfinite'))
                    fm=np.mean(d[:,:32]**2,dtype='d');vm=np.mean(d[:,32:]**2,dtype='d')
                    if k=='dense-matched' and (fm>.001**2 or vm>.025**2):
                        np.savez_compressed(opt.out/f'{name}-{j}-parity-{time.time_ns()}.npz',reference=ref,matched=v,rectangles=rs,packet=packet_sha)
                        raise ValueError((name,j,'dense parity RMS',fm**.5,vm**.5))
                    rows[k]=dict(field=fm,flow=vm,signal=np.mean(ref[:,:32]**2,dtype='d'),gt=labelled(v,chunks,10 if opt.domain=='emotion' else 1))
                if j==2:
                    for rep in range(6):
                        for k in rng.permutation(MODES):
                            torch.mps.synchronize();t=time.perf_counter();call(k);torch.mps.synchronize();ms=(time.perf_counter()-t)*1000
                            if rep:rows[k].setdefault('ms',[]).append(ms)
                windows.append(dict(j=j,events=len(e),rectangles=rs,rows=rows))
        result=dict(name=name,domain=opt.domain,group=record.get('group',name),input=packet_sha,metadata=sha(meta),code=sha(source),windows=windows)
        tmp=path.with_suffix('.pending');tmp.write_text(json.dumps(result,allow_nan=False)+'\n');tmp.replace(path);print(name,flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('f3-repo','encoder-weights','head-weights','head-config','data','out'):p.add_argument('--'+k,type=Path,required=True)
    p.add_argument('--domain',choices=SIZES,required=True);p.add_argument('names',nargs='+');run(p.parse_args())
