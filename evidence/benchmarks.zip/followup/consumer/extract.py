"""Join frozen feature requests to the publisher's same-frame motion masks."""
import argparse
import json
from pathlib import Path

import cv2
import numpy as np
from followup.consumer.features import SIZE,load_models,observe,addresses
from followup.consumer.poses import trajectories,annotations
from followup.motion_only.panels import sha

HERE=Path(__file__).resolve().parent
BASE=HERE.parents[1]
MODES={'dense':'released-gather','regional':'bilinear'}


def paths(root,name):
    dataset=root/'datasets'
    source=dataset/'query-f3-final-panel/evimo'/(name+'.npz')
    dirs=list((dataset/'query-f3-evimo/train').glob('*/'+name))
    if len(dirs)!=1:raise ValueError(('ambiguous publisher folder',name,dirs))
    return source,dirs[0]


def model_files(root):
    arch=root/'archive/binary-occupancy'
    weights=arch/'project/checkpoints'
    return (arch/'fast-feature-fields',weights/'f3/patchff_fullcardaym3ed_small_20ms.pth',
            weights/'flow/last.pth',weights/'flow/flow_config.yaml')


def run(root,cache,name):
    cv2.setNumThreads(1)
    p,folder=paths(root,name)
    meta=json.loads(p.with_suffix('.json').read_text())
    record=HERE.parent/'records/evimo'/(name+'.json')
    reference=json.loads(record.read_text())
    assert reference['packet']==sha(p)==meta['sha256']
    observed=[r['j'] for r in reference['windows']]
    assert observed==[1,2,3,4]
    ordered=json.loads((HERE/'ordered_regions.json').read_text())[name]
    assert ordered['packet']==sha(p)
    source=meta['source']
    for f in ('dataset_info.npz','dataset_mask.npz','dataset_depth.npz'):
        assert source['source_members'][f]==sha(folder/f)
    modelspec=model_files(root)
    lock={p.name:sha(p),record.name:sha(record),'sidecar':sha(p.with_suffix('.json')),
          **{f.name:sha(f) for f in (HERE/'extract.py',HERE/'poses.py',HERE/'features.py',HERE/'protocol.md',HERE/'ordered_regions.json',
                                     HERE.parent/'precision/measure.py',*modelspec[1:])}}
    out=cache/name;out.mkdir(parents=True,exist_ok=True)
    receipt=out/'index.json'
    if receipt.exists():
        prior=json.loads(receipt.read_text())
        assert prior['lock']==lock and all(sha(out/k)==v for k,v in prior['files'].items())
        return
    files={}
    with np.load(folder/'dataset_info.npz',allow_pickle=True) as src:
        info=src['meta'].item()
    tr=trajectories(info)
    frames={str(f['id']-info['frames'][0]['id']).zfill(10):f for f in info['frames'] if 'cam' in f}
    nets=load_models(*modelspec)
    with np.load(p) as archive,np.load(folder/'dataset_depth.npz') as depths,np.load(folder/'dataset_mask.npz') as masks:
        for row in reference['windows']:
            j=row['j'];receipt_row=source['rows'][j];key=receipt_row['key'];t=receipt_row['left_s']
            assert abs(frames[key]['cam']['ts']-t)<1e-6 and abs(receipt_row['cut_us']-round((t+.01)*1e6))<=1
            e=archive[f'w{j}'];a,xy,first,active=observe(e,nets,MODES['dense'])
            b,other,first2,support=observe(e,nets,MODES['regional'])
            old_xy,old_first=addresses(ordered['rows'][str(j)])
            assert np.array_equal(xy,old_xy) and np.array_equal(first,old_first)
            assert np.array_equal(xy,other) and np.array_equal(active,support) and np.array_equal(first,first2)
            assert np.isfinite(a).all() and np.isfinite(b).all() and np.array_equal(a[:,:33],b[:,:33])
            # Verify the union against the original flow-annotation reader's independently archived count.
            truth=archive[f'xy{j}'];xy=xy[first]
            original_keys=truth[:,1].astype('i8')*SIZE[0]+truth[:,0]
            assert np.isin(original_keys,xy[:,1]*SIZE[0]+xy[:,0]).sum()==row['rows']['dense']['gt'][0]
            y,tracked=annotations(depths['depth_'+key],masks['mask_'+key],tr,t,xy)
            dest=out/f'{j}.npz';tmp=dest.with_suffix('.pending.npz')
            np.savez_compressed(tmp,dense=a[first],regional=b[first],y=y,tracked=tracked,
                                active=active[first],xy=xy,pose_time=t)
            tmp.replace(dest);files[dest.name]=sha(dest)
    receipt.write_text(json.dumps(dict(name=name,group=source['scene'],lock=lock,files=files),indent=2)+'\n')
    print(name, 'four pose-joined original regions',flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('root',type=Path)
    parser.add_argument('cache',type=Path)
    parser.add_argument('name')
    args=parser.parse_args()
    run(args.root,args.cache,args.name)
