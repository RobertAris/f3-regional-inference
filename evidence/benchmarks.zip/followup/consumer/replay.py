"""Recalculate coverage, per-setup mask utility, and time from compact recordings."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
BASES=('raw','raw-fb','dense/flow','regional/flow','dense/raw-flows','regional/raw-flows')


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def evaluate(include_timing):
    originals={p.stem:json.loads(p.read_text()) for p in (HERE.parent/'records/evimo').glob('*.json')}
    inputs=sorted((HERE/'records').glob('*.json'))
    assert len(inputs)==14 and {p.stem for p in inputs}==set(originals)
    records={}
    for p in inputs:
        r=json.loads(p.read_text());name=r['name'];group=r['group']
        assert p.stem==name and originals[name]['group']==group and r['scoring']==sha(HERE/'study.py')
        assert r['training']==sorted(n for n,v in originals.items() if v['group']!=group)
        assert len(r['covers'])==4
        y=sum(k['active_positive'] for k in r['covers'])
        v=sum(k['active_valid'] for k in r['covers'])
        for m in r['methods'].values():
            t=m['event']
            assert t['tp']+t['fn']==y and t['tp']+t['fp']+t['fn']+t['tn']==v
            assert 0<=t['hard_rejected']<=t['hard_sites']<=t['tn']+t['fp']
        if include_timing:
            time_path=HERE/'timing'/(name+'.json');tim=json.loads(time_path.read_text())
            assert tim['record']==sha(p) and tim['code']==sha(HERE/'timing.py') and tim['packet']==originals[name]['packet']
            assert tim['features']==sha(HERE/'features.py') and tim['group']==group
            assert all(len(a)==5 and min(a)>0 for a in tim['ms'].values())
            r['latency']={a:float(np.median(seq)) for a,seq in tim['ms'].items()}
        records[name]=r
    groups=sorted(set(r['group'] for r in records.values()))
    assert len(groups)==5
    arms=(*BASES,'dense/full','regional/full')
    by={}
    def mean(values):return float(np.mean(values)) if values else None
    for g in groups:
        group=[r for r in records.values() if r['group']==g]
        by[g]={}
        for a in arms:
            items=[r['methods'][a]['event'] for r in group]
            pos=[q for q in items if q['tp']+q['fn']];neg=[q for q in items if not q['tp']+q['fn'] and q['tn']+q['fp']]
            hard=[q for q in items if q['hard_sites']]
            by[g][a]=dict(iou=mean([q['tp']/(q['tp']+q['fn']+q['fp']) for q in pos]),
                          ap=mean([q['ap'] for q in pos]),hard_fpr=mean([q['hard_rejected']/q['hard_sites'] for q in hard]),
                          negative_only_fpr=mean([q['fp']/(q['fp']+q['tn']) for q in neg]),
                          pos_captures=len(pos),negative_captures=len(neg),hard_captures=len(hard),
                          event_positives=sum(q['tp']+q['fn'] for q in items),hard_sites=sum(q['hard_sites'] for q in items))
            if include_timing:by[g][a]['ms']=mean([r['latency'][a] for r in group])
    supported=[g for g in groups if by[g][arms[-1]]['iou'] is not None]
    hard_supported=[g for g in groups if by[g][arms[-1]]['hard_fpr'] is not None]
    means={a:{m:mean([by[g][a][m] for g in groups if by[g][a][m] is not None]) for m in ('iou','ap','hard_fpr','negative_only_fpr')} for a in arms}
    best=max(BASES,key=lambda a:means[a]['iou']) if supported else None
    effects={};candidate='regional/full'
    if supported:
        ix=np.random.default_rng(731).integers(len(supported),size=(20000,len(supported)))
        for a in (*BASES,'dense/full'):
            delta=np.array([by[g][candidate]['iou']-by[g][a]['iou'] for g in supported])
            effects[a]={'delta':float(np.mean(delta)),'interval':np.quantile(delta[ix].mean(1),[.025,.975]).tolist()}
    gain=effects[best]['delta'] if best else None
    static=None if not hard_supported or not best else means[candidate]['hard_fpr']-means[best]['hard_fpr']
    dense=effects.get('dense/full',{}).get('delta')
    gates=dict(training=all(min(r['training_counts']['sampled'])>0 for r in records.values()),support=len(supported)>=3,feature_utility=gain is not None and gain>=.03,
               static_guard=static is not None and static<=.02,dense_fidelity=dense is not None and dense>=-.01)
    result=dict(source={n:sha(HERE/'records'/(n+'.json')) for n in records},by_group=by,means=means,
                groups=supported,static_groups=hard_supported,controls=effects,best_deletion=best,
                delta_static=static,gates=gates,passed=all(gates.values()),
                observations={k:sum(b[k] for r in records.values() for b in r['covers']) for k in next(iter(records.values()))['covers'][0]})
    if include_timing:
        result['times']={a:mean([by[g][a]['ms'] for g in groups]) for a in arms}
        result['timing_source']={n:sha(HERE/'timing'/(n+'.json')) for n in records}
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--save',action='store_true');args=p.parse_args()
    v=evaluate(True);path=HERE/'summary.json'
    if args.save:path.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
    else:assert json.loads(path.read_text())==v
    print('event-supported sites:',v['observations']['active_valid'],'true moving:',v['observations']['active_positive'])
    print('decision',v['gates'],'best deletion',v['best_deletion'])
    for a,m in v['means'].items():print(a,m['iou'],m['ap'],v['times'][a])
