"""Download two version-pinned EVIMO2v2 archives and retain official training runs."""
import hashlib,json,shutil,tarfile
from pathlib import Path
import requests
from query_f3.binding import ROOT,digest
BASE=ROOT/'datasets/query-f3-evimo'
PINS={'imo':(1819418535,'216ce41565a2ee4e1849067764fe2a2e-19'),'imo_ll':(195008573,'d2f48cf099bed6c8e03fe0a588ffd303')}
CODE='8897c6d9aa18384f9746b89b565d09cc7d8a059f'
FLOW_SHA='f734e306dc19751ab22d2b1170be845278cd8a3210956bbc3bf8e4c23de76b45'
def get(kind):
    length,etag=PINS[kind];url=f'https://obj.umiacs.umd.edu/evimo2v2npz/npz_left_camera_{kind}.tar.gz'
    path=BASE/(kind+'.tar.gz');pending=path.with_suffix('.partial')
    if not path.exists():
        for i in range(4):
            start=pending.stat().st_size if pending.exists() else 0
            if start==length:break
            headers={'If-Match':f'"{etag}"','Accept-Encoding':'identity','Range':f'bytes={start}-{length-1}'}
            try:
                with requests.get(url,headers=headers,stream=True,timeout=(15,60)) as response:
                    response.raise_for_status()
                    if response.status_code!=206 or response.headers['Content-Range']!=f'bytes {start}-{length-1}/{length}' or response.headers['ETag'].strip('"')!=etag:raise ValueError('source identity mismatch')
                    with pending.open('ab') as out:
                        for buf in response.iter_content(2**20):out.write(buf)
            except requests.RequestException:
                if i==3:raise
        if pending.stat().st_size!=length:raise ValueError('short source')
        pending.replace(path)
    if path.stat().st_size!=length:raise ValueError(kind)
    files=[]
    with tarfile.open(path,'r|gz') as tar:
        for obj in tar:
            p=Path(obj.name)
            if not obj.isfile() or '..' in p.parts or 'train' not in p.parts:continue
            if p.name not in {'dataset_info.npz','dataset_depth.npz','dataset_mask.npz','dataset_events_t.npy','dataset_events_xy.npy'}:continue
            loc=BASE/'train'/kind/p.parent.name/p.name;loc.parent.mkdir(exist_ok=True,parents=True)
            if not loc.is_file() or loc.stat().st_size!=obj.size:
                tmp=loc.with_suffix('.part')
                with tmp.open('wb') as out:shutil.copyfileobj(tar.extractfile(obj),out)
                tmp.replace(loc)
            files.append(dict(member=obj.name,name=str(loc.relative_to(BASE)),sha=digest(loc)))
    if not files:raise ValueError('no matching members')
    (BASE/(kind+'-members.json')).write_text(json.dumps(dict(url=url,etag=etag,size=length,sha256=digest(path),files=files),indent=2)+'\n')
    print('verified',kind,len(files),flush=True)
def source():
    vendor=BASE/'vendor';vendor.mkdir(exist_ok=True,parents=True);p=vendor/'evimo_flow.py'
    if not p.exists():
        r=requests.get(f'https://raw.githubusercontent.com/better-flow/evimo/{CODE}/tools/evimo_flow.py',timeout=30);r.raise_for_status();p.write_bytes(r.content)
    if digest(p)!=FLOW_SHA:raise ValueError('publisher generator changed')
