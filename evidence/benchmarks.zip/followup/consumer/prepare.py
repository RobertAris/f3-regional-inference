"""Reconstruct the original Prophesee flow/packet inputs for the regional paper."""
import argparse
import importlib.util
import json
import tempfile
from pathlib import Path
import numpy as np
from query_f3.binding import digest
from . import publisher as sources
from .extract import HERE

def evimo_roster():
    available={}
    for light in sources.PINS:
        manifest=json.loads((sources.BASE/(light+'-members.json')).read_text())
        for file in manifest['files']:
            if not file['name'].endswith('/dataset_info.npz'):continue
            folder=(sources.BASE/file['name']).parent;family=folder.name.rsplit('_',1)[0]
            key=(light,family)
            if key not in available or available[key].name>folder.name:available[key]=folder
    return sorted(available.values())

def save(name,domain,items,receipt):
    path=DATA/domain;path.mkdir(parents=True,exist_ok=True);dest=path/(name+'.npz')
    tmp=dest.with_suffix('.pending.npz');np.savez_compressed(tmp,**items);tmp.replace(dest)
    rec=path/(name+'.json');rec.write_text(json.dumps(dict(name=name,domain=domain,source=receipt,sha256=digest(dest),input_design='17ebc47b9eb41aa0d858050ec9df691a8f3352e696361a91ff80eced01753f1e'),indent=2)+'\n')

def complete(n,dom):
    d=DATA/dom/(n+'.json')
    if not d.exists():return False
    doc=json.loads(d.read_text());assert doc['input_design']=='17ebc47b9eb41aa0d858050ec9df691a8f3352e696361a91ff80eced01753f1e' and doc['sha256']==digest(d.with_suffix('.npz'))
    return True

def EVIMO():
    sources.source();sp=importlib.util.spec_from_file_location('evimo_official',sources.BASE/'vendor/evimo_flow.py')
    official=importlib.util.module_from_spec(sp);sp.loader.exec_module(official)
    for folder in evimo_roster():
        n=folder.name
        if complete(n,'evimo'):continue
        info=folder/'dataset_info.npz';meta=np.load(info,allow_pickle=True)['meta'].item()
        t=np.load(folder/'dataset_events_t.npy',mmap_mode='r');xy=np.load(folder/'dataset_events_xy.npy',mmap_mode='r')
        if t.ndim!=1 or xy.shape!=(len(t),2) or np.any(np.diff(t)<0):raise ValueError(n)
        first=meta['frames'][0]['id'];lo=float(t[0])+.010;hi=min(float(t[-1])-.010,max(v['ts'] for v in meta['full_trajectory'] if 'cam' in v)-.100)
        arrays={};rows=[]
        with tempfile.TemporaryDirectory() as td,np.load(folder/'dataset_depth.npz') as d,np.load(folder/'dataset_mask.npz') as mask:
            tmp=Path(td);(tmp/info.name).symlink_to(info);stamps={}
            dkeys=set(d.files);mkeys=set(mask.files)
            for f in meta['frames']:
                key=str(f['id']-first).zfill(10)
                if 'cam' in f and lo<=f['cam']['ts']<=hi and 'depth_'+key in dkeys and 'mask_'+key in mkeys:stamps[key]=float(f['cam']['ts'])
            keys=[list(stamps)[(len(stamps)-1)*q//10] for q in (1,3,5,7,9)]
            if len(set(keys))!=5:raise ValueError((n,'insufficient distinct frames'))
            np.savez(tmp/'dataset_depth.npz',**{'depth_'+k:d['depth_'+k] for k in keys});np.savez(tmp/'dataset_mask.npz',**{'mask_'+k:mask['mask_'+k] for k in keys})
            official.convert(str(tmp),.100,quiet=True,showflow=False,format='evimo2v2')
            with np.load(tmp/'dataset_flow.npz') as z:
                for j,(key,left,right) in enumerate(zip(keys,z['t'],z['t_end'],strict=True)):
                    if abs(left-stamps[key])>1e-6 or abs(right-left-.1)>1e-8:raise ValueError((n,key,left,stamps[key]))
                    cut=round(float(left)*1e6)+10000;start,end=np.searchsorted(t.astype('d'),[(cut-20001)/1e6,(cut+1)/1e6])
                    us=np.rint(np.asarray(t[start:end],dtype='d')*1e6).astype(np.int64);inside=(us>=cut-20000)&(us<cut)
                    ev=np.column_stack((us[inside]-cut,xy[start:end][inside])).astype(np.int32)
                    gt=z['flow_'+key];valid=np.isfinite(gt).all(-1);yy,xx=np.where(valid)
                    if gt.shape!=(480,640,2):raise ValueError(n)
                    arrays.update({f'w{j}':ev,f'xy{j}':np.column_stack((xx,yy)).astype(np.int16),f'gt{j}':gt[yy,xx],f'dt{j}':np.int64(100000)})
                    rows.append(dict(key=key,left_s=left,right_s=right,cut_us=cut,events=len(ev),valid=int(valid.sum())))
        save(n,'evimo',arrays,dict(light=folder.parent.name,scene=n.split('_')[0],source_members={f.name:digest(f) for f in folder.iterdir() if f.is_file()},generator=sources.FLOW_SHA,rows=rows));print(n,flush=True)


def prepare(root,download,verification_only):
    global DATA
    from numpy.lib import npyio, _npyio_impl
    if not hasattr(npyio,'zipfile_factory'):npyio.zipfile_factory=_npyio_impl.zipfile_factory
    sources.BASE=root/'datasets/query-f3-evimo'
    DATA=root/'datasets/query-f3-final-panel'
    if download:
        sources.BASE.mkdir(exist_ok=True,parents=True)
        for kind in sources.PINS:sources.get(kind)
    if not verification_only:EVIMO()
    expected=json.loads((HERE/'ordered_regions.json').read_text())
    for name,rec in expected.items():
        assert complete(name,'evimo') and digest(DATA/'evimo'/(name+'.npz'))==rec['packet']
    print('Fourteen original Prophesee packet identities verified.')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('root',type=Path)
    parser.add_argument('--download',action='store_true');parser.add_argument('--verify-only',action='store_true')
    args=parser.parse_args();prepare(args.root.resolve(),args.download,args.verify_only)
