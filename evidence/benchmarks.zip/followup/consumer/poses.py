"""Pose and depth truth for independent object motion at the query midpoint."""
import numpy as np
from scipy.spatial.transform import Rotation

def transform(pos,quat):
    T=np.eye(4);T[:3,3]=pos;T[:3,:3]=Rotation.from_quat(quat).as_matrix();return T

def interp(times,mat,t,gap=.020001):
    k=int(np.searchsorted(times,t))
    if k<len(times) and abs(times[k]-t)<1e-7:return mat[k]
    if k>0 and abs(times[k-1]-t)<1e-7:return mat[k-1]
    if k==0 or k==len(times) or times[k]-times[k-1]>gap:return None
    f=(t-times[k-1])/(times[k]-times[k-1]);a,b=mat[k-1:k+1]
    v=Rotation.from_matrix(a[:3,:3].T@b[:3,:3]).as_rotvec()
    out=np.eye(4);out[:3,:3]=a[:3,:3]@Rotation.from_rotvec(f*v).as_matrix();out[:3,3]=a[:3,3]+f*(b[:3,3]-a[:3,3]);return out

def status(cam,obj,t):
    poses=[]
    for a in (t-.05,t,t+.05):
        c=interp(*cam,a);o=interp(*obj,a)
        if c is None or o is None:return -1
        poses.append(c@o)
    linear=0;angle=0
    for i,a in enumerate(poses):
        for b in poses[i+1:]:
            linear=max(linear,float(np.linalg.norm(a[:3,3]-b[:3,3])))
            angle=max(angle,float(np.degrees(Rotation.from_matrix(a[:3,:3].T@b[:3,:3]).magnitude())))
    if linear>=.010 or angle>=3:return 1
    if linear<=.002 and angle<=1:return 0
    return -1

def clean(track,t):
    times,mat=track
    # Select endpoints and all interior tracking observations, including brackets.
    a=max(0,np.searchsorted(times,t-.05,side='right')-1);b=min(len(times),np.searchsorted(times,t+.05,side='left')+1)
    times=times[a:b];arr=mat[a:b]
    if len(times)<2 or times[0]>t-.05+1e-7 or times[-1]<t+.05-1e-7:return False
    dt=np.diff(times)
    if np.any(dt<=0) or np.any(dt>.020001):return False
    step=np.linalg.norm(np.diff(arr[:,:3,3],axis=0),axis=1)
    theta=np.rad2deg(Rotation.from_matrix(arr[:-1,:3,:3].transpose(0,2,1)@arr[1:,:3,:3]).magnitude())
    return bool(np.all(step<=9*dt) and np.all(theta<=2250*dt))

def trajectories(metadata):
    parts={}
    for row in metadata['full_trajectory']:
        for key,value in row.items():
            if key=='cam' or key.isdigit():
                p=value['pos']
                mat=transform([p['t'][s] for s in 'xyz'],[p['q'][s] for s in 'xyzw'])
                parts.setdefault(key,[]).append((row['ts'],mat))
    return {k:(np.array([t for t,_ in v]),np.stack([m for _,m in v])) for k,v in parts.items()}

def annotations(depth,mask,tracks,t,xy):
    x,y=xy.T
    ids=mask[y,x].astype('i8')
    ok=np.isfinite(depth[y,x]) & (depth[y,x]>0)
    target=np.full(len(x),-1,'i1')
    if clean(tracks['cam'],t):
        target[ok & (ids==0)]=0
        for key in np.unique(ids[ok & (ids>0)]):
            k=str(key//1000)
            if key%1000==0 and k in tracks and clean(tracks[k],t):
                target[ok & (ids==key)]=status(tracks['cam'],tracks[k],t)
    return target,ids>0
