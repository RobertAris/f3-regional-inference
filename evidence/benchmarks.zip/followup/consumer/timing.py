"""Measure complete packet-to-mask calls using the forest trained outside the setup."""
import argparse
import hashlib
import json
from pathlib import Path
import time
import cv2
import joblib
import numpy as np
import torch
from threadpoolctl import threadpool_limits
from followup.consumer.features import load_models,observe
from followup.consumer.extract import paths,model_files,HERE
from followup.motion_only.panels import sha
from followup.consumer.study import masked

ARMS=('dense/full','regional/full','raw','raw-fb','regional/raw-flows','dense/raw-flows','regional/flow','dense/flow')


def run(root,cache,name):
    cv2.setNumThreads(1)
    record=HERE/'records'/(name+'.json');r=json.loads(record.read_text())
    model_file=cache/'models'/(r['group']+'.joblib');assert sha(model_file)==r['model_sha']
    forests=joblib.load(model_file) # Only the locally trained readout, bound above.
    p,_=paths(root,name);historical=json.loads((HERE.parent/'records/evimo'/(name+'.json')).read_text())
    assert historical['packet']==sha(p)
    j=2
    assert j in [w['j'] for w in historical['windows']]
    with np.load(p) as z:events=z[f'w{j}']
    nets=load_models(*model_files(root))
    def call(tag):
        path,arm=tag.split('/') if '/' in tag else ('dense',tag)
        method='released-gather' if path=='dense' else 'bilinear'
        x,*_=observe(events,nets,method,arm)
        model,t=forests[arm]
        return (model.predict_proba(x)[:,1]>=t).astype('f').reshape(10,32,32)
    rng=np.random.default_rng(int.from_bytes(hashlib.sha256(('service/'+name).encode()).digest()[:8],'big'))
    stamps={k:[] for k in ARMS}
    checks={k:call(k) for k in rng.permutation(ARMS)}
    with np.load(cache/name/f'{j}.npz') as z:
        from followup.fresh import regions
        from followup.consumer.features import addresses,SIZE
        _,first=addresses(regions(events,SIZE))
        for tag,v in checks.items():
            path,arm=tag.split('/') if '/' in tag else ('dense',tag)
            model,t=forests[arm]
            reference=model.predict_proba(masked(z[path],arm))[:,1]>=t
            assert np.array_equal(reference,v.ravel()[first]),(name,tag)
    for _ in range(5):
        for k in rng.permutation(ARMS):
            torch.mps.synchronize();start=time.perf_counter()
            v=call(k);torch.mps.synchronize();ms=1000*(time.perf_counter()-start)
            assert np.array_equal(v,checks[k]) and v.dtype==np.float32
            stamps[k].append(ms)
    dest=HERE/'timing';dest.mkdir(exist_ok=True)
    (dest/(name+'.json')).write_text(json.dumps(dict(name=name,group=r['group'],j=j,record=sha(record),packet=sha(p),
            code=sha(Path(__file__)),features=sha(HERE/'features.py'),ms=stamps),indent=2)+'\n')
    print(name,flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('root',type=Path);parser.add_argument('cache',type=Path);parser.add_argument('name')
    args=parser.parse_args()
    with threadpool_limits(limits=1):run(args.root,args.cache,args.name)
