"""Features available at packet delivery for moving-object rejection."""
from pathlib import Path

import cv2
import numpy as np
import torch

from followup.fresh import regions
from followup.motion_only.panels import flow
from followup.precision.measure import predict
from query_f3.inference.demo import import_file
from query_f3.scale.preview import Preview

SIZE=(640,480)
DIMS=(28,5,5,32)
ARMS={'raw':(0,), 'raw-fb':(0,1), 'flow':(2,), 'raw-flows':(0,1,2), 'full':(0,1,2,3)}


def load_models(repo,encoder_path,head_path,config):
    adapters=Path(__file__).resolve().parents[2]/'query_f3/inference/loaders'
    encoder=import_file(adapters/'published_f3.py').load_published_f3(repo,encoder_path,'mps').eval()
    head=import_file(adapters/'released_flow.py').load_head(repo,head_path,config,encoder_path,'mps').eval()
    encoder.w,encoder.h=SIZE
    encoder.frame_sizes=[*SIZE,20]
    encoder.return_logits=False
    encoder.return_feat=True
    return encoder,head,{'bilinear':Preview()}


def addresses(boxes):
    ux,uy=np.indices((32,32))
    xy=np.concatenate([np.column_stack(((x+ux).ravel(),(y+uy).ravel())) for x,y,w,h in boxes])
    keys=xy[:,1]*SIZE[0]+xy[:,0]
    _,first=np.unique(keys,return_index=True)
    return xy, np.sort(first)


def raw_cues(events,xy):
    w,h=SIZE
    t,x,y=events.T.astype('i8')
    keys=y*w+x
    qx,qy=xy.T
    query=qy*w+qx
    # Count 1-ms bins only on requested pixels; no dependence on records outside the packet.
    wanted,inverse=np.unique(query,return_inverse=True)
    pos=np.searchsorted(wanted,keys)
    take=(pos<len(wanted)) & (wanted[np.minimum(pos,len(wanted)-1)]==keys)
    tb=(-1-t[take])//1000
    counts=np.bincount(tb*len(wanted)+pos[take],minlength=20*len(wanted)).reshape(20,-1).T[inverse]
    image=np.bincount(keys,minlength=w*h).reshape(h,w).astype('f')
    age=np.bincount(keys,weights=(t+20000)/20000,minlength=w*h).reshape(h,w).astype('f')
    cols=[np.log1p(counts)]
    for width in (3,11,27):
        a=cv2.boxFilter(image,-1,(width,width),normalize=False)[qy,qx]
        b=cv2.boxFilter(age,-1,(width,width),normalize=False)[qy,qx]
        cols.extend((np.log1p(a),b/np.maximum(a,1.)))
    cols.extend((qx/w,qy/h))
    return np.column_stack(cols).astype('f'),np.any(counts>0,axis=1)


def flow_cues(patches,xy,first):
    # Input coordinates are [region,x,y,component] throughout.
    flat=patches.reshape(-1,2)
    delta=np.concatenate([(a-cv2.blur(a,(5,5),borderType=cv2.BORDER_REPLICATE)).reshape(-1,2) for a in patches])
    design=np.column_stack((xy/np.array(SIZE),np.ones(len(xy))))
    idx=first[::8]
    xx,yy=design[idx],flat[idx]
    weights=np.ones(len(idx))
    for _ in range(3):
        sq=np.sqrt(weights)[:,None]
        coef=np.linalg.lstsq(xx*sq,yy*sq,rcond=None)[0]
        residual=np.linalg.norm(yy-xx@coef,axis=1)
        weights=1/np.maximum(1.,residual/max(.25,1.4826*np.median(residual)))
    return np.column_stack((flat,np.linalg.norm(flat,axis=1),np.linalg.norm(delta,axis=1),
                            np.linalg.norm(flat-design@coef,axis=1))).astype('f')


@torch.inference_mode()
def observe(e,models,path,arm='full'):
    boxes=regions(e,SIZE)
    xy,first=addresses(boxes)
    needed=ARMS[arm]
    values={}
    if 0 in needed:values[0],active=raw_cues(e,xy)
    else:active=None
    if 1 in needed:
        fb=flow(e,SIZE,8000,boxes).transpose(0,2,1,3)*(100/8)
        values[1]=flow_cues(fb,xy,first)
    if 2 in needed or 3 in needed:
        enc,head,preview=models
        z=predict(e,SIZE,boxes,enc,enc,head,preview,path,torch.float32).transpose(0,2,3,1)
        values[2]=flow_cues(z[:,:,:,32:],xy,first)
        if 3 in needed:values[3]=z[:,:,:,:32].reshape(-1,32)
    full=np.zeros((len(xy),sum(DIMS)),'f')
    start=0
    for i,width in enumerate(DIMS):
        if i in needed:full[:,start:start+width]=values[i]
        start+=width
    return full,xy,first,active
