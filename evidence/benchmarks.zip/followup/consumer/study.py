"""Leave one physical setup out; the same fitted consumer scores both F3 paths."""
import argparse
from collections import Counter,defaultdict
import hashlib
import json
from pathlib import Path

import joblib
import numpy as np
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.metrics import average_precision_score
from threadpoolctl import threadpool_limits
from followup.consumer.features import ARMS,DIMS
from followup.consumer.extract import HERE
from followup.motion_only.panels import sha

BASES=('raw','raw-fb','dense/flow','regional/flow','dense/raw-flows','regional/raw-flows')
THRESHOLDS=np.arange(2,39)/40


class ConstantScore:
    """Defined fallback only for folds whose sampled training targets lack a class."""
    def __init__(self,p):
        self.p=float(p)
    def predict_proba(self,x):
        return np.broadcast_to([1-self.p,self.p],(len(x),2))

def masked(features,arm):
    if arm=='full':return features
    out=np.zeros_like(features)
    start=0
    for i,w in enumerate(DIMS):
        if i in ARMS[arm]:out[:,start:start+w]=features[:,start:start+w]
        start+=w
    return out


def read(cache):
    files=sorted((HERE.parent/'records/evimo').glob('*.json'))
    assert len(files)==14
    seen={}
    for entry in files:
        old=json.loads(entry.read_text());name=old['name'];src=cache/name
        idx=json.loads((src/'index.json').read_text())
        assert idx['name']==entry.stem==name and idx['group']==old['group']
        assert idx['lock'][entry.name]==sha(entry) and set(idx['files'])=={f'{j}.npz' for j in (1,2,3,4)}
        assert all(idx['lock'][k]==sha(HERE/k) for k in ('extract.py','poses.py','features.py','protocol.md'))
        windows=[]
        for f,identity in sorted(idx['files'].items()):
            p=src/f;assert sha(p)==identity
            with np.load(p) as z:
                windows.append({key:z[key] for key in ('dense','regional','active','y','tracked')})
        seen[name]=(idx['group'],windows,sha(src/'index.json'))
    assert len({v[0] for v in seen.values()})==5
    return seen


def training(rows,held):
    blocks=[]
    for name,(group,windows,src) in rows.items():
        if group==held:continue
        for j,z in enumerate(windows):
            ii=np.flatnonzero(z['active'] & (z['y']>=0))
            if not len(ii):continue
            seed=int.from_bytes(hashlib.sha256(f'consumer/{name}/{j}/731'.encode()).digest()[:8],'big')
            idx=np.random.default_rng(seed).choice(ii,min(len(ii),384),replace=False)
            blocks.append((group,name,z['dense'][idx],z['y'][idx]))
    if not blocks:return np.empty((0,sum(DIMS)),'f'),np.empty(0,'i1'),np.empty(0),np.empty(0,dtype='U')
    members=defaultdict(set);win=Counter()
    for g,n,_,_ in blocks:members[g].add(n);win[n]+=1
    weights=np.concatenate([np.full(len(y),1/(len(members[g])*win[n]*len(y))) for g,n,x,y in blocks])
    xx=np.concatenate([x for _,_,x,_ in blocks]);yy=np.concatenate([y for _,_,_,y in blocks])
    groups=np.concatenate([np.repeat(g,len(y)) for g,n,x,y in blocks])
    assert held not in groups
    return xx,yy,weights,groups


def threshold(y,s,groups):
    def quality(t):
        pred=s>=t
        values=[]
        for g in np.unique(groups):
            take=groups==g
            if np.any(y[take]):
                values.append(np.sum((y[take]==1)&pred[take])/np.sum((y[take]==1)|pred[take]))
        return np.mean(values),-abs(t-.5)
    return float(max(THRESHOLDS,key=quality))


def measures(y,score,hard,t):
    assert len(y)==len(score)==len(hard)
    pos=y==1;pred=score>=t
    return dict(tp=int((pos & pred).sum()),fp=int((~pos & pred).sum()),fn=int((pos & ~pred).sum()),
                tn=int((~pos & ~pred).sum()),hard_sites=int(hard.sum()),hard_rejected=int((hard & pred).sum()),
                ap=float(average_precision_score(y,score)) if pos.any() else None)


def run(root,cache):
    rows=read(cache);groups=sorted({v[0] for v in rows.values()})
    out=HERE/'records';out.mkdir(exist_ok=True);models=cache/'models';models.mkdir(exist_ok=True)
    for held in groups:
        xx,yy,w,gg=training(rows,held);forests={}
        available=sum((np.bincount(z['y'][z['active'] & (z['y']>=0)],minlength=2) for g,zs,_ in rows.values() if g!=held for z in zs),start=np.zeros(2,dtype=int))
        sample=np.bincount(yy,minlength=2)
        for arm in ARMS:
            if not np.all(sample):
                forests[arm]=(ConstantScore(float(yy.mean()) if yy.size else 0.),.5)
                continue
            model=ExtraTreesClassifier(n_estimators=32,max_depth=8,min_samples_leaf=12,max_features=1.0,n_jobs=1,random_state=731)
            x=masked(xx,arm)
            model.fit(x,yy,sample_weight=w)
            t=threshold(yy,model.predict_proba(x)[:,1],gg);forests[arm]=(model,t)
        model_file=models/(held+'.joblib')
        joblib.dump(forests,model_file,compress=2)
        for n,(group,windows,source) in rows.items():
            if group!=held:continue
            vals={};cover=[]
            for z in windows:
                y=z['y'];ac=z['active']
                cover.append(dict(unique=len(y),active=int(ac.sum()),valid=int((y>=0).sum()),active_valid=int(((y>=0)&ac).sum()),
                                  positive=int((y==1).sum()),active_positive=int(((y==1)&ac).sum())))
            for tag in (*BASES,'dense/full','regional/full'):
                path,arm=tag.split('/') if '/' in tag else ('dense',tag)
                forest,t=forests[arm];all_scores=[];all_labels=[];all_active=[];all_hard=[]
                for z in windows:
                    s=forest.predict_proba(masked(z[path],arm))[:,1]
                    ok=z['y']>=0
                    all_scores.append(s[ok]);all_labels.append(z['y'][ok]);all_active.append(z['active'][ok])
                    all_hard.append(z['tracked'][ok] & (z['y'][ok]==0))
                scores,y,active,hard=map(np.concatenate,(all_scores,all_labels,all_active,all_hard))
                vals[tag]=dict(event=measures(y[active],scores[active],hard[active],t),
                               all=measures(y,scores,hard,t),threshold=t)
            rec=dict(name=n,group=held,training=sorted(k for k,v in rows.items() if v[0]!=held),source_index=source,
                     training_counts={'available':available.tolist(),'sampled':sample.tolist()},model_sha=sha(model_file),scoring=sha(Path(__file__)),covers=cover,methods=vals)
            (out/(n+'.json')).write_text(json.dumps(rec,indent=2,allow_nan=False)+'\n')
        print('fitted',held,flush=True)
    (cache/'fitted.json').write_text(json.dumps({p.name:sha(p) for p in out.glob('*.json')},indent=2)+'\n')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('root',type=Path);parser.add_argument('cache',type=Path)
    args=parser.parse_args()
    with threadpool_limits(limits=1):run(args.root,args.cache)
