# Rejecting independently moving sites within ten requested regions

A moving-object rejection mask is one possible use for the learned F3 features. This development comparison holds out a whole physical setup at a time. The same fitted reader receives the original or regional F3 responses. Controls remove the 32 learned channels and include a reader using raw counts and local event timing. There are 56 previously evaluated 20 ms packets in 14 recordings. The truth is constructed from publisher motion capture, object IDs and positive depth. Overlapping regions count once per sensor pixel for scoring. Predictions and service timings refer to four packets and one packet per recording, respectively. [Protocol and limits](protocol.md)

From the repository root, run `python followup/consumer/replay.py` with Python and NumPy to reproduce the accuracy and timing estimates from compact per-recording confusion counts, AP records and individual repetitions. Each timing arm also checked its deployed mask against the fitted offline forest at every unique returned pixel. [Recorded measures](records/) · [Timed calls](timing/) · [Aggregate](summary.json)

## Regenerate the measurements

Use Python 3.13, NumPy 2.5.5, OpenCV 5.1.0, SciPy 1.18.1, scikit-learn 1.9.1, PyTorch 2.9.1, joblib, threadpoolctl, h5py, hdf5plugin, tqdm, requests, Matplotlib, and the upstream F3 dependencies. The measurements used the MPS backend and a single CPU thread. The input root below is an absolute directory you choose. Its historical layout places the upstream F3 checkout under `archive/binary-occupancy/fast-feature-fields`, its encoder under `archive/binary-occupancy/project/checkpoints/f3/patchff_fullcardaym3ed_small_20ms.pth`, and the released flow head and configuration under `archive/binary-occupancy/project/checkpoints/flow/{last.pth,flow_config.yaml}`. Directories or symlinks can supply that layout. [Checkpoint and source revision](../../INFERENCE.md)

The optional acquisition command downloads approximately 2.01 GB of pinned Prophesee training archives. It extracts the five named publisher members per take, retrieves the hash-checked upstream flow generator and writes the original flow packets. The raw input archives and F3 weights remain under their authors' terms. Local disk requirements exceed the download size. When the inputs already exist, use `--verify-only`.

```sh
input_root=/absolute/path/to/input-root
cache_dir="$input_root/datasets/f3-regional-consumer"
python -m followup.consumer.prepare "$input_root" --download
python -m followup.consumer.prepare "$input_root" --verify-only
for member in followup/records/evimo/*.json; do
  python -m followup.consumer.extract "$input_root" "$cache_dir" "$(basename "$member" .json)"
done
python -m followup.consumer.study "$input_root" "$cache_dir"
for member in followup/records/evimo/*.json; do
  python -m followup.consumer.timing "$input_root" "$cache_dir" "$(basename "$member" .json)"
done
python followup/consumer/replay.py --save
```

Use a separate checkout for new measurements. The scorer and timing driver write into this checkout's records and timing directories. Never load an untrusted forest serialization; the timing driver checks the locally fitted model hash. Raw exposures, poses, masks, coordinates and model files are not redistributed in this archive.
