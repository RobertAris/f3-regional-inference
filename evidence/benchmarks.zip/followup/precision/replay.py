"""Summarize recorded mixed-precision calls on the four frozen camera panels."""
import hashlib
import json
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
COUNTS={'evimo':14,'samsung':16,'m3ed':6,'emotion':7}
DENSE=('released-gather','released-full','matched')


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def score(rows,key):
    s=rows['results'][key]
    if s['nonfinite']:return None
    ms=np.asarray(s['ms']);assert len(ms)==5 and np.all(ms>0)
    return {'ms':float(np.median(ms)),'epe':None if rows['n']==0 else s['epe_sum']/rows['n'],'field_rel':float(np.sqrt(s['field_mse']/rows['signal'])),
            'flow_px':float(np.sqrt(s['flow_mse']))}


def summarize():
    out={}
    for dom,count in COUNTS.items():
        captures={}
        for f in sorted((HERE/'records'/dom).glob('*.json')):
            r=json.loads(f.read_text());assert r['name']==f.stem and r['domain']==dom and len(r['regions'])==10
            assert r['lock']['generator']==sha(HERE/'measure.py') and r['lock']['protocol']==sha(HERE/'protocol.md')
            assert r['lock']['record']==sha(HERE.parent/'records'/dom/f.name)
            original=json.loads((HERE.parent/'records'/dom/f.name).read_text())
            assert r['lock']['source']==original.get('input',original.get('packet')) and r['group']==original['group']
            middle=original['windows'][len(original['windows'])//2]
            assert r['window']==middle['j']
            if 'rectangles' in middle:assert r['regions']==middle['rectangles'] and r['events']==middle['events']
            gt=middle['rows']['dense']['gt']
            assert r['n']==gt[0] and np.isclose(r['zero_sum'],gt[-1],rtol=1e-6,atol=.001)
            assert np.isclose(r['results']['32/released-gather']['epe_sum'],gt[1],rtol=1e-5,atol=.002)
            assert set(r['results'])=={p+'/'+m for p in ('16','32') for m in (*DENSE,'crop16','crop32','plain','bilinear','bicubic')}
            assert set(r['dtypes'])=={'16','32'}
            assert all(d['grid']=='torch.float32' and d['host']=='float32' and d['activation']==d['output']==d['parameter']==d['norm']=='torch.float'+prec for prec,d in r['dtypes'].items())
            vals={k:score(r,k) for k in r['results']}
            choose=lambda keys:min((v['ms'],k) for k in keys for v in [vals[k]] if v is not None and v['field_rel']<=.015 and v['flow_px']<=.50)
            dense,win=choose([p+'/'+m for p in ('16','32') for m in DENSE])
            ref32,_=choose(['32/'+m for m in DENSE])
            candidate=vals['16/bilinear']
            crops={k:v for k,v in vals.items() if '/crop' in k and v is not None and v['field_rel']<=.015 and v['flow_px']<=.50}
            wide=choose(crops) if crops else (None,None)
            captures[f.stem]=dict(wide_ms=wide[0],wide=wide[1],labeled=r['n'],group=r['group'],competitor=win,dense_ms=dense,dense32_ms=ref32,
                gain=None if candidate is None else 1-candidate['ms']/dense,
                gain32=1-vals['32/bilinear']['ms']/ref32,paths=vals,sha256=sha(f))
        assert len(captures)==count,(dom,len(captures))
        groups=sorted({v['group'] for v in captures.values()});by={}
        for g in groups:
            rows=[r for r in captures.values() if r['group']==g]
            avg=lambda name:float(np.mean([r[name] for r in rows]))
            paths={}
            for k in rows[0]['paths']:
                data=[r['paths'][k] for r in rows];paths[k]=None if any(v is None for v in data) else {name:float(np.mean([v[name] for v in data if v[name] is not None])) if any(v[name] is not None for v in data) else None for name in data[0]}
            by[g]=dict(dense_ms=avg('dense_ms'),dense32_ms=avg('dense32_ms'),gain32=avg('gain32'),paths=paths,
                       gain=None if any(r['gain'] is None for r in rows) else avg('gain'))
        paths={}
        for k in next(iter(by.values()))['paths']:
            data=[by[g]['paths'][k] for g in groups]
            paths[k]=None if any(v is None for v in data) else {name:float(np.mean([v[name] for v in data if v[name] is not None])) if any(v[name] is not None for v in data) else None for name in data[0]}
        ng=len(groups);ix=np.random.default_rng(731).integers(ng,size=(20000,ng))
        gains=[by[g]['gain'] for g in groups]
        ratios=None;ci=None;gain=None;passed=False
        if all(v is not None for v in gains):
            gains=np.asarray(gains);gain=float(gains.mean());ci=np.quantile(gains[ix].mean(1),[.025,.975]).tolist()
            ratios=1-paths['16/bilinear']['ms']/np.mean([by[g]['dense_ms'] for g in groups])
            passed=gain>=.20 and ci[0]>0 and paths['16/bilinear']['field_rel']<=.015 and paths['16/bilinear']['flow_px']<=.50
        out[dom]=dict(passed=bool(passed),n=count,groups=len(groups),gain=gain,interval=ci,ratio_of_means=ratios,
            gain32=float(np.mean([by[g]['gain32'] for g in groups])),dense_ms=float(np.mean([by[g]['dense_ms'] for g in groups])),
            pooled_flow_px=float(np.sqrt(np.mean([np.mean([r['paths']['16/bilinear']['flow_px']**2 for r in captures.values() if r['group']==g]) for g in groups]))) if gain is not None else None,
            crop_qualified=sum(v['wide'] is not None for v in captures.values()),
            candidate_qualified=sum(v['paths']['16/bilinear'] is not None and v['paths']['16/bilinear']['field_rel']<=.015 and v['paths']['16/bilinear']['flow_px']<=.50 for v in captures.values()),
            dense_winners={k:sum(v['competitor']==k for v in captures.values()) for k in sorted({v['competitor'] for v in captures.values()})},
            eligible_plain=sum(v['paths']['16/plain'] is not None and v['paths']['16/plain']['field_rel']<=.015 and v['paths']['16/plain']['flow_px']<=.50 for v in captures.values()),
            methods=paths,by_group=by,captures=captures)
    return out


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--save',action='store_true');a=parser.parse_args()
    s=summarize();p=HERE/'summary.json'
    if a.save:p.write_text(json.dumps(s,indent=2,allow_nan=False)+'\n')
    else:assert json.loads(p.read_text())==s
    for d,v in s.items():print(d,v['passed'],v['gain'],v['interval'],v['dense_ms'],v['methods']['16/bilinear'])
