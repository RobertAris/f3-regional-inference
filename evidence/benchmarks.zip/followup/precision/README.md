# Explicit FP16 convolution and joint regional service

The test uses one fixed middle packet from every camera-panel recording. The same ten regions receive 32 learned feature channels and both motion components, for a total of 1,392,640 bytes at host FP32. Sixteen arms cross two trunk precisions with released dense scatter (full-host or gathered), matched dense scatter, two cropped heads and three regional previews. The event lookup and scatter remain FP32. Each recording stores actual input/weight/activation/normalization-output dtypes and five interleaved synchronized measurements per finite arm. The recorded reduction dtype is its observable PyTorch output dtype. Internal device accumulation is backend dependent. [Protocol](protocol.md)

With only Python and NumPy, run `python followup/precision/replay.py` from the branch root. It verifies original input identities, the per-recording source hash, observed dtypes, and the timing and numerical-accuracy decisions. Each panel average weights physical setups equally when captures share a setup. The precision stress test uses the original recordings and one middle packet per recording.

To rerun, prepare the four event-packet directories from the [source instructions](../REPRODUCE.md), install the original model and flow head from [the inference instructions](../../docs/inference.md), and invoke the generator with fresh output storage. The local-root argument identifies a root containing the `datasets` tree. The model paths can be passed explicitly.

```sh
python -m followup.precision.measure --local-root /path/to/input-root \
  --f3-repo /path/to/fast-feature-fields --encoder-weights /path/to/encoder.pth \
  --head-weights /path/to/last.pth --head-config /path/to/flow_config.yaml \
  --out /path/to/new-measurements samsung scene7_00_000000
```

For the historical archive, `--save` writes the group summary from the included capture receipts. Wall times from a new run need separate analysis. Only the feature and flow approximation and timings at the specified packets are assessed here. The original FP32 task-fidelity and dense-head comparisons used the larger window panels.

The candidate met both accuracy tolerances on 38 of 43 individual packets. On Prophesee, the setup-weighted mean of capture RMS errors was 0.342 px and the square root of the setup-weighted mean square was 0.795 px. Dense comparison paths were screened per packet. The design's FP32 projection statement applies to the bilinear kernel code. The bicubic helper inherits the weight dtype for its interpolation and two matrix products. No 16/32-pixel cropped-head arm met both tolerances on any capture. [Group and capture measurements](summary.json)
