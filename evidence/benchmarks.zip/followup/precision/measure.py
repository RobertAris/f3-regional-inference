"""Time equal-output mixed-precision dense, cropped and regional F3 services."""
import argparse
import copy
import hashlib
import json
import time
from pathlib import Path

import numpy as np
import torch
from followup.fresh import gather, packet, regions
from query_f3.depth_context import prefix
from query_f3.engine import halo
from query_f3.quadrature.batch import batched_suffix
from query_f3.scale.preview import Preview
from query_f3.scale.prior import CubicPreview
from query_f3.inference.demo import import_file
from followup.motion_only.panels import SIZES,SOURCES,sha

HERE=Path(__file__).resolve().parent
MODES=('released-gather','released-full','matched','crop16','crop32','plain','bilinear','bicubic')


def host(field,flow):
    return torch.cat((field,flow),dim=1).float().contiguous().cpu().numpy()


def crop_head(field,head,rs,radius):
    buckets={}
    for i,r in enumerate(rs):
        x,y,w,h=halo(r,field.shape[-2:],radius)
        buckets.setdefault((w,h),[]).append((i,x,y))
    result=[None]*len(rs)
    for (w,h),group in buckets.items():
        patches=torch.cat([field[:,:,x:x+w,y:y+h] for _,x,y in group])
        output=head(patches.transpose(-1,-2)).transpose(-1,-2)
        for i,(j,x,y) in enumerate(group):
            px,py,pw,ph=rs[j];result[j]=output[i:i+1,:,px-x:px-x+pw,py-y:py-y+ph]
    return torch.cat(result)


def predict(events,size,rs,source,encoder,head,previews,mode,dtype):
    p=packet(events,size)
    if mode.startswith('released') and len(events):
        ev=torch.from_numpy(p.ev).to('mps')
        counts=torch.tensor([len(ev)],device=ev.device)
        if dtype==torch.float32:
            # Exercise the released forward entry point for the full-precision baseline.
            field=source(ev,counts).permute(0,3,1,2)
            flow=head(field.transpose(-1,-2)).transpose(-1,-2)
            if mode=='released-full':
                tensor=host(field,flow)
                return np.concatenate([tensor[:,:,px:px+w,py:py+h] for px,py,w,h in rs])
            return host(gather(field,rs),gather(flow,rs))
        grid=source.forward_variable_single(ev) if source.single_batch_mode else source.forward_variable(ev,counts)
    else:
        grid=p.grid(source)
    assert grid.dtype==torch.float32
    x=grid.to(dtype)
    if mode in ('plain','bilinear','bicubic'):
        preview=previews['bilinear' if mode=='plain' else mode]
        state,gains=prefix(encoder,x,(5,))[5]
        ctx=preview.context(encoder,head,state,gains,2,mode!='plain',mode!='plain')
        return host(*batched_suffix(encoder,head,ctx,rs))
    for stem,stage in zip(encoder.downsample_layers,encoder.stages,strict=True):x=stage(stem(x))
    if mode.startswith('crop'):
        return host(gather(x,rs),crop_head(x,head,rs,int(mode[4:])))
    flow=head(x.transpose(-1,-2)).transpose(-1,-2)
    if mode=='released-full':
        full=host(x,flow)
        return np.concatenate([full[:,:,px:px+w,py:py+h] for px,py,w,h in rs])
    return host(gather(x,rs),gather(flow,rs))


def labels(z,j,domain,rs):
    if domain=='emotion':
        yy,xx=np.where(z[f'valid{j}']);xy=np.column_stack((xx,yy));truth=z[f'velocity{j}'][yy,xx];mult=10.
    else:
        xy=z[f'xy{j}'];truth=z[f'gt{j}'];mult=int(z[f'dt{j}'])/100000
    idx=[];truth_order=[];seen=np.zeros(len(xy),bool)
    for i,(x,y,w,h) in enumerate(rs):
        selected=(xy[:,0]>=x)&(xy[:,0]<x+w)&(xy[:,1]>=y)&(xy[:,1]<y+h)&~seen
        ij=xy[selected]-[x,y]
        idx.extend(zip(np.full(len(ij),i),ij[:,0],ij[:,1],strict=True));truth_order.append(truth[selected]);seen|=selected
    return np.asarray(idx,'i4').reshape(-1,3),np.concatenate(truth_order),mult


@torch.inference_mode()
def run(opt):
    root=opt.local_root
    arch=root/'archive/binary-occupancy';weights=arch/'project/checkpoints'
    adapters=Path(__file__).resolve().parents[2]/'query_f3/inference/loaders'
    ck=opt.encoder_weights or weights/'f3/patchff_fullcardaym3ed_small_20ms.pth'
    flow_weights=opt.head_weights or weights/'flow/last.pth'
    config=opt.head_config or weights/'flow/flow_config.yaml'
    repo=opt.f3_repo or arch/'fast-feature-fields'
    enc=import_file(adapters/'published_f3.py').load_published_f3(repo,ck,'mps').eval()
    head=import_file(adapters/'released_flow.py').load_head(repo,flow_weights,config,ck,'mps').eval()
    size=SIZES[opt.domain];enc.return_logits=False;enc.return_feat=True;enc.w,enc.h=size;enc.frame_sizes=[*size,20]
    models={'32':(enc,head,torch.float32),'16':(copy.deepcopy(enc).half(),copy.deepcopy(head).half(),torch.float16)}
    for n in opt.names:
        old=HERE.parent/'records'/opt.domain/(n+'.json');record=json.loads(old.read_text())
        src=root/'datasets'/SOURCES[opt.domain]/(n+'.npz');j=record['windows'][len(record['windows'])//2]['j']
        lock={'source':sha(src),'record':sha(old),'generator':sha(Path(__file__)),'protocol':sha(HERE/'protocol.md')}
        assert lock['source']==record.get('input',record.get('packet'))
        out=opt.out/opt.domain/(n+'.json');out.parent.mkdir(parents=True,exist_ok=True)
        if out.exists():assert json.loads(out.read_text())['lock']==lock;continue
        with np.load(src) as z:
            e=z[f'w{j}'];rs=regions(e,size);ix,truth,mult=labels(z,j,opt.domain,rs)
        previews={prec:{'bilinear':Preview(),'bicubic':CubicPreview()} for prec in models}
        def call(key):
            prec,mode=key.split('/',1);trunk,flow,dtype=models[prec]
            return predict(e,size,rs,enc,trunk,flow,previews[prec],mode,dtype)
        dtype_log={}
        sample=packet(e,size).grid(enc)
        assert sample.dtype==torch.float32
        for prec,(trunk,net,dtype) in models.items():
            observed={}
            def capture_dtypes(module,args,out):
                inp=args[0];observed.update(activation=str(inp.dtype),output=str(out.dtype),norm=str(torch.norm(inp,p=2,dim=(1,2),keepdim=True).dtype))
            hook=trunk.stages[0][0].grn.register_forward_hook(capture_dtypes)
            try:value=call(prec+'/released-gather')
            finally:hook.remove()
            dtype_log[prec]=dict(grid=str(sample.dtype),parameter=str(trunk.stages[0][0].dwconv.weight.dtype),host=str(value.dtype),**observed)
            assert observed['activation']==str(dtype) and value.dtype==np.float32
        ref=call('32/released-gather');assert np.isfinite(ref).all()
        arms=[prec+'/'+m for prec in models for m in MODES]
        rng=np.random.default_rng(int.from_bytes(hashlib.sha256(('precision/'+n).encode()).digest()[:8],'big'));res={}
        for key in rng.permutation(arms):
            value=call(key);assert value.shape==ref.shape
            finite=np.isfinite(value)
            if not finite.all():res[key]={'nonfinite':int((~finite).sum())};continue
            delta=(value-ref).astype('d');v=value[:,32:].transpose(0,2,3,1)
            selected=v[ix[:,0],ix[:,1],ix[:,2]]
            res[key]=dict(nonfinite=0,field_mse=float(np.mean(delta[:,:32]**2)),flow_mse=float(np.mean(delta[:,32:]**2)),
                          epe_sum=float(np.linalg.norm(mult*selected-truth,axis=1).sum(dtype='d')),ms=[])
        for rep in range(5):
            for key in rng.permutation(arms):
                if res[key]['nonfinite']:continue
                torch.mps.synchronize();start=time.perf_counter();value=call(key);torch.mps.synchronize()
                res[key]['ms'].append(1000*(time.perf_counter()-start))
                if not np.isfinite(value).all():res[key]['nonfinite']+=int((~np.isfinite(value)).sum())
        out.write_text(json.dumps(dict(name=n,domain=opt.domain,group=record['group'],window=j,n=len(ix),events=len(e),regions=rs,dtypes=dtype_log,
            signal=float(np.mean(ref[:,:32].astype('d')**2)),zero_sum=float(np.linalg.norm(truth,axis=1).sum(dtype='d')),results=res,lock=lock),
            allow_nan=False,default=lambda x:x.item())+'\n')
        print(opt.domain,n,flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--local-root',type=Path,required=True);parser.add_argument('--out',type=Path,default=HERE/'records')
    for flag in ('f3-repo','encoder-weights','head-weights','head-config'):parser.add_argument('--'+flag,type=Path)
    parser.add_argument('domain',choices=SIZES);parser.add_argument('names',nargs='+');run(parser.parse_args())
