# Flow data and model setup

## Regenerating native packets

In a Python environment with requests, NumPy 2, h5py, hdf5plugin, SciPy, tqdm, OpenCV, PyYAML, PyTorch and the original F3 model dependencies, run the following from the branch root. The Samsung archive is 10,417,922,576 bytes and requires additional space for extracted captures and flow labels. The E-MOTION reader only requests needed HDF5 ranges. The source receipts identify exact publisher revisions or archive hashes and individual packets. Some timestamp and depth metadata from EVIMO use the publisher's pickled NumPy representation. Inspect and hash the publisher archive before loading it.

```sh
python -m followup.sources.samsung
python -m followup.sources.samsung_packets
python -c "from followup.sources.emotion import NAMES,run; [run(n) for n in NAMES[:-1]]"
python -m followup.sources.emotion_mult
```

Point the runner at the released model and generated packets. Replace the final capture name with the other names listed in the corresponding source receipts, or list several names on one invocation. Use `--domain emotion --data datasets/f3-next-emotion` for the velocity measurements.

```sh
python -m followup.fresh --domain samsung --data datasets/f3-next-samsung/packets \
  --out runs/replication/samsung --f3-repo /path/to/fast-feature-fields \
  --encoder-weights /path/to/patchff_fullcardaym3ed_small_20ms.pth \
  --head-weights /path/to/last.pth --head-config /path/to/flow_config.yaml \
  scene_04_00_000000
```

Source data remain under the terms of their publishers. [EVIMO2](https://better-flow.github.io/evimo/download_evimo_2.html) · [E-MOTION](https://heudiasyc.github.io/emotion/) · [Pinned E-MOTION release](https://huggingface.co/datasets/ivangr3/e-motion/tree/8c364021cc14f48e778a55ce36188eea9c899ca1)

## Paths for the timing and per-region benchmarks

The precision-policy and region-fidelity runners take a single input root. They read the original F3 checkout, weights and calibrated packets at the following paths relative to that root. Directories may be symlinks. The [inference guide](../docs/inference.md) identifies the upstream revision and released weight files.

```text
archive/binary-occupancy/fast-feature-fields/
archive/binary-occupancy/project/checkpoints/f3/patchff_fullcardaym3ed_small_20ms.pth
archive/binary-occupancy/project/checkpoints/flow/last.pth
archive/binary-occupancy/project/checkpoints/flow/flow_config.yaml
datasets/query-f3-final-panel/evimo/
datasets/query-f3-final-panel/m3ed/
datasets/f3-next-samsung/packets/
datasets/f3-next-emotion/
```

The downloaders above rebuild the Samsung and E-MOTION inputs. New Prophesee and M3ED timings require the original calibrated packet caches. The saved measurements replay for all four panels without those caches. For new precision-policy timings, use a separate checkout with an empty `followup/precision_policy/records/` directory and retain the prior measurements in `followup/precision/records/`. Existing output files trigger verification and reuse.
