# Full-precision bicubic regional queries

Each ten-region response returns all 32 learned F3 channels and both motion components. We compare each response with released FP32 dense F3. Each recording contributes its earliest archived follow-up window. The middle packet from the prior precision experiment is used to explain the choice, and is reported separately. [Fixed protocol](protocol.md) · [Per-recording measurements](records/)

| Camera panel | Earliest FP32 bicubic requests within both tolerances | Mean time saved vs eligible dense, 95% paired interval | Middle requests within both tolerances |
|---|---:|---:|---:|
| Prophesee EVIMO2v2 | 14 / 14 | 13.17% [9.48, 16.85] | 14 / 14 |
| Samsung EVIMO2v2 | 15 / 16 | 10.29% [8.54, 13.60] | 16 / 16 |
| M3ED | 6 / 6 | 8.84% [7.10, 10.40] | 6 / 6 |
| E-MOTION | 7 / 7 | 7.72% [6.51, 8.78] | 7 / 7 |

Across the earliest windows, only Samsung scene_04_04_000000 exceeded either tolerance with FP32 bicubic. Its relative field RMS was 0.0504% and its flow-component RMS was 0.6623 px. FP16 bilinear qualified on 36 of these 43 and FP16 bicubic on 33. The camera-specific choice qualified on 41. Intervals quantify group variation on this one Mac. [Full per-capture comparisons](summary.json)

The retrospective fastest-finite comparison admits dense outputs that exceeded either tolerance. Mean latency savings were 8.35% on Prophesee, 8.70% on Samsung, 8.84% on M3ED and 7.72% on E-MOTION. Replay both comparisons from the repository root with Python and NumPy.

```sh
python -m followup.precision_policy.replay
python -m followup.precision_policy.sensitivity
```

To repeat the measurements on MPS, supply the development root containing the four documented packet archives and released encoder and flow checkpoints. Use the same setup as the original precision experiment. Run one capture per invocation, substituting the names in the existing precision records. To preserve archived measurements, run the experiment from a separate checkout. Regenerate the summary with the save flag after all 43 invocations. [Data and checkpoint setup](../REPRODUCE.md) · [Original numerical comparison](../precision/README.md)

```sh
python -m followup.precision_policy.measure /path/to/local/data-root evimo scene14_dyn_test_02_000000
python -m followup.precision_policy.replay --save
```
