"""Replay the retrospective timing comparison on the reused earliest windows."""

import hashlib
import json
from math import isfinite
from pathlib import Path
from statistics import mean, median


HERE = Path(__file__).resolve().parent
PANEL_SIZE = {"evimo": 14, "samsung": 16, "m3ed": 6, "emotion": 7}
REGIONAL = "32/bicubic"
REGIONAL_ARMS = {REGIONAL, "16/bicubic", "16/bilinear"}
DENSE_ARMS = {
    f"{precision}/{mode}"
    for precision in (16, 32)
    for mode in ("matched", "released-full", "released-gather")
}


def require(condition, path, message):
    if not condition:
        raise ValueError(f"{path}: {message}")


def read_json(path):
    try:
        return json.loads(path.read_bytes())
    except ValueError as exc:
        raise ValueError(f"{path}: {exc}") from exc


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_input(path, record, primary_capture, previous_capture, source_hashes):
    panel, name = path.parent.name, path.stem
    old_path = HERE.parent / "records" / panel / path.name
    previous_path = HERE.parent / "precision" / "records" / panel / path.name
    old = read_json(old_path)
    previous = read_json(previous_path)

    require((record["domain"], record["name"]) == (panel, name), path, "capture identity mismatch")
    group = record["group"]
    require(
        isinstance(group, str) and group and group == old["group"] == previous["group"]
        == primary_capture["group"] == previous_capture["group"],
        path, "setup group mismatch",
    )
    require(
        record["packet"] == old.get("input", old.get("packet")) == previous["lock"]["source"],
        path, "input packet mismatch",
    )
    require(
        record["old"] == sha256(old_path)
        and record["previous"] == previous_capture["sha256"] == sha256(previous_path)
        and all(record[key] == digest for key, digest in source_hashes.items()),
        path, "source hash mismatch",
    )

    earliest = old["windows"][0]
    require(
        record["window"] == earliest["j"] and record["window"] != previous["window"],
        path, "expected the earliest window, distinct from the middle window",
    )
    regions = record["regions"]
    require(
        len(regions) == 10 and all(len(region) == 4 and region[2:] == [32, 32] for region in regions),
        path, "expected ten 32×32 regions",
    )
    if "rectangles" in earliest:
        require(
            regions == earliest["rectangles"] and record["events"] == earliest["events"],
            path, "region or event count mismatch",
        )


def finite_number(value):
    return type(value) in (int, float) and isfinite(value)


def compare_timings(path, arms):
    require(set(arms) == DENSE_ARMS | REGIONAL_ARMS, path, "dense or regional arm set mismatch")
    regional_ms = None
    finite_dense = []
    qualified_dense = []
    for arm, values in arms.items():
        nonfinite = values.get("nonfinite", False)
        require(isinstance(nonfinite, bool), path, f"{arm}: invalid nonfinite flag")
        if nonfinite:
            continue
        repeats = values.get("ms")
        require(
            isinstance(repeats, list) and len(repeats) == 5
            and all(finite_number(ms) and ms > 0 for ms in repeats),
            path, f"{arm}: expected five positive finite timing repeats",
        )

        if arm == REGIONAL:
            regional_ms = median(repeats)
        if arm in DENSE_ARMS:
            field, flow = values.get("field"), values.get("flow")
            require(
                all(finite_number(error) and error >= 0 for error in (field, flow)),
                path, f"{arm}: invalid fidelity measurements",
            )
            dense_ms = median(repeats)
            finite_dense.append(dense_ms)
            if field <= .015 and flow <= .50:
                qualified_dense.append(dense_ms)

    require(regional_ms is not None, path, "no finite FP32 bicubic timing")
    require(qualified_dense, path, "no finite dense timing within both fidelity limits")
    qualified_ms = min(qualified_dense)
    finite_ms = min(finite_dense)
    return (
        1 - regional_ms / qualified_ms,
        1 - regional_ms / finite_ms,
        regional_ms < finite_ms,
        finite_ms < qualified_ms,
    )


def calculate():
    primary = read_json(HERE / "summary.json")
    previous = read_json(HERE.parent / "precision" / "summary.json")
    records = HERE / "records"
    source_hashes = {"code": sha256(HERE / "measure.py"), "protocol": sha256(HERE / "protocol.md")}
    require(
        {path.parent.name for path in records.glob("*/*.json")} == set(PANEL_SIZE),
        records, "record panels differ from the fixed panel set",
    )

    results = {}
    for panel, size in PANEL_SIZE.items():
        registered = primary[panel]["first"][REGIONAL]
        primary_captures = registered["captures"]
        previous_captures = previous[panel]["captures"]
        files = sorted((records / panel).glob("*.json"))
        require(
            len(files) == size == registered["total"]
            and {file.stem for file in files} == set(primary_captures) == set(previous_captures),
            records / panel, f"expected the same {size} captures as both archived summaries",
        )

        groups = {}
        faster_count = excluded_count = 0
        for path in files:
            record = read_json(path)
            validate_input(
                path, record, primary_captures[path.stem], previous_captures[path.stem], source_hashes,
            )
            qualified, finite, faster, excluded = compare_timings(path, record["arms"])
            groups.setdefault(record["group"], []).append((qualified, finite))
            faster_count += faster
            excluded_count += excluded

        qualified_means = [mean(qualified for qualified, _ in pairs) for pairs in groups.values()]
        finite_means = [mean(finite for _, finite in pairs) for pairs in groups.values()]
        results[panel] = (mean(qualified_means), mean(finite_means), faster_count, excluded_count)
    return results


def main():
    results = calculate()
    print("Retrospective FP32 bicubic timing sensitivity on 43 reused earliest windows")
    print(
        f"{'Panel':<8} {'Qualified dense':>16} {'Fastest finite dense':>21} "
        f"{'Faster vs finite':>17} {'Faster dense excluded':>22}"
    )
    for panel, (qualified, finite, faster, excluded) in results.items():
        count = f"{faster}/{PANEL_SIZE[panel]}"
        print(f"{panel:<8} {qualified:>16.5%} {finite:>21.5%} {count:>17} {excluded:>22}")


if __name__ == "__main__":
    main()
