"""Verify first-window measurements and reconstruct both precision choices."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
PANEL_SIZE = {'evimo':14,'samsung':16,'m3ed':6,'emotion':7}
REGIONAL = ('32/bicubic','16/bicubic','16/bilinear')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def eligible(v):
    return v is not None and v['field']<=.015 and v['flow']<=.50


def metrics(rows, mode):
    captures = {}
    groups = {}
    for n,(g,arms) in rows.items():
        baseline = min((s['time'],k) for k,s in arms.items() if k.split('/')[1] in
                       ('matched','released-full','released-gather') and eligible(s))
        s = arms[mode]
        gain = 1-s['time']/baseline[0] if s else None
        captures[n] = dict(group=g,field=s['field'] if s else None,flow=s['flow'] if s else None,
                           gain=gain,qualified=eligible(s),competitor=baseline[1],
                           dense_ms=baseline[0],regional_ms=s['time'] if s else None)
        groups.setdefault(str(g),[]).append(gain)
    all_finite = all(v is not None for group in groups.values() for v in group)
    avg, ci = None,None
    if all_finite:
        group_means = np.array([np.mean(groups[g]) for g in sorted(groups)])
        idx = np.random.default_rng(993).integers(len(group_means),size=(20000,len(group_means)))
        avg = float(group_means.mean())
        ci = np.quantile(group_means[idx].mean(axis=1),[.025,.975]).tolist()
    n_ok = sum(v['qualified'] for v in captures.values())
    return dict(qualified=n_ok,total=len(rows),mean_saving=avg,interval=ci,
                passed=bool(n_ok==len(rows) and avg is not None and avg>=.05 and ci[0]>0),captures=captures)


def calculate():
    prevdir = HERE.parent/'precision'
    m = json.loads((prevdir/'summary.json').read_text())
    results = {}
    for d,num in PANEL_SIZE.items():
        first,middle = {},{}
        files = sorted((HERE/'records'/d).glob('*.json'))
        assert len(files)==num and {p.stem for p in files}==set(m[d]['captures'])
        for file in files:
            r = json.loads(file.read_text())
            n=file.stem
            p=prevdir/'records'/d/file.name
            f=HERE.parent/'records'/d/file.name
            old=json.loads(f.read_text())
            previous=json.loads(p.read_text())
            assert r['name']==n and r['domain']==d and r['group']==old['group']==previous['group']
            assert r['packet']==old.get('input',old.get('packet'))==previous['lock']['source']
            assert r['previous']==sha(p) and r['old']==sha(f)
            assert r['code']==sha(HERE/'measure.py') and r['protocol']==sha(HERE/'protocol.md')
            assert r['window']==old['windows'][0]['j'] and r['window']!=previous['window']
            if 'rectangles' in old['windows'][0]:
                assert r['regions']==old['windows'][0]['rectangles'] and r['events']==old['windows'][0]['events']
            assert len(r['regions'])==10 and all(q[2:]==[32,32] for q in r['regions'])
            assert m[d]['captures'][n]['sha256']==sha(p)
            expected={str(prec)+'/'+k for prec in (16,32) for k in ('matched','released-full','released-gather')} | set(REGIONAL)
            assert set(r['arms'])==expected
            old_paths=m[d]['captures'][n]['paths']
            a={}
            for k,v in r['arms'].items():
                if v.get('nonfinite'):
                    a[k]=None
                    continue
                assert len(v['ms'])==5 and min(v['ms'])>0
                a[k]=dict(time=float(np.median(v['ms'])),field=v['field'],flow=v['flow'])
            first[n]=(r['group'],a)
            middle[n]=(r['group'],{k:None if v is None else dict(time=v['ms'],field=v['field_rel'],flow=v['flow_px'])
                                   for k,v in old_paths.items()})
        chosen='32/bicubic' if d in ('evimo','samsung') else '16/bicubic'
        results[d]=dict(first={k:metrics(first,k) for k in REGIONAL},
                        middle={k:metrics(middle,k) for k in REGIONAL},panel_choice=chosen)
    return results


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--save',action='store_true')
    p.add_argument('--all-policies',action='store_true',help='Also display the two FP16 regional comparisons')
    args=p.parse_args()
    v=calculate()
    dest=HERE/'summary.json'
    if args.save:
        dest.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
    else:
        assert json.loads(dest.read_text())==v
    names={'evimo':'Prophesee EVIMO2v2','samsung':'Samsung EVIMO2v2','m3ed':'M3ED','emotion':'E-MOTION'}
    policies=REGIONAL if args.all_policies else ('32/bicubic',)
    for policy in policies:
        print(f'FP{policy.split("/")[0]} {policy.split("/")[1]} regional inference')
        print(f'{"Panel":<22} {"Requests within limits":>22} {"Time saved":>12} {"95% interval":>20}')
        for domain,panel in v.items():
            result=panel['first'][policy]
            count=f'{result["qualified"]}/{result["total"]}'
            saving=result['mean_saving']
            interval=result['interval']
            saving_text=f'{saving*100:.2f}%' if saving is not None else 'unavailable'
            interval_text=f'[{interval[0]*100:.2f}, {interval[1]*100:.2f}]%' if interval else 'unavailable'
            print(f'{names[domain]:<22} {count:>22} {saving_text:>12} {interval_text:>20}')
