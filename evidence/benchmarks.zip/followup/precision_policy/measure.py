"""Repeat equal-output regional precision measurements on the first archived window."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import time

import numpy as np
import torch

from followup.precision.measure import (CubicPreview, Preview, SIZES, SOURCES, import_file,
                                         predict, regions, sha)

HERE = Path(__file__).resolve().parent
BRANCH = HERE.parents[1]
DENSE = ('released-gather','released-full','matched')
MODES = [str(p)+'/'+m for p in (32,16) for m in DENSE] + ['32/bicubic','16/bicubic','16/bilinear']


@torch.inference_mode()
def measure(root, domain, name):
    weights = root/'archive/binary-occupancy/project/checkpoints'
    repo = root/'archive/binary-occupancy/fast-feature-fields'
    ck = weights/'f3/patchff_fullcardaym3ed_small_20ms.pth'
    adapters = BRANCH/'query_f3/inference/loaders'
    old = HERE.parent/'records'/domain/(name+'.json')
    previous = HERE.parent/'precision/records'/domain/(name+'.json')
    r = json.loads(old.read_text())
    j = r['windows'][0]['j']
    assert j != json.loads(previous.read_text())['window']
    file = root/'datasets'/SOURCES[domain]/(name+'.npz')
    assert sha(file)==r.get('input',r.get('packet'))
    out = HERE/'records'/domain/(name+'.json')
    if out.exists():
        saved=json.loads(out.read_text())
        for key,expected in dict(name=name,domain=domain,window=j,packet=sha(file),code=sha(Path(__file__)),
                                 protocol=sha(HERE/'protocol.md'),old=sha(old),previous=sha(previous)).items():
            assert saved[key]==expected
        assert set(saved['arms'])==set(MODES)
        assert all(v.get('nonfinite') or (len(v['ms'])==5 and min(v['ms'])>0) for v in saved['arms'].values())
        return
    enc = import_file(adapters/'published_f3.py').load_published_f3(repo,ck,'mps').eval()
    head = import_file(adapters/'released_flow.py').load_head(repo,weights/'flow/last.pth',
        weights/'flow/flow_config.yaml',ck,'mps').eval()
    size = SIZES[domain]
    enc.return_logits=False
    enc.return_feat=True
    enc.w, enc.h = size
    enc.frame_sizes = [*size,20]
    models = {'32':(enc,head,torch.float32),'16':(copy.deepcopy(enc).half(),copy.deepcopy(head).half(),torch.float16)}
    with np.load(file) as z:
        events = z[f'w{j}']
    rs = regions(events,size)
    if 'rectangles' in r['windows'][0]:
        assert np.array_equal(rs,r['windows'][0]['rectangles'])
    previews = {k:dict(bilinear=Preview(),bicubic=CubicPreview()) for k in models}
    def call(key):
        prec,mode = key.split('/')
        trunk,net,dtype = models[prec]
        return predict(events,size,rs,enc,trunk,net,previews[prec],mode,dtype)
    baseline = call('32/released-gather')
    assert baseline.shape == (10,34,32,32) and np.isfinite(baseline).all()
    signal = float(np.square(baseline[:,:32],dtype='d').mean())
    assert signal>0
    seed = int.from_bytes(hashlib.sha256(('first-window/'+domain+'/'+name).encode()).digest()[:8],'big')
    rng = np.random.default_rng(seed)
    arms = {}
    for k in rng.permutation(MODES):
        v = call(k)
        assert v.shape==baseline.shape
        if not np.isfinite(v).all():
            arms[k] = dict(nonfinite=True)
            continue
        delta = np.square(v.astype('d')-baseline.astype('d'))
        arms[k] = dict(field=float(np.sqrt(delta[:,:32].mean()/signal)),flow=float(np.sqrt(delta[:,32:].mean())),ms=[])
    for _ in range(5):
        for k in rng.permutation(MODES):
            if arms[k].get('nonfinite'):
                continue
            torch.mps.synchronize()
            start = time.perf_counter()
            value = call(k)
            torch.mps.synchronize()
            arms[k]['ms'].append((time.perf_counter()-start)*1000)
            if not np.isfinite(value).all():
                arms[k]['nonfinite'] = True
    out.parent.mkdir(parents=True,exist_ok=True)
    doc = dict(name=name,domain=domain,group=r['group'],window=j,packet=sha(file),events=len(events),
               regions=np.asarray(rs).tolist(),old=sha(old),previous=sha(previous),code=sha(Path(__file__)),
               protocol=sha(HERE/'protocol.md'),seed=seed,arms=arms)
    with out.open('x') as stream:
        stream.write(json.dumps(doc,allow_nan=False)+'\n')
    print(domain,name,j,flush=True)


if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('root',type=Path,help='local root holding datasets and the released checkpoints')
    p.add_argument('domain',choices=SIZES)
    p.add_argument('name')
    args=p.parse_args()
    measure(args.root.resolve(),args.domain,args.name)
