"""Run a fixed classical motion-only reader on the archived native test packets."""
import argparse,hashlib,json,time
from pathlib import Path
import cv2
import numpy as np
from followup.fresh import regions

ROOT=Path(__file__).resolve().parent
SIZES={'samsung':(640,480),'emotion':(1280,720),'m3ed':(1280,720),'evimo':(640,480)}
SOURCES={'samsung':'f3-next-samsung/packets','emotion':'f3-next-emotion','m3ed':'query-f3-final-panel/m3ed','evimo':'query-f3-final-panel/evimo'}


def sha(f):
    with f.open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()


def flow(e,size,span,rs):
    w,h=size;t=e[:,0];use=(t>=-2*span)&(t<0);t,x,y=e[use].astype('i8').T
    a=np.bincount(((t+2*span)//span*h+y)*w+x,minlength=2*h*w).reshape(2,h,w)
    im=[np.minimum(255,cv2.GaussianBlur(np.log1p(z).astype('f'),(0,0),1)*(255/np.log(6))).astype('u1') for z in a]
    v=cv2.calcOpticalFlowFarneback(*im,None,.5,3,15,3,5,1.2,0)
    return np.stack([v[y:y+rh,x:x+rw] for x,y,rw,rh in rs])


def evaluate(tiles,rs,xy,truth,scale):
    visited=np.zeros(len(xy),bool);vsum=zero=count=0
    for a,(x,y,w,h) in zip(tiles,rs,strict=True):
        xx,yy=xy.T;use=(xx>=x)&(xx<x+w)&(yy>=y)&(yy<y+h)&~visited
        p=a[yy[use]-y,xx[use]-x]*scale
        count+=int(use.sum());vsum+=np.linalg.norm(p-truth[use],axis=1).sum(dtype='d')
        zero+=np.linalg.norm(truth[use],axis=1).sum(dtype='d');visited|=use
    return [count,vsum,zero]


def run(dom,data,dest):
    cv2.setNumThreads(1);dest=dest/dom;dest.mkdir(exist_ok=True,parents=True)
    for f in sorted((ROOT.parent/'records'/dom).glob('*.json')):
        s=json.loads(f.read_text());pack=data/SOURCES[dom]/(s['name']+'.npz');h=sha(pack)
        assert h==s.get('input',s.get('packet'));target=dest/f.name
        lock=dict(packet=h,old_record=sha(f),source=sha(Path(__file__)),protocol=sha(ROOT/'protocol.md'))
        if target.exists():assert json.loads(target.read_text())['lock']==lock;continue
        res=[]
        with np.load(pack) as z:
            for old in s['windows']:
                j=old['j'];e=z[f'w{j}'];size=SIZES[dom];rs=regions(e,size)
                if 'rectangles' in old:np.testing.assert_array_equal(rs,old['rectangles'])
                if dom=='emotion':
                    mask=z[f'valid{j}'];yy,xx=np.where(mask);xy=np.column_stack((xx,yy));y=z[f'velocity{j}'][yy,xx];dt=1_000_000
                else:xy,y,dt=z[f'xy{j}'],z[f'gt{j}'],int(z[f'dt{j}'])
                out={}
                for span in (8000,10000):
                    start=time.perf_counter();tiles=flow(e,size,span,rs);ms=(time.perf_counter()-start)*1000
                    a=evaluate(tiles,rs,xy,y,dt/span);v=old['rows']['dense']['gt']
                    np.testing.assert_allclose([a[0],a[-1]],[v[0],v[-1]],atol=1e-4,rtol=1e-6)
                    out[str(span)]=dict(gt=a,ms=ms)
                res.append(dict(j=int(j),far=out,dense=old['rows']['dense']['gt'],regional=old['rows']['regional']['gt']))
        target.write_text(json.dumps(dict(name=s['name'],group=s['group'],domain=dom,windows=res,lock=lock),indent=2)+'\n')
    print(dom,flush=True)


def summarize(out):
    results={}
    for dom in SIZES:
        files=sorted((out/dom).glob('*.json'));assert len(files)=={'samsung':16,'emotion':7,'m3ed':6,'evimo':14}[dom]
        scene={}
        for f in files:
            r=json.loads(f.read_text());methods={}
            for k in ('dense','regional','zero','8000','10000'):
                rows=[(x['far'][k]['gt'] if k in ('8000','10000') else x['dense' if k=='zero' else k]) for x in r['windows']]
                a=np.sum(rows,axis=0);methods[k]=float(a[-1 if k=='zero' else 1]/a[0])
            scene.setdefault(r['group'],[]).append(methods)
        groups={g:{k:float(np.mean([v[k] for v in rows])) for k in rows[0]} for g,rows in scene.items()}
        vec=lambda k:np.array([v[k] for v in groups.values()]);n=len(groups);ix=np.random.default_rng(731).integers(n,size=(20000,n))
        d=vec('8000')-vec('regional');results[dom]=dict(groups=groups,mean={k:float(vec(k).mean()) for k in next(iter(groups.values()))},
            raw_minus_regional=[float(d.mean()),*np.quantile(d[ix].mean(1),[.025,.975]).tolist()])
        print(dom,results[dom]['mean'],results[dom]['raw_minus_regional'])
    return results

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('domain',choices=[*SIZES,'summary']);ap.add_argument('--data',type=Path,default=Path('datasets'))
    ap.add_argument('--out',type=Path,default=ROOT/'records');a=ap.parse_args()
    if a.domain=='summary':print(json.dumps(summarize(a.out),indent=2))
    else:run(a.domain,a.data,a.out)
