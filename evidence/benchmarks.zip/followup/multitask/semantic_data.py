"""Acquire three time-selected left-event packets per DSEC semantic recording."""

import argparse
import concurrent.futures
import io
import json
import re
from pathlib import Path
import zipfile

import cv2
import h5py
import hdf5plugin  # register Blosc HDF5 filters
import numpy as np
import requests

from followup.multitask.ranges import ByteFile, Source, directory, member
from query_f3.binding import ROOT, digest
from followup.multitask.restore import LockedFile, save_packet

BASE = "https://download.ifi.uzh.ch/rpg/DSEC"
CMDA = "https://drive.usercontent.google.com/download?id=1LWinkZXUWKBzl946wxhLKaHbOOIP-hRi&export=download&confirm=t"
OUT = ROOT / "datasets/multitask"
MAPPING = np.array([5, 6, 1, 9, 2, 4, 10, 10, 7, 7, 0, 3, 3, 8, 8, 8, 8, 8, 8], dtype="u1")


def connect(url):
    response = requests.get(url, headers={"Range": "bytes=0-0", "Accept-Encoding": "identity"}, timeout=60)
    response.raise_for_status()
    if response.status_code != 206 or len(response.content) != 1:
        raise ValueError(f"Server did not support byte ranges at {url}")
    return Source(
        url,
        int(response.headers["Content-Range"].split("/")[-1]),
        response.headers.get("ETag"),
        response.headers.get("Last-Modified"),
    )


def acquire(subset):
    name = "zurich_city_" + subset
    roster = json.loads(Path(__file__).with_name("packets.json").read_text())[
        "human" if subset.startswith("09_") else "day"
    ]
    manual = subset.startswith("09_")
    split = "train" if manual or subset == "02_a" else "test"
    events_url = f"{BASE}/{split}_coarse/{split}_events.zip"
    labels_url = CMDA if manual else f"{BASE}/semantic/{split}_semantic_segmentation.zip"
    event_src, lab_src = connect(events_url), connect(labels_url)
    entries = directory(event_src)
    data_info = entries[f"{name}/events/left/events.h5"]
    rect_info = entries[f"{name}/events/left/rectify_map.h5"]
    fh, evt = member(event_src, data_info, block=262144)
    fr, rect = member(event_src, rect_info, block=262144)
    OUT.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ByteFile(lab_src)) as archive, h5py.File(fh) as h, h5py.File(fr) as m:
        all_members = archive.namelist()
        if manual:
            pattern = re.compile(rf"/{name}/labels/{name}_(\d+)_grey_gtFine_labelTrainIds.png$")
            images = sorted((int(match[1]), n) for n in all_members if (match := pattern.search("/" + n)))
            url = f"{BASE}/{split}/{name}/{name}_image_timestamps.txt"
            response = requests.get(url, timeout=60)
            response.raise_for_status()
            times = np.loadtxt(io.BytesIO(response.content), dtype="i8").reshape(-1)
        else:
            images = sorted(
                (int(Path(n).stem), n)
                for n in all_members
                if f"{name}/" in n and "/11classes/" in n and n.endswith(".png")
            )
            (tn,) = [n for n in all_members if name in n and n.endswith("semantic_timestamps.txt")]
            times = np.loadtxt(io.BytesIO(archive.read(tn)), dtype="i8").reshape(-1)
            if len(times) != len(images):
                raise ValueError((name, len(times), len(images)))
        if not images:
            raise ValueError((name, all_members[:10]))
        forward = m["rectify_map"][:]
        offset = int(h["t_offset"][()])
        for q in (20, 50, 80):
            i = (len(images) - 1) * q // 100
            ident, entry = images[i]
            if manual and not any(n.endswith(f"{name}/warp_images/{ident:06d}.png") for n in all_members):
                raise ValueError(entry)
            cut = int(times[ident if manual else i])
            lo, hi = cut - offset - 20000, cut - offset
            lut = h["ms_to_idx"]
            a = int(lut[lo // 1000])
            b = int(lut[(hi + 999) // 1000])
            ts = h["events/t"][a:b].astype("int64")
            left, right = np.searchsorted(ts, [lo, hi])
            s = slice(a + left, a + right)
            if (
                s.start
                and int(h["events/t"][s.start - 1]) >= lo
                or s.stop < len(h["events/t"])
                and int(h["events/t"][s.stop]) < hi
            ):
                raise ValueError("ms_to_idx did not bracket label time")
            x, y, p = [h["events/" + key][s] for key in ("x", "y", "p")]
            rawxy = np.rint(forward[y, x]).astype("i4")
            ok = np.all((rawxy >= 0) & (rawxy < (640, 480)), axis=1)
            events = np.column_stack((ts[left:right] - hi, rawxy, p))[ok].astype("i4")
            label = cv2.imdecode(np.frombuffer(archive.read(entry), "u1"), cv2.IMREAD_UNCHANGED)
            if label.ndim != 2 or label.shape[1] != 640 or label.shape[0] not in (440, 480):
                raise ValueError((entry, label.shape))
            label = label[:440].copy()
            if manual:
                if not np.all((label < 19) | (label == 255)):
                    raise ValueError(np.unique(label))
                keep = label < 19
                label[keep] = MAPPING[label[keep]]
            if not np.all((label < 11) | (label == 255)):
                raise ValueError(np.unique(label))
            dest = OUT / f"{name}-{q}.npz"
            target = LockedFile(dest, roster[dest.name]["sha256"])
            if not target.cached():
                save_packet(target, dict(left=events, label=label))
            receipt = dict(
                name=name,
                q=q,
                image_id=ident,
                label_us=cut,
                label=entry,
                labels_url=labels_url,
                events_url=events_url,
                event_member=evt,
                rectification=rect,
                label_crc=archive.getinfo(entry).CRC,
                labels_size=lab_src.size,
                labels_etag=lab_src.etag,
                events_etag=event_src.etag,
                source_indices=[int(s.start), int(s.stop)],
                sha256=digest(dest),
                label_kind="human" if manual else "image-model",
            )
            dest.with_suffix(".json").write_text(json.dumps(receipt, indent=2) + "\n")
            print(name, ident, len(events), flush=True)
    event_src.session.close()
    lab_src.session.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "takes", nargs="*", default=["09_a", "09_b", "09_c", "09_d", "02_a", "13_a", "14_c", "15_a"]
    )
    args = parser.parse_args()
    with concurrent.futures.ThreadPoolExecutor(4) as pool:
        list(pool.map(acquire, args.takes))
