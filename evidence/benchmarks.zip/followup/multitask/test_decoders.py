"""CPU parity checks against full-frame Depth Anything V2 and SegFormer tails."""

import math
import unittest

import torch
from torch import nn
from torch.nn import functional as F
from transformers import SegformerConfig, SegformerForSemanticSegmentation

from query_f3.multitask.decoders import depth_context, depth_regions, seg_context, seg_regions


class _ToyDino(nn.Module):
    def get_intermediate_layers(self, image, layers, *, return_class_token):
        if layers != [2, 5, 8, 11] or not return_class_token:
            raise AssertionError("unexpected ViT-B intermediate layer request")
        self.image = image
        tokens = F.avg_pool2d(image, 14).flatten(2).transpose(1, 2)
        global_mean = tokens.mean(dim=1)
        return tuple((tokens * (1 + i / 8) + global_mean[:, None], global_mean) for i in layers)


class _ToyRefine(nn.Module):
    def __init__(self):
        super().__init__()
        self.skip = nn.Conv2d(4, 4, 3, padding=1)
        self.mix = nn.Conv2d(4, 4, 3, padding=1)

    def forward(self, coarse, skip=None, *, size=None):
        if skip is not None:
            coarse = coarse + self.skip(skip)
        coarse = coarse + self.mix(coarse).relu()
        scale = {"scale_factor": 2} if size is None else {"size": size}
        return F.interpolate(coarse, **scale, mode="bilinear", align_corners=True)


class _ToyDptHead(nn.Module):
    """Small DPT fixture with the upstream topology and a dense forward."""

    def __init__(self):
        super().__init__()
        self.projects = nn.ModuleList(nn.Conv2d(3, 4, 1) for _ in range(4))
        self.resize_layers = nn.ModuleList(
            [
                nn.ConvTranspose2d(4, 4, 4, stride=4),
                nn.ConvTranspose2d(4, 4, 2, stride=2),
                nn.Identity(),
                nn.Conv2d(4, 4, 3, stride=2, padding=1),
            ]
        )
        self.scratch = nn.Module()
        for i in range(1, 5):
            setattr(self.scratch, f"layer{i}_rn", nn.Conv2d(4, 4, 3, padding=1, bias=False))
            setattr(self.scratch, f"refinenet{i}", _ToyRefine())
        self.scratch.output_conv1 = nn.Conv2d(4, 2, 3, padding=1)
        self.scratch.output_conv2 = nn.Sequential(
            nn.Conv2d(2, 4, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(4, 1, 1),
            nn.ReLU(inplace=True),
            nn.Identity(),
        )
        # Ensure a nondegenerate readout with a response to asymmetric padding.
        first, _, last, _, _ = self.scratch.output_conv2
        with torch.no_grad():
            first.bias.fill_(0.25)
            last.weight.copy_(torch.tensor([0.5, -0.3, 0.4, 0.2]).view(1, 4, 1, 1))
            last.bias.fill_(0.2)

    def forward(self, features, patch_h, patch_w):
        scratch = self.scratch
        pyramid = []
        for i, (tokens, _) in enumerate(features):
            grid = tokens.permute(0, 2, 1).reshape(1, 3, patch_h, patch_w)
            projected = self.resize_layers[i](self.projects[i](grid))
            pyramid.append(getattr(scratch, f"layer{i + 1}_rn")(projected))
        path = scratch.refinenet4(pyramid[3], size=pyramid[2].shape[-2:])
        for stage in (3, 2, 1):
            size = pyramid[stage - 2].shape[-2:] if stage > 1 else None
            path = getattr(scratch, f"refinenet{stage}")(path, pyramid[stage - 1], size=size)
        features = scratch.output_conv1(path)
        upsampled = F.interpolate(features, (14 * patch_h, 14 * patch_w), mode="bilinear", align_corners=True)
        return scratch.output_conv2(upsampled)


class _ToyDepthAnythingV2(nn.Module):
    def __init__(self):
        super().__init__()
        self.pretrained = _ToyDino()
        self.encoder = "vitb"
        self.intermediate_layer_idx = {"vitb": [2, 5, 8, 11]}
        self.depth_head = _ToyDptHead()

    def forward(self, image):
        layers = self.pretrained.get_intermediate_layers(image, [2, 5, 8, 11], return_class_token=True)
        depth = self.depth_head(layers, image.shape[-2] // 14, image.shape[-1] // 14)
        return F.relu(depth).squeeze(1)


def _tiny_segformer():
    config = SegformerConfig(
        num_channels=3,
        hidden_sizes=[4, 6, 8, 10],
        depths=[1, 1, 1, 1],
        sr_ratios=[1, 1, 1, 1],
        num_attention_heads=[1, 2, 2, 2],
        decoder_hidden_size=7,
        num_labels=5,
    )
    model = SegformerForSemanticSegmentation(config).eval()
    head = model.decode_head
    with torch.no_grad():
        for parameter in head.parameters():
            parameter.uniform_(-0.6, 0.6)
        head.batch_norm.running_mean.uniform_(-0.1, 0.1)
        head.batch_norm.running_var.uniform_(0.5, 1.5)
    return model


def _rectangles(height, width):
    w, h = min(width, 7), min(height, 5)
    interior = (width // 2 - w // 2, height // 2 - h // 2, w, h)
    return [
        (width - 1, height - 1, 1, 1),
        (0, 0, w, h),
        (width - w, 0, w, h),
        interior,
        (0, height - h, w, h),
        (width - w, height - h, w, h),
        interior,
    ]


class DecoderTests(unittest.TestCase):
    def assertCropsClose(self, dense, crops, rects):
        self.assertIsInstance(crops, list)
        self.assertEqual(len(crops), len(rects))
        for crop, (x, y, w, h) in zip(crops, rects, strict=True):
            expected = dense[:, :, y : y + h, x : x + w]
            torch.testing.assert_close(crop, expected, rtol=2e-5, atol=2e-6)

    def assertInvalidRects(self, query, model, context):
        height, width = context.native_size
        for rect in (
            (-1, 0, 1, 1),
            (0, -1, 1, 1),
            (width - 1, 0, 2, 1),
            (0, height - 1, 1, 2),
            (0, 0, 0, 1),
            (0, 0, 1, -1),
            (0, 0, 1.0, 1),
            (0, 0, 1),
        ):
            with self.subTest(rect=rect), self.assertRaises(ValueError):
                query(model, context, [rect])

    @torch.inference_mode()
    def test_depth_matches_dense_depth_anything(self):
        with torch.random.fork_rng(devices=[]):
            torch.random.default_generator.manual_seed(406)
            model = _ToyDepthAnythingV2().eval()
            # Native upsampling, gapped decoder support, and both singleton axes.
            for height, width in ((541, 383), (19, 18), (13, 1), (1, 3), (1, 1)):
                with self.subTest(height=height, width=width):
                    field = torch.randn(1, 3, height, width)
                    field[:, 0] += torch.linspace(-2, 2, width)
                    field[:, 1] += torch.linspace(-2, 2, height)[:, None]
                    resized_size = (518, math.ceil(int(width / height * 518) / 14) * 14)
                    image = F.interpolate(field, resized_size, mode="bilinear", align_corners=False)
                    context = depth_context(model, field)
                    torch.testing.assert_close(model.pretrained.image, image, rtol=0, atol=0)
                    reference = F.interpolate(
                        model(image).unsqueeze(1), (height, width), mode="bilinear", align_corners=True
                    )
                    rects = _rectangles(height, width)
                    self.assertCropsClose(reference, depth_regions(model, context, rects), rects)
            self.assertInvalidRects(depth_regions, model, context)

    @torch.inference_mode()
    def test_segformer_matches_huggingface_decode_head(self):
        with torch.random.fork_rng(devices=[]):
            torch.random.default_generator.manual_seed(329)
            model = _tiny_segformer()
            for height, width in ((37, 59), (1, 13), (13, 1), (1, 1)):
                with self.subTest(height=height, width=width):
                    field = torch.randn(1, 3, height, width)
                    outputs = model(field, output_hidden_states=True)
                    reference = F.interpolate(
                        outputs.logits, (height, width), mode="bilinear", align_corners=False
                    )
                    context = seg_context(model, field)
                    self.assertEqual(len(context.hidden_states), 4)
                    for actual, expected in zip(context.hidden_states, outputs.hidden_states, strict=True):
                        torch.testing.assert_close(actual, expected, rtol=0, atol=0)
                    rects = _rectangles(height, width)
                    self.assertCropsClose(reference, seg_regions(model, context, rects), rects)
            self.assertInvalidRects(seg_regions, model, context)


if __name__ == "__main__":
    unittest.main()
