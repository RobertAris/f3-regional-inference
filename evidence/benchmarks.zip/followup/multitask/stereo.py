"""Sparse matching on native, rectified stereo event packets."""

from math import sqrt
from operator import index

import numpy as np
import torch


def _event_rows(events):
    rows = np.asarray(events)
    if rows.shape == (0,):
        return np.empty((0, 4), dtype=np.int64)
    if rows.ndim != 2 or rows.shape[1] != 4:
        raise ValueError("events must have shape [N, 4] for (t, x, y, p)")
    if len(rows) and not np.issubdtype(rows.dtype, np.integer):
        raise ValueError("event rows must be integers")
    return rows.astype(np.int64, copy=False)


def _size(size):
    width, height = map(index, size)
    if min(width, height) <= 0:
        raise ValueError("sensor width and height must be positive")
    return width, height


def _nonnegative(value, name):
    value = index(value)
    if value < 0:
        raise ValueError(f"{name} must be nonnegative")
    return value


def select_points(events, size, count=16, max_disp=48, radius=2):
    """Return up to count native (x, y) centers from left-camera events.

    Split the interior that supports the full search into near-regular cells.
    Each occupied cell contributes its busiest pixel, with ties favoring
    smaller y and then smaller x. Visit cells top to bottom and left to right.
    An empty packet, empty interior, or zero count returns an empty list.
    """
    width, height = _size(size)
    count = _nonnegative(count, "count")
    max_disp = _nonnegative(max_disp, "max_disp")
    radius = _nonnegative(radius, "radius")
    x, y = _event_rows(events)[:, 1:3].T
    x_start = max_disp + radius
    inner_w = width - radius - x_start
    inner_h = height - 2 * radius
    if not count or inner_w <= 0 or inner_h <= 0:
        return []

    inside = (x >= x_start) & (x < width - radius) & (y >= radius) & (y < height - radius)
    if not inside.any():
        return []
    pixels = (y[inside] - radius) * inner_w + (x[inside] - x_start)
    counts = np.bincount(pixels, minlength=inner_h * inner_w).reshape(inner_h, inner_w)

    # Choose near-square cells where possible, using exactly cells total.
    cells = min(count, inner_w * inner_h)
    rows = round(sqrt(cells * inner_h / inner_w))
    min_rows = (cells + inner_w - 1) // inner_w
    rows = min(max(rows, min_rows), inner_h, cells)
    columns, extra = divmod(cells, rows)

    points = []
    for row in range(rows):
        y0, y1 = (row * inner_h // rows, (row + 1) * inner_h // rows)
        cols = columns + (row < extra)
        for col in range(cols):
            x0, x1 = (col * inner_w // cols, (col + 1) * inner_w // cols)
            cell = counts[y0:y1, x0:x1]
            dy, dx = divmod(int(cell.argmax()), x1 - x0)
            if cell[dy, dx]:
                points.append((x_start + x0 + dx, radius + y0 + dy))
    return points


def boxes(points, max_disp=48, radius=2):
    """Return left patch and right search xywh lists in input point order.

    Each center must support its full search. The right rectangle starts at
    disparity max_disp and ends at the right edge of the zero-disparity patch.
    """
    max_disp = _nonnegative(max_disp, "max_disp")
    radius = _nonnegative(radius, "radius")
    side = 2 * radius + 1
    left, right = [], []
    for x, y in points:
        x0, y0 = index(x) - radius, index(y) - radius
        left.append((x0, y0, side, side))
        right.append((x0 - max_disp, y0, side + max_disp, side))
    return left, right


def _unit_centered(values):
    # Reference subtraction keeps finite constant patches exactly zero.
    values = values - values[..., :1]
    values = values - values.mean(dim=-1, keepdim=True)
    norm = torch.linalg.vector_norm(values, dim=-1, keepdim=True)
    return values / torch.where(norm > 0, norm, 1.0)


@torch.no_grad()
def match(left_patches, right_patches, max_disp=48):
    """Return one integer disparity per pair of width-first patches.

    Input shapes are [N, C, W, H] and [N, C, W + max_disp, H]. Use float32
    ZNCC with one mean over channels and space per patch. A constant patch
    gives zero correlation. Equal scores favor the smallest disparity. The
    result is a torch.long tensor of shape [N] on the input device.
    """
    max_disp = _nonnegative(max_disp, "max_disp")
    if left_patches.ndim != 4:
        raise ValueError("left patches must have shape [N, C, W, H]")
    n, channels, width, height = left_patches.shape
    if min(channels, width, height) <= 0:
        raise ValueError("patch channel count, width, and height must be positive")
    if right_patches.shape != (n, channels, width + max_disp, height):
        raise ValueError("right patches must have shape [N, C, W + max_disp, H]")
    if left_patches.device != right_patches.device:
        raise ValueError("patches must be on the same device")
    if not n:
        return torch.empty(0, dtype=torch.long, device=left_patches.device)

    left = _unit_centered(left_patches.float().flatten(1))
    windows = right_patches.float().unfold(dimension=2, size=width, step=1)
    windows = windows.permute(0, 2, 1, 4, 3).flatten(2)
    right = _unit_centered(windows)
    scores = (left[:, None, :] * right).sum(dim=-1)
    # Leftmost window has largest disparity. argmax returns the first tie.
    return scores.flip(dims=(1,)).argmax(dim=1)


def raw_field(events, size):
    """Return a CPU float32 event descriptor with shape [1, 12, W, H].

    Use the F3 clock: microseconds in [-20000, 0) relative to a shared packet
    end. Channels 0–7 are log1p counts in four 5 ms bins, oldest first, with
    nonpositive then positive polarity in each bin. Channels 8–11 are the
    exponential recency of the latest event per pixel and polarity, in the
    same polarity order for 1 ms and then 5 ms. Missing data contributes zero.
    Events outside the sensor are ignored. Event order is immaterial.
    """
    width, height = _size(size)
    t, x, y, p = _event_rows(events).T
    inside = (x >= 0) & (x < width) & (y >= 0) & (y < height)
    t, x, y, p = t[inside], x[inside], y[inside], p[inside]
    if np.any((t < -20_000) | (t >= 0)):
        raise ValueError("event times must be in [-20000, 0) microseconds")

    field = np.zeros((12, width, height), dtype=np.float32)
    if len(t):
        polarity = (p > 0).astype(np.intp)
        time_bin = (t + 20_000) // 5_000
        counts = field[:8]
        np.add.at(counts, (2 * time_bin + polarity, x, y), 1)
        np.log1p(counts, out=counts)

        latest = np.full((2, width, height), -np.inf, dtype=np.float32)
        np.maximum.at(latest, (polarity, x, y), t)
        np.exp(latest / 1_000, out=field[8:10])
        np.exp(latest / 5_000, out=field[10:12])
    return torch.from_numpy(field[None])
