"""Run a locked panel on local data with the released weights and an isolated output directory."""

import argparse
import json
import shutil
import tempfile
import time
from pathlib import Path
import subprocess
import sys

from followup.multitask.data import DEV
from query_f3.binding import ROOT

CASES = {
    "mvsec": "indoor_flying2",
    "dsec": "zurich_city_00_a",
    "m3ed": "car_urban_night_rittenhouse",
}
GLOBAL = [
    "dense",
    "sdpa",
    "mixed",
    "half",
    "folded",
    "folded-half",
    "exact-eager",
    "batched",
    "batched-half",
    "ordinary",
    "crop-input",
    "hybrid-batched",
]


def commands(group, out):
    if group == "features":
        for domain in CASES:
            yield (
                "feature_bench",
                ["--task", "features", "--domain", domain, "--out", out / "feature"],
            )
    elif group == "stereo":
        for domain in ("mvsec", "dsec"):
            yield (
                "feature_bench",
                [
                    "--task",
                    "stereo",
                    "--count",
                    64,
                    "--domain",
                    domain,
                    "--out",
                    out / "stereo",
                ],
            )
    elif group == "occupancy":
        yield "occupancy", ["--out", out / "occupancy"]
    elif group == "global":
        for task, domain in (
            ("depth", "mvsec"),
            ("depth", "m3ed"),
            ("semantics", "human"),
            ("semantics", "day"),
        ):
            roster = json.loads(Path(__file__).with_name("packets.json").read_text())[domain]
            for name in sorted({f.rsplit("-", 1)[0] for f in roster} - {DEV[domain]}):
                yield (
                    "bench",
                    [
                        "--task",
                        task,
                        "--domain",
                        domain,
                        "--lookup",
                        "--modes",
                        *GLOBAL,
                        "--only-recording",
                        name,
                        "--out",
                        out / "global",
                    ],
                )
    elif group in ("crossover", "field-grid"):
        for domain, name in CASES.items():
            opts = [
                "--task",
                "features",
                "--domain",
                domain,
                "--recording",
                name,
                "--one",
            ]
            yield (
                "feature_bench",
                [
                    *opts,
                    "--sweep",
                    "--policies",
                    "regional-3-2",
                    "merged-3-2",
                    "--out",
                    out / "crossover",
                ],
            )
            yield (
                "feature_bench",
                [
                    *opts,
                    "--lookup",
                    "--policies",
                    "regional-3-2",
                    "regional-5-2",
                    "--out",
                    out / "lookup",
                ],
            )
        for keep in ("0.1", "0.5", "1"):
            yield (
                "feature_bench",
                [
                    "--task",
                    "features",
                    "--domain",
                    "dsec",
                    "--recording",
                    CASES["dsec"],
                    "--one",
                    "--keep",
                    keep,
                    "--policies",
                    "regional-3-2",
                    "--out",
                    out / ("density-" + keep),
                ],
            )
    if group in ("head-grid", "crossover"):
        for task, domain in (
            ("depth", "mvsec"),
            ("depth", "m3ed"),
            ("semantics", "dsec"),
        ):
            fraction = 5 if domain == "m3ed" else 50
            yield (
                "head_grid",
                [
                    "--task",
                    task,
                    "--domain",
                    domain,
                    "--packet",
                    f"{CASES[domain]}-{fraction}",
                    "--repeats",
                    3,
                    "--lookup",
                    "--out",
                    out / "head-grid" / f"{task}-{domain}.json",
                ],
            )
    elif group == "hardware":
        for dev in ("cpu", "mps"):
            for task in ("features", "depth", "semantics"):
                for mode in (
                    "dense",
                    "batched" if task in ("depth", "semantics") else "regional",
                ):
                    yield (
                        "hardware",
                        [
                            "--device",
                            dev,
                            "--task",
                            "features",
                            "--tasks",
                            task,
                            "--strategy",
                            mode,
                            "--domain",
                            "mvsec",
                            "--packet",
                            "indoor_flying2-50",
                            "--repeats",
                            3,
                            "--out",
                            out / "hardware" / f"{dev}-{task}-{mode}.json",
                        ],
                    )
        for mode in ("dense", "batched", "separate-batched"):
            yield (
                "hardware",
                [
                    "--task",
                    "features",
                    "--tasks",
                    "depth",
                    "semantics",
                    "occupancy",
                    "features",
                    "flow",
                    "--strategy",
                    mode,
                    "--domain",
                    "dsec",
                    "--packet",
                    "zurich_city_00_a-50",
                    "--repeats",
                    5,
                    "--out",
                    out / "hardware" / f"joint-{mode}.json",
                ],
            )
        for task in ("flow", "occupancy"):
            for mode in ("regional", "dense"):
                yield (
                    "hardware",
                    [
                        "--task",
                        "features",
                        "--tasks",
                        task,
                        "--strategy",
                        mode,
                        "--domain",
                        "mvsec",
                        "--packet",
                        "indoor_flying2-50",
                        "--repeats",
                        5,
                        "--out",
                        out / "hardware" / f"mps-{task}-{mode}.json",
                    ],
                )
        for mode in ("dense", "half", "regional-3-2", "raw", "raw-sgbm"):
            yield (
                "stereo_memory",
                [
                    "--task",
                    "stereo",
                    "--method",
                    mode,
                    "--count",
                    64,
                    "--domain",
                    "dsec",
                    "--packet",
                    "zurich_city_00_a-50",
                    "--repeats",
                    5,
                    "--out",
                    out / "stereo-memory" / f"stereo-{mode}.json",
                ],
            )


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "group",
        choices=(
            "features",
            "stereo",
            "occupancy",
            "global",
            "crossover",
            "head-grid",
            "field-grid",
            "hardware",
        ),
    )
    p.add_argument(
        "--measurement-root", type=Path, default=ROOT, help="Source checkout for the actual benchmark process"
    )
    p.add_argument(
        "--resume",
        action="store_true",
        help="Reuse complete recording or hardware records from that revision",
    )
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--data", type=Path, required=True)
    p.add_argument("--weights", type=Path, required=True)
    p.add_argument("--upstream", type=Path, required=True)
    p.add_argument("--models", type=Path, required=True)
    p.add_argument("--flow-dir", type=Path, required=True)
    p.add_argument(
        "--reserve",
        action="store_true",
        help="Acquire the local AI Lab compute slot for each measurement process",
    )
    args = p.parse_args()
    checkout = args.measurement_root.resolve()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=checkout, text=True).strip()
    for module, opts in commands(args.group, args.output.resolve()):
        argv = [
            sys.executable,
            "-u",
            "-m",
            "followup.multitask." + module,
            "--split",
            "evaluation",
            "--data",
            str(args.data.resolve()),
            "--upstream",
            str(args.upstream.resolve()),
            "--weights",
            str(args.weights.resolve()),
        ]
        if module != "occupancy":
            argv.extend(["--models", str(args.models.resolve())])
        if module == "hardware":
            argv.extend(["--flow-dir", str(args.flow_dir.resolve())])
        argv.extend(map(str, opts))
        destination = Path(argv[argv.index("--out") + 1])
        if args.resume:
            existing = [destination] if destination.suffix == ".json" else []
            if "--only-recording" in argv:
                rec = argv[argv.index("--only-recording") + 1]
                domain = argv[argv.index("--domain") + 1]
                task = argv[argv.index("--task") + 1]
                roster = json.loads((checkout / "followup/multitask/packets.json").read_text())[domain]
                existing = [
                    destination / f"{task}-{domain}-{Path(name).stem}.json"
                    for name in roster
                    if name.rsplit("-", 1)[0] == rec
                ]
            if existing and all(f.exists() for f in existing):
                if any(json.loads(f.read_bytes())["provenance"]["revision"] != revision for f in existing):
                    raise ValueError("Saved observations came from a different revision")
                continue
        if not args.reserve:
            subprocess.run(argv, check=True, cwd=checkout)
            continue
        destination = Path(argv[argv.index("--out") + 1])
        destination.parent.mkdir(parents=True, exist_ok=True)
        while True:
            with tempfile.TemporaryDirectory(dir=destination.parent, prefix=".pending-") as staging:
                temporary = Path(staging) / destination.name
                argv[argv.index("--out") + 1] = str(temporary)
                marker = Path(staging) / ".busy"
                guarded = [sys.executable, str(Path(__file__).with_name("quiet.py")), str(marker), *argv]
                outcome = subprocess.run(["ailab", "compute", "--wait", "3600", "--", *guarded], cwd=checkout)
                if outcome.returncode == 0:
                    for f in Path(staging).rglob("*.json"):
                        target = destination.parent / f.relative_to(staging)
                        target.parent.mkdir(parents=True, exist_ok=True)
                        if target.exists():
                            raise FileExistsError(target)
                        shutil.move(f, target)
                    break
                if not marker.exists():
                    outcome.check_returncode()
            time.sleep(30)


if __name__ == "__main__":
    main()
