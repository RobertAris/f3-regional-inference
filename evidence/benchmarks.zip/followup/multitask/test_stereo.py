"""CPU checks for sparse rectified stereo matching."""

import inspect
import math
import unittest

import numpy as np
import torch

from followup.multitask.stereo import boxes, match, raw_field, select_points


def _gather(field, rects):
    return torch.cat([field[:, :, x:x + w, y:y + h] for x, y, w, h in rects])


class PointTests(unittest.TestCase):
    def test_selection_uses_only_left_event_pixel_counts(self):
        self.assertEqual(
            tuple(inspect.signature(select_points).parameters),
            ("events", "size", "count", "max_disp", "radius"),
        )
        rows = []
        for x, y, hits in [(9, 2, 2), (6, 3, 3), (8, 2, 3), (7, 2, 3), (14, 4, 1)]:
            rows.extend([(-10, x, y, 1)] * hits)
        events = np.asarray(rows)
        changed = events[::-1].copy()
        changed[:, 0] = -2_000 - np.arange(len(changed))
        changed[:, 3] = np.arange(len(changed)) % 2
        for packet in (events, changed):
            self.assertEqual(
                select_points(packet, (21, 9), count=2, max_disp=4),
                [(7, 2), (14, 4)],
            )

    def test_default_border_support_and_native_rectangles(self):
        size = (100, 13)
        centers = [(50, 2), (97, 10)]
        outside = [(49, 2), (98, 10), (50, 1), (97, 11), (100, 10), (-1, 2)]
        rows = [(-1, x, y, 1) for x, y in centers + outside * 4]
        points = select_points(rows, size)
        self.assertEqual(points, centers)
        self.assertEqual(
            boxes(points),
            ([(48, 0, 5, 5), (95, 8, 5, 5)], [(0, 0, 53, 5), (47, 8, 53, 5)]),
        )
        self.assertEqual(
            boxes([(3, 0)], max_disp=3, radius=0), ([(3, 0, 1, 1)], [(0, 0, 4, 1)])
        )

    def test_empty_sparse_and_cell_cap(self):
        events = np.array([[-1, 50, 2, 1], [-8, 50, 2, -1]])
        self.assertEqual(select_points(np.empty((0, 4), dtype=int), (53, 5)), [])
        self.assertEqual(select_points(events, (52, 5)), [])
        self.assertEqual(select_points(events, (53, 4)), [])
        self.assertEqual(select_points(events, (53, 5), count=0), [])
        self.assertEqual(select_points(events, (53, 5)), [(50, 2)])
        self.assertEqual(boxes([]), ([], []))

        dense_events = [(-1, x, y, 1) for y in range(11) for x in range(23)]
        points = select_points(dense_events, (23, 11), count=7, max_disp=3, radius=1)
        self.assertEqual(len(points), 7)
        self.assertEqual(len(set(points)), 7)


class MatchTests(unittest.TestCase):
    def test_dense_gathers_and_regional_patches_recover_same_shift(self):
        generator = torch.Generator().manual_seed(18)
        left = torch.randn(1, 4, 151, 19, generator=generator)
        right = torch.zeros_like(left)
        disparity = 7
        right[:, :, :-disparity, :] = left[:, :, disparity:, :]
        left_rects, right_rects = boxes([(55, 3), (94, 8), (141, 15)])
        expected = torch.full((3,), disparity)
        regional_left = _gather(left, left_rects)
        self.assertTrue(torch.equal(match(regional_left, _gather(right, right_rects)), expected))

        regional_right = torch.randn(3, 4, 53, 5, generator=generator)
        offset = 48 - disparity
        regional_right[:, :, offset:offset + 5, :] = 2 * regional_left + 3
        self.assertTrue(torch.equal(match(regional_left, regional_right), expected))

    def test_nonsquare_width_first_patches_cover_both_disparity_endpoints(self):
        generator = torch.Generator().manual_seed(27)
        left = torch.randn(3, 2, 3, 4, generator=generator).transpose(2, 3).half()
        right = torch.randn(3, 2, 13, 3, generator=generator).half()
        disparities = [0, 5, 9]
        for i, disparity in enumerate(disparities):
            start = 9 - disparity
            right[i, :, start:start + 4, :] = left[i]
        result = match(left, right, max_disp=9)
        self.assertEqual(result.tolist(), disparities)
        self.assertEqual(result.dtype, torch.long)
        self.assertEqual(result.device, left.device)

    def test_constant_patches_and_nonzero_ties(self):
        zeros = torch.zeros(2, 3, 5, 5)
        self.assertEqual(match(zeros, torch.zeros(2, 3, 53, 5)).tolist(), [0, 0])
        varying = torch.randn(1, 2, 10, 2, generator=torch.Generator().manual_seed(9))
        constant_left = torch.full((1, 2, 3, 2), 0.1)
        constant_right = torch.full_like(varying, 0.1)
        self.assertEqual(match(constant_left, varying, max_disp=7).tolist(), [0])
        self.assertEqual(match(varying[:, :, :3, :], constant_right, max_disp=7).tolist(), [0])

        left = torch.tensor([[[[-1.0], [2.0], [4.0]]]])
        right = torch.zeros(1, 1, 10, 1)
        right[:, :, 1:4, :] = left
        right[:, :, 6:9, :] = left
        self.assertEqual(match(left, right, max_disp=7).tolist(), [1])

    def test_empty_batch_zero_range_and_shape_validation(self):
        empty = match(torch.empty(0, 3, 5, 5), torch.empty(0, 3, 53, 5))
        self.assertEqual(tuple(empty.shape), (0,))
        self.assertEqual(empty.dtype, torch.long)
        patch = torch.ones(1, 1, 1, 1)
        self.assertEqual(match(patch, patch, max_disp=0).tolist(), [0])
        with self.assertRaises(ValueError):
            match(patch, torch.ones(1, 1, 1, 3), max_disp=2)


class RawFieldTests(unittest.TestCase):
    def test_time_polarity_channels_and_non_square_coordinates(self):
        events = np.array([
            [-1, 5, 2, 1], [-20_000, 5, 2, 0], [-10_000, 5, 2, -1],
            [-15_000, 5, 2, 1], [-19_999, 5, 2, -1], [-17_500, 5, 2, 1],
            [-5_000, 5, 2, 0], [-2_000, 3, 1, 1], [-1, 7, 1, 1],
        ])
        field = raw_field(events, (7, 4))
        self.assertEqual(tuple(field.shape), (1, 12, 7, 4))
        self.assertEqual(field.dtype, torch.float32)
        self.assertEqual(field.device.type, "cpu")
        expected = torch.zeros_like(field)
        ln2 = math.log(2)
        expected[0, :, 5, 2] = torch.tensor([
            math.log(3), ln2, 0, ln2, ln2, 0, ln2, ln2,
            math.exp(-5), math.exp(-0.001), math.exp(-1), math.exp(-0.0002),
        ])
        expected[0, [7, 9, 11], 3, 1] = torch.tensor([ln2, math.exp(-2), math.exp(-0.4)])
        torch.testing.assert_close(field, expected)
        self.assertTrue(torch.equal(field, raw_field(events[::-1], (7, 4))))

    def test_empty_field_and_invalid_clock(self):
        self.assertTrue(torch.equal(raw_field([], (3, 2)), torch.zeros(1, 12, 3, 2)))
        for timestamp in (-20_001, 0):
            with self.subTest(timestamp=timestamp), self.assertRaises(ValueError):
                raw_field([[timestamp, 0, 0, 1]], (3, 2))

    def test_raw_fields_use_the_same_rectangles_and_matcher(self):
        size = (80, 12)
        left = np.array([
            [-12_000, 53, 4, -1], [-2_200, 54, 5, 1],
            [-3_300, 54, 5, 1], [-7_400, 56, 6, 0],
        ])
        right = left.copy()
        right[:, 1] -= 9
        points = select_points(left, size, count=1)
        self.assertEqual(points, [(54, 5)])
        left_rects, right_rects = boxes(points)
        result = match(
            _gather(raw_field(left, size), left_rects),
            _gather(raw_field(right, size), right_rects),
        )
        self.assertEqual(result.tolist(), [9])


if __name__ == "__main__":
    unittest.main()
