"""CPU checks for the packed regional decoder tails."""

import math
import unittest
from unittest.mock import patch

import torch
from torch.nn import functional as F
from torch.utils._python_dispatch import TorchDispatchMode

from query_f3.multitask.batched_decoders import fast_depth_regions, fast_seg_regions
from query_f3.multitask.decoders import (
    DepthContext,
    SegContext,
    depth_context,
    depth_regions,
    seg_context,
    seg_regions,
)
from query_f3.multitask.fusion import FoldedSegformer

from followup.multitask.test_decoders import _rectangles, _tiny_segformer, _ToyDepthAnythingV2


def _queries(size):
    height, width = size
    rects = _rectangles(height, width)
    rects.insert(3, (0, 0, min(3, width), min(2, height)))
    rects.append((0, height - 1, 1, 1))
    return rects


class _HalfPromotions(TorchDispatchMode):
    def __init__(self):
        self.shapes = []

    def __torch_dispatch__(self, func, types, args=(), kwargs=None):
        kwargs = kwargs or {}
        # Inference mode exposes the cast as aten.to.dtype.
        if func == torch.ops.aten.to.dtype:
            dtype = args[1]
        elif func == torch.ops.aten._to_copy.default:
            dtype = kwargs.get("dtype")
        else:
            dtype = None
        if dtype == torch.float32 and args[0].dtype == torch.float16:
            self.shapes.append(args[0].shape)
        return func(*args, **kwargs)


class BatchedDecoderTests(unittest.TestCase):
    def setUp(self):
        self.enterContext(torch.random.fork_rng(devices=[]))

    def assertCropsClose(self, dense, regional, crops, rects):
        self.assertIsInstance(crops, list)
        for crop, old, (x, y, w, h) in zip(crops, regional, rects, strict=True):
            self.assertEqual(crop.shape, (1, dense.shape[1], h, w))
            torch.testing.assert_close(crop, dense[..., y : y + h, x : x + w], rtol=2e-5, atol=2e-6)
            torch.testing.assert_close(crop, old, rtol=2e-5, atol=2e-6)

    @torch.inference_mode()
    def test_depth_matches_dense_and_regional_tails(self):
        torch.random.default_generator.manual_seed(406)
        model = _ToyDepthAnythingV2().eval()
        for height, width in ((541, 383), (19, 18)):
            with self.subTest(height=height, width=width):
                size = (height, width)
                field = torch.randn(1, 3, height, width)
                field[:, 0] += torch.linspace(-2, 2, width)
                field[:, 1] += torch.linspace(-2, 2, height)[:, None]
                decoder_size = (518, math.ceil(int(width / height * 518) / 14) * 14)
                image = F.interpolate(field, decoder_size, mode="bilinear", align_corners=False)
                dense = F.interpolate(model(image).unsqueeze(1), size, mode="bilinear", align_corners=True)
                context = depth_context(model, field)
                rects = _queries(size)
                crops = fast_depth_regions(model, context, iter(rects))
                old = depth_regions(model, context, rects)
                self.assertCropsClose(dense, old, crops, rects)

    @torch.inference_mode()
    def test_hd_subpixel_coordinates(self):
        model = _ToyDepthAnythingV2().eval()
        tail = model.depth_head.scratch.output_conv2
        for conv in (tail[0], tail[2]):
            conv.weight.zero_()
            conv.bias.zero_()
        tail[0].weight[0, 0, 1, 1] = 1
        tail[2].weight[0, 0, 0, 0] = 1
        features = torch.zeros(1, 2, 296, 528)
        features[0, 0, :, 1::2] = 1
        features[0, 0, 1::2] = 1 - features[0, 0, 1::2]
        context = DepthContext(features, (720, 1280), (518, 924))
        enlarged = F.interpolate(features, context.decoder_size, mode="bilinear", align_corners=True)
        native = F.interpolate(tail(enlarged), context.native_size, mode="bilinear", align_corners=True)
        rects = [((37 * i + 1137) % 1249, (79 * i + 590) % 689, 32, 32) for i in range(32)]
        rects.extend([(0, 0, 256, 256), (0, 0, 720, 720)])
        for (x, y, w, h), result in zip(rects, fast_depth_regions(model, context, rects), strict=True):
            torch.testing.assert_close(result, native[..., y : y + h, x : x + w], rtol=2e-5, atol=2e-6)

    @torch.inference_mode()
    def test_depth_singleton_axes_and_physical_padding(self):
        torch.random.default_generator.manual_seed(406)
        model = _ToyDepthAnythingV2().eval()
        tail = model.depth_head.scratch.output_conv2
        for size, decoder_size, feature_size in (
            ((1, 13), (1, 9), (1, 5)),
            ((13, 1), (9, 1), (5, 1)),
            ((1, 1), (9, 7), (5, 3)),
        ):
            with self.subTest(size=size, decoder_size=decoder_size):
                features = torch.randn(1, 2, *feature_size)
                context = DepthContext(features, size, decoder_size)
                upsampled = F.interpolate(features, decoder_size, mode="bilinear", align_corners=True)
                dense = F.interpolate(tail(upsampled).relu(), size, mode="bilinear", align_corners=True)
                rects = _queries(size)
                crops = fast_depth_regions(model, context, rects)
                self.assertCropsClose(dense, depth_regions(model, context, rects), crops, rects)

    @torch.inference_mode()
    def test_half_depth_preserves_subpixel_coordinates(self):
        model = _ToyDepthAnythingV2().eval().half()
        tail = model.depth_head.scratch.output_conv2
        # Pass one channel through the tail so coordinate drift remains visible.
        first, _, last, _, _ = tail
        first.weight.zero_()
        first.weight[0, 0, 1, 1] = 1
        first.bias.zero_()
        last.weight.zero_()
        last.weight[0, 0, 0, 0] = 1
        last.bias.zero_()
        features = torch.zeros(1, 2, 1, 1025, dtype=torch.float16)
        features[:, 0, :, ::2] = 1
        context = DepthContext(features, (1, 2049), (1, 1537))
        upsampled = F.interpolate(features, context.decoder_size, mode="bilinear", align_corners=True)
        dense = F.interpolate(tail(upsampled), context.native_size, mode="bilinear", align_corners=True)
        rects = [(2000, 0, 11, 1), (2038, 0, 11, 1)]
        for crop, (x, _, w, _) in zip(fast_depth_regions(model, context, rects), rects, strict=True):
            torch.testing.assert_close(
                crop, dense[..., x : x + w], rtol=0, atol=torch.finfo(torch.float16).eps
            )

    @torch.inference_mode()
    def test_seg_matches_dense_and_regional_tails(self):
        torch.random.default_generator.manual_seed(329)
        model = _tiny_segformer()
        for height, width in ((37, 59), (1, 13), (13, 1), (1, 1)):
            with self.subTest(height=height, width=width):
                size = (height, width)
                field = torch.randn(1, 3, height, width)
                context = seg_context(model, field)
                logits = model.decode_head(context.hidden_states)
                dense = F.interpolate(logits, size, mode="bilinear", align_corners=False)
                rects = _queries(size)
                crops = fast_seg_regions(model, context, rects)
                self.assertCropsClose(dense, seg_regions(model, context, rects), crops, rects)

    @torch.inference_mode()
    def test_mixed_size_half_queries_promote_only_regional_support(self):
        torch.random.default_generator.manual_seed(157)
        size = (129, 193)
        rects = [
            (189, 126, 4, 3),
            (0, 0, 2, 1),
            (81, 65, 4, 3),
            (0, 0, 4, 3),
            (189, 126, 4, 3),
        ]
        depth = _ToyDepthAnythingV2().eval().half()
        depth_ctx = DepthContext(torch.randn(1, 2, 64, 96, dtype=torch.float16), size, (127, 191))
        upsampled = F.interpolate(
            depth_ctx.features,
            depth_ctx.decoder_size,
            mode="bilinear",
            align_corners=True,
        )
        depth_logits = depth.depth_head.scratch.output_conv2(upsampled).relu()
        depth_dense = F.interpolate(depth_logits, size, mode="bilinear", align_corners=True)

        seg = _tiny_segformer().half()
        hidden_shapes = ((4, 33, 49), (6, 17, 25), (8, 9, 13), (10, 5, 7))
        hidden_states = tuple(torch.randn(1, *shape, dtype=torch.float16) for shape in hidden_shapes)
        seg_ctx = SegContext(hidden_states, size)
        seg.folded = FoldedSegformer(seg)
        seg_dense = F.interpolate(
            seg.decode_head(seg_ctx.hidden_states),
            size,
            mode="bilinear",
            align_corners=False,
        )

        tolerance = torch.finfo(torch.float16).eps
        # Each group has at most three unique queries. The largest decoder
        # tiles have at most 6x7 sites with the depth halo and 3x3 for segmentation.
        for query, model, ctx, dense, max_area in (
            (fast_depth_regions, depth, depth_ctx, depth_dense, 6 * 7),
            (fast_seg_regions, seg, seg_ctx, seg_dense, 3 * 3),
        ):
            with self.subTest(query=query.__name__):
                with _HalfPromotions() as promotions:
                    crops = query(model, ctx, rects)
                self.assertTrue(promotions.shapes)
                for shape in promotions.shapes:
                    batch, _, height, width = shape
                    self.assertLessEqual(batch * height * width, 3 * max_area, f"promoted {tuple(shape)}")
                for crop, (x, y, w, h) in zip(crops, rects, strict=True):
                    torch.testing.assert_close(
                        crop,
                        dense[..., y : y + h, x : x + w],
                        rtol=tolerance,
                        atol=tolerance,
                    )

    @torch.inference_mode()
    def test_same_shape_queries_sample_packed_regional_tiles(self):
        torch.random.default_generator.manual_seed(329)
        size = (40, 60)
        rects = [(1, 1, 3, 2), (45, 28, 3, 2), (1, 1, 3, 2)]
        depth = _ToyDepthAnythingV2().eval()
        depth_ctx = DepthContext(torch.randn(1, 2, 9, 13), size, (20, 30))
        seg = _tiny_segformer()
        seg_ctx = seg_context(seg, torch.randn(1, 3, *size))
        seg.folded = FoldedSegformer(seg)

        with patch(
            "query_f3.multitask.batched_decoders.FoldedSegformer",
            side_effect=AssertionError("query rebuilt the precomputed fold"),
        ):
            for query, model, ctx, sources, tile_size, halo in (
                (
                    fast_depth_regions,
                    depth,
                    depth_ctx,
                    (depth_ctx.features,),
                    (3, 3),
                    1,
                ),
                (fast_seg_regions, seg, seg_ctx, seg_ctx.hidden_states, (2, 3), 0),
            ):
                with self.subTest(query=query.__name__):
                    with patch.object(F, "grid_sample", wraps=F.grid_sample) as sample:
                        crops = query(model, ctx, rects)
                    tile_h, tile_w = tile_size
                    calls = sample.call_args_list
                    self.assertEqual(len(calls), len(sources) + 1)
                    for call, source in zip(calls[:-1], sources, strict=True):
                        source_tiles = call.args[0]
                        self.assertEqual(source_tiles.shape[:2], (1, source.shape[1]))
                        self.assertLessEqual(
                            source_tiles.shape[2],
                            2 * min(source.shape[2], tile_h + 2 * halo + 1),
                        )
                        self.assertLessEqual(
                            source_tiles.shape[3],
                            min(source.shape[3], tile_w + 2 * halo + 1),
                        )
                        self.assertEqual(
                            call.args[1].shape,
                            (1, 4 * (tile_h + 2 * halo), 2 * (tile_w + 2 * halo), 2),
                        )
                    self.assertEqual(calls[-1].args[0].shape[-2:], tile_size)
                    self.assertEqual(calls[-1].args[1].shape, (2, 4, 6, 2))
                    for rect, crop in zip(rects, crops, strict=True):
                        torch.testing.assert_close(crop, query(model, ctx, [rect])[0], rtol=2e-5, atol=2e-6)


if __name__ == "__main__":
    unittest.main()
