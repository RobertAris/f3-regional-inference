"""Validated byte access to immutable, ZIP_STORED public dataset members."""

from collections import OrderedDict
import io, re, struct, time, zipfile
import requests


class Source:
    def __init__(self, url, size, etag=None, modified=None):
        self.url, self.size, self.etag, self.modified = url, size, etag, modified
        self.session = requests.Session()
        self.bytes = 0
        self.requests = 0

    def fetch(self, start, length):
        if length == 0:
            return b""
        if start < 0 or length < 0 or start + length > self.size or length > 32 * 1024**2:
            raise ValueError("invalid bounded byte range")
        end = start + length - 1
        expected = f"bytes {start}-{end}/{self.size}"
        hdr = {"Range": f"bytes={start}-{end}", "Accept-Encoding": "identity"}
        if self.etag:
            hdr["If-Match"] = self.etag
        for attempt in range(9):
            try:
                with self.session.get(self.url, headers=hdr, timeout=(15, 65), stream=True) as r:
                    if r.status_code == 429 or 500 <= r.status_code < 600:
                        wait = r.headers.get("Retry-After", "")
                        raise requests.RequestException(
                            "retry " + str(min(90, int(wait)) if wait.isdigit() else 2 ** min(attempt, 5))
                        )
                    if r.status_code != 206 or r.headers.get("Content-Range") != expected:
                        raise ValueError(
                            f"invalid range {self.url} {start} {r.status_code} {r.headers.get('Content-Range')}"
                        )
                    if self.etag and r.headers.get("ETag") != self.etag:
                        raise ValueError("ETag changed")
                    if (
                        self.modified
                        and r.headers.get("Last-Modified")
                        and r.headers["Last-Modified"] != self.modified
                    ):
                        raise ValueError("source changed")
                    data = r.raw.read(length + 1)
                    if len(data) != length:
                        raise requests.RequestException("short range")
                    self.bytes += length
                    self.requests += 1
                    return data
            except (requests.RequestException, TimeoutError, OSError) as e:
                if attempt == 8:
                    raise
                wait = str(e).split()
                time.sleep(
                    float(wait[-1]) if len(wait) == 2 and wait[0] == "retry" else min(30, 2**attempt)
                )
        raise RuntimeError


class ByteFile(io.RawIOBase):
    def __init__(self, source, start=0, size=None, block=65536, max_blocks=96):
        self.source = source
        self.base = int(start)
        self.size = source.size - start if size is None else int(size)
        self.pos = 0
        self.block = block
        self.cache = OrderedDict()
        self.max_blocks = max_blocks

    def readable(self):
        return True

    def seekable(self):
        return True

    def tell(self):
        return self.pos

    def seek(self, offset, whence=0):
        dest = (0, self.pos, self.size)[whence] + int(offset)
        if dest < 0:
            raise ValueError("negative seek")
        self.pos = dest
        return dest

    def read(self, n=-1):
        count = max(0, self.size - self.pos) if n < 0 else max(0, min(n, self.size - self.pos))
        if count > 64 * 1024**2:
            raise ValueError("unbounded file read")
        if count >= 2 * self.block and count <= 16 * 1024**2:
            data = self.source.fetch(self.base + self.pos, count)
            self.pos += len(data)
            return data
        result = bytearray()
        while count:
            b, off = divmod(self.pos, self.block)
            if b not in self.cache:
                self.cache[b] = self.source.fetch(
                    self.base + b * self.block, min(self.block, self.size - b * self.block)
                )
                if len(self.cache) > self.max_blocks:
                    self.cache.popitem(last=False)
            else:
                self.cache.move_to_end(b)
            data = self.cache[b][off : off + count]
            if not data:
                raise IOError("unexpected EOF")
            result.extend(data)
            self.pos += len(data)
            count -= len(data)
        return bytes(result)

    def readinto(self, b):
        view = memoryview(b).cast("B")
        d = self.read(len(view))
        view[: len(d)] = d
        return len(d)


def directory(source):
    with zipfile.ZipFile(ByteFile(source)) as z:
        return {obj.filename: obj for obj in z.infolist()}


def member(source, info, block=65536):
    if info.compress_type != zipfile.ZIP_STORED or info.compress_size != info.file_size:
        raise ValueError(info.filename)
    header = source.fetch(info.header_offset, 30)
    if header[:4] != b"PK\x03\x04":
        raise ValueError("ZIP local header")
    namesize, extra = struct.unpack_from("<HH", header, 26)
    name = source.fetch(info.header_offset + 30, namesize)
    if name.decode("utf8") != info.filename:
        raise ValueError("ZIP directory/local disagreement")
    base = info.header_offset + 30 + namesize + extra
    return ByteFile(source, base, info.file_size, block), dict(
        member=info.filename, crc32=info.CRC, size=info.file_size, offset=base
    )
