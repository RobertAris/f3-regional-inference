"""Content pin for a benchmark and the native models it evaluates."""

import hashlib
import json
import subprocess
from functools import lru_cache
from pathlib import Path

from query_f3.binding import ROOT, digest
from query_f3.inference.loaders.published_f3 import CHECKPOINT_SHA256
from query_f3.multitask.models import HASHES


@lru_cache(None)
def pin(upstream):
    files = sorted(
        p
        for folder in ("query_f3", "followup/multitask")
        for p in (ROOT / folder).rglob("*.py")
        if not p.name.startswith("test_") and p.name not in ("report.py", "replay.py")
    )
    files += [
        ROOT / "followup/multitask" / s for s in ("protocol.md", "packets.json", "occupancy-packets.json")
    ]
    data = {str(p.relative_to(ROOT)): digest(p) for p in files}
    model_files = [
        upstream / "hubconf.py",
        upstream / "confs/ff/modeloptions/1280x720x20_patchff_ds1_small.yml",
    ]
    model_files += sorted((upstream / "src/f3/tasks/depth/depth_anything_v2").rglob("*.py"))
    return dict(
        revision=subprocess.check_output(["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True).strip(),
        source=data,
        source_sha256=hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest(),
        upstream_revision=subprocess.check_output(
            ["git", "-C", str(upstream), "rev-parse", "HEAD"], text=True
        ).strip(),
        upstream_files={str(p.relative_to(upstream)): digest(p) for p in model_files},
        encoder=CHECKPOINT_SHA256,
        heads=HASHES,
    )
