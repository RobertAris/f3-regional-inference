"""CPU-only restore tests backed by synthetic publisher objects in memory."""
from contextlib import redirect_stdout
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import cv2
import h5py
import numpy as np
import requests
import yaml

from followup.multitask import restore
from query_f3.binding import digest


def sha(data):
    return hashlib.sha256(data).hexdigest()


def npz_hash(arrays, compressed=True):
    stream = io.BytesIO()
    save = np.savez_compressed if compressed else np.savez
    save(stream, **arrays)
    return sha(stream.getvalue())


def hdf5(fields, version=None):
    stream = io.BytesIO()
    with h5py.File(stream, "w") as handle:
        if version is not None:
            handle.attrs["version"] = version
        for key, value in fields.items():
            handle[key] = value
    return stream.getvalue()


def zipped(entries, compression=zipfile.ZIP_STORED):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", compression) as archive:
        for key, value in entries.items():
            archive.writestr(key, value)
    return stream.getvalue()


class RestoreTests(unittest.TestCase):
    def setUp(self):
        folder = Path(self.enterContext(tempfile.TemporaryDirectory()))
        self.root = folder / "cache"
        self.manifests = folder / "manifests"
        self.manifests.mkdir()
        self.fixtures = {}
        self.seen = []
        self.enterContext(patch.object(restore, "HERE", self.manifests))
        self.enterContext(patch.object(requests.adapters.HTTPAdapter, "send", autospec=True, side_effect=self.send))

    def send(self, adapter, request, **kwargs):
        url, headers = request.url, request.headers
        self.assertEqual(request.method, "GET")
        self.assertEqual(headers["Accept-Encoding"], "identity")
        self.assertIn(url, self.fixtures, f"Unexpected download from {url}")
        self.seen.append(url)
        payload, pin = self.fixtures[url]
        response = requests.Response()
        response.request = request
        response.url = url
        response.status_code = 200
        for header, key in (("ETag", "etag"), ("Last-Modified", "modified")):
            if key in pin:
                response.headers[header] = pin[key]
        if "Range" in headers:
            lo, hi = map(int, headers["Range"].removeprefix("bytes=").split("-"))
            self.assertTrue(0 <= lo <= hi < len(payload))
            response.status_code = 206
            response.headers["Content-Range"] = f"bytes {lo}-{hi}/{len(payload)}"
            payload = payload[lo:hi + 1]
        response.raw = io.BytesIO(payload)
        return response

    def publisher(self, name, payload, *, url=None, **headers):
        url = url or f"https://publisher.invalid/{name}"
        pin = dict(url=url, size=len(payload), **headers)
        self.fixtures[url] = (payload, pin.copy())
        return pin

    def lock(self, domain, recording, index, row, pins, arrays, cal=None):
        filename = f"{recording}-{index}.npz"
        entry = dict(recording=recording, row=row, objects=pins, sha256=npz_hash(arrays))
        if cal is not None:
            entry["cal_sha256"] = npz_hash(cal)
        (self.manifests / "packets.json").write_text(json.dumps({domain: {filename: entry}}))
        return self.root / restore.FOLDERS[domain] / filename, entry["sha256"]

    def test_dsec_stored_members_disparity_and_calibration(self):
        name, size = "locked_dsec", (4, 3)
        self.enterContext(patch.object(restore, "DSEC_SIZE", size))
        y, x = np.indices(size[::-1], dtype=np.float32)
        official = np.stack((x, y), axis=-1)
        map_bytes = hdf5({"rectify_map": official.astype("d")})
        intrinsic = {"camera_type": "event", "camera_matrix": [1, 1, 0, 0], "resolution": list(size)}
        doc = {"intrinsics": {}, "extrinsics": {}}
        entries, extras, cal = {}, {}, {}
        image = np.arange(12, dtype=np.uint16).reshape(size[::-1]) * 256
        png = cv2.imencode(".png", image)[1].tobytes()
        arrays = {"disparity_png": image}
        for j, side in enumerate(restore.SIDES):
            fields = {"t_offset": 60000, "events/t": np.array([19999, 20000, 39999, 40000], dtype="u8"),
                      "events/x": [0, j, 3, 1], "events/y": [0, 1, 1, 0], "events/p": [0, 1, 0, 1]}
            files = {"events.h5": hdf5(fields), "rectify_map.h5": map_bytes}
            entries.update({f"{name}/events/{side}/{k}": v for k, v in files.items()})
            key = f"events_{side}.zip"
            extras[key] = self.publisher(key, zipped(files, zipfile.ZIP_DEFLATED), etag='"eye"')
            base = dict(intrinsic, camera_location=side)
            doc["intrinsics"][f"cam{j}"] = dict(base, is_rectified=False, distortion_model="radtan",
                                                distortion_coeffs=[0, 0, 0, 0])
            doc["intrinsics"][f"camRect{j}"] = dict(base, is_rectified=True)
            doc["extrinsics"][f"R_rect{j}"] = np.eye(3).tolist()
            cal[f"inverse_{side}_x"], cal[f"inverse_{side}_y"], cal[f"forward_{side}"] = x, y, official
            arrays[side] = np.array([[-20000, j, 1, 1], [-1, 3, 1, 0]], dtype="i4")
        coarse = self.publisher("coarse", zipped(entries), etag='"coarse"')
        self.enterContext(patch.object(restore, "DSEC_COARSE", coarse))
        pins = dict(extras)
        pins["calibration.zip"] = self.publisher("cal", zipped({"cam_to_cam.yaml": yaml.safe_dump(doc)}))
        pins["disparity_event.zip"] = self.publisher("disparity", zipped({"000000.png": png}, zipfile.ZIP_DEFLATED))
        pins["disparity_timestamps.txt"] = self.publisher("timestamps", b"90000\n")
        row = dict(q=20, index=0, total=1, timestamp=90000, cut=100000, png="000000.png",
                   indices={side: [1, 3] for side in restore.SIDES})
        path, wanted = self.lock("dsec", name, 20, row, pins, arrays, cal)
        receipt = restore.restore("dsec", name, self.root, "0.2")
        self.assertEqual(digest(path), wanted)
        cal_path = path.with_name(f"{name}-cal.npz")
        self.assertEqual(digest(cal_path), npz_hash(cal))
        self.assertEqual(len(receipt["sources"][0]["members"]), 4)

        self.seen.clear()
        cal_path.unlink()
        receipt = restore.restore("dsec", name, self.root)
        self.assertEqual({x["status"] for x in receipt["outputs"]}, {"verified_cache", "restored"})
        self.assertNotIn(pins["disparity_event.zip"]["url"], self.seen)
        self.seen.clear()
        with redirect_stdout(io.StringIO()) as stdout:
            restore.main(["--domain", "dsec", "--recording", name, "--data-root", str(self.root)])
        self.assertEqual(json.loads(stdout.getvalue())["sources"], [])
        self.assertEqual(self.seen, [])
        cal_path.write_bytes(b"wrong calibration")
        with self.assertRaisesRegex(restore.RestoreError, "SHA-256 mismatch.*-cal.npz"):
            restore.restore("dsec", name, self.root)
        self.assertEqual(cal_path.read_bytes(), b"wrong calibration")
        self.assertEqual(self.seen, [])

    def test_mvsec_rounded_50ms_window_and_pinned_calibration(self):
        size = (4, 3)
        self.enterContext(patch.object(restore, "MVSEC_SIZE", size))
        setting = "indoor_flying"
        url = f"https://visiondata.cis.upenn.edu/mvsec/{setting}/{setting}_calib.zip"
        k = np.array([[4., 0, 1], [0, 4, 1], [0, 0, 1]])
        docs, maps, cal, fields, event_pins = {}, {}, {}, {}, {}
        depth = np.arange(12, dtype=np.float64).reshape(size[::-1])
        arrays = {"depth": depth.astype("f")}
        y, x = np.indices(size[::-1], dtype="d")
        coords = np.stack((x, y), axis=-1).reshape(-1, 1, 2)
        official = cv2.fisheye.undistortPoints(coords, k, np.zeros(4), P=k).reshape(*size[::-1], 2)
        for j, side in enumerate(restore.SIDES):
            p = np.column_stack((k, [-j, 0, 0]))
            docs[f"cam{j}"] = dict(resolution=list(size), distortion_model="equidistant", intrinsics=[4, 4, 1, 1],
                                   distortion_coeffs=[0, 0, 0, 0], rectification_matrix=np.eye(3).tolist(),
                                   projection_matrix=p.tolist())
            for i, axis in enumerate("xy"):
                stream = io.StringIO()
                np.savetxt(stream, official[:, :, i])
                maps[f"{setting}_{side}_{axis}_map.txt"] = stream.getvalue()
            mx, my = cv2.fisheye.initUndistortRectifyMap(k, np.zeros(4), np.eye(3), k, size, cv2.CV_32FC1)
            cal.update({f"P_{side}": p, f"inverse_{side}_x": mx, f"inverse_{side}_y": my,
                        f"forward_{side}": official.astype("f")})
            off = -1 + j
            fields[f"davis/{side}/events"] = [[0, 0, 1.009999, 1], [j, 1, 1.00999975, off],
                                               [2, 1, 1.039999, 1], [3, 2, 1.059999, off], [3, 2, 1.05999975, 1]]
            event_pins[side] = dict(start=1, end=4, n=5, polarity_values=[off, 1])
            arrays[side] = np.array([[-50000, j, 1, 0], [-20001, 2, 1, 1], [-1, 3, 2, 0]], dtype="i4")
        payload = zipped(dict(maps, **{f"camchain-imucam-{setting}.yaml": yaml.safe_dump(docs)}))
        self.publisher("cal", payload, url=url)
        self.enterContext(patch.dict(restore.MVSEC_CAL_SHA, {setting: sha(payload)}))
        pins = {"data": self.publisher("data", hdf5(fields)), "gt": self.publisher("gt", hdf5({
            "davis/left/depth_image_rect": depth[None], "davis/left/depth_image_rect_ts": [1.05]}))}
        row = dict(q=50, index=0, frames=1, ts_us=1050000, cut_us=1060000, events=event_pins)
        path, wanted = self.lock("mvsec", setting + "1", 50, row, pins, arrays, cal)
        restore.restore("mvsec", setting + "1", self.root, "50")
        self.assertEqual(digest(path), wanted)
        cal_path = path.with_name(setting + "-cal.npz")
        self.assertEqual(digest(cal_path), npz_hash(cal))
        cal_path.unlink()
        self.fixtures[url] = (b"changed calibration", {})
        with self.assertRaisesRegex(restore.RestoreError, f"SHA-256 mismatch for {url}"):
            restore.restore("mvsec", setting + "1", self.root)
        self.assertFalse(cal_path.exists())
        self.assertEqual(digest(path), wanted)

    def test_m3ed_publisher_groups_and_native_timestamp(self):
        name, size = "locked_m3ed", (4, 3)
        self.enterContext(patch.object(restore, "M3ED_SIZE", size))
        stamps = np.array([19999, 20000, 20000, 31000, 39999, 40000], dtype="u8")
        locator = np.searchsorted(stamps, np.arange(42) * 1000)
        fields, arrays = {}, {}
        for j, side in enumerate(restore.SIDES):
            transform = np.eye(4)
            transform[0, 3] = -j
            k, dist = np.array([4, 4, 1, 1], dtype="d"), np.zeros(4)
            source = {"t": stamps, "x": [0, 1, 1, 2, j, 0], "y": [0, 0, 0, 2, 1, 0], "p": [1, 1, 1, 0, 1, 0],
                      "ms_map_idx": locator, "calib/resolution": size, "calib/intrinsics": k,
                      "calib/distortion_coeffs": dist, "calib/distortion_model": b"radtan",
                      "calib/T_to_prophesee_left": transform}
            fields.update({f"prophesee/{side}/{key}": v for key, v in source.items()})
            arrays.update({f"K_{side}": k, f"dist_{side}": dist, f"T_{side}": transform})
        depth = np.arange(12).reshape(size[::-1])
        arrays["depth"] = depth.astype("f")
        for j, side in enumerate(restore.SIDES):
            arrays[side] = np.array([[-20000, 1, 0, 1], [-20000, 1, 0, 1], [-9000, 2, 2, 0], [-1, j, 1, 1]], dtype="i4")
        version = "locked-fixture"
        pins = {"data": self.publisher("data", hdf5(fields, version), release=version, etag='"data"'),
                "depth_gt": self.publisher("gt", hdf5({"ts": [10000, 30000, 50000], "Cn_T_C0": [np.eye(4)] * 3,
                                                       "depth/prophesee/left": [depth + 1, depth, depth + 2]}, version),
                                           release=version, etag='"gt"')}
        row = dict(j=5, idx=1, n_depth=3, t=30000, events={s: 4 for s in restore.SIDES})
        path, wanted = self.lock("m3ed", name, 5, row, pins, arrays)
        restore.restore("m3ed", name, self.root, "5")
        self.assertEqual(digest(path), wanted)
        cam = {key: np.asarray(fields["prophesee/left/" + key]) for key in ("t", "x", "y", "p", "ms_map_idx")}
        cam["ms_map_idx"][20] += 1
        with self.assertRaisesRegex(restore.RestoreError, "does not bracket"):
            restore.m3ed_events(cam, 20000, 40000)

    def test_esot_reuses_verified_aedat_and_preserves_window_boundaries(self):
        payload, name = b"synthetic AEDAT", "fixture"
        source_sha = sha(payload)
        base = "https://publisher.invalid/ESOT500-H"
        url = f"{base}/aedat4/{name}.aedat4"
        self.publisher(name, payload, url=url)
        event_dtype = [("t", "u8"), ("x", "u2"), ("y", "u2"), ("on", "?")]
        chunks = [np.array(values, dtype=event_dtype) for values in
                  [[(100000, 1, 1, True), (139999, 2, 2, False)],
                   [(140000, 4, 3, True), (140000, 4, 3, True), (1059999, 7, 7, False), (1060000, 0, 0, True)]]]
        arrays = {"anchors": np.arange(120000, 1040001, 40000, dtype="i8"), "source_sha": source_sha}
        for i in range(24):
            arrays[f"w{i}"] = np.empty((0, 4), dtype="i4")
        arrays["w0"] = np.array([[-20000, 1, 1, 1], [19999, 2, 2, 0]], dtype="i4")
        arrays["w1"] = np.array([[-20000, 4, 3, 1], [-20000, 4, 3, 1]], dtype="i4")
        arrays["w23"] = np.array([[19999, 7, 7, 0]], dtype="i4")
        with self.assertRaisesRegex(restore.RestoreError, "24 windows"):
            restore.esot_windows(lambda: iter(chunks[:1]), source_sha)
        wanted = npz_hash(arrays, compressed=False)
        row = dict(name=name, sensor="H", base=base, file=f"H_{name}.npz", bytes=len(payload),
                   sha256=source_sha, packet_sha256=wanted)
        (self.manifests / "occupancy-packets.json").write_text(json.dumps([row]))
        path = self.root / "temporal/windows" / row["file"]
        raw = self.root / "temporal/H" / f"{name}.aedat4"
        with patch.object(restore, "esot_packets", side_effect=lambda path: iter(chunks)) as decode:
            restore.restore("esot", name, self.root)
            self.assertEqual(digest(path), wanted)
            self.assertEqual(self.seen, [url])
            decode.assert_called_with(raw)
            path.unlink()
            self.seen.clear()
            receipt = restore.restore("esot", "H_" + name, self.root)
            self.assertEqual(receipt["sources"][0]["status"], "verified_cache")
            self.assertEqual(self.seen, [])
            self.assertEqual(digest(path), wanted)
            path.unlink()
            raw.unlink()
            self.fixtures[url] = (b"!" * len(payload), {})
            with self.assertRaisesRegex(restore.RestoreError, "SHA-256 mismatch.*aedat4"):
                restore.restore("esot", name, self.root)
            self.assertFalse(raw.exists())
            self.assertFalse(path.exists())
            self.assertEqual(decode.call_count, 4)

    def test_refuses_changed_publisher_validator(self):
        pin = self.publisher("changed", b"123", etag='"new"')
        source = restore.PublisherSource(pin["url"], pin["size"], etag='"old"')
        self.addCleanup(source.session.close)
        with self.assertRaisesRegex(restore.RestoreError, "publisher.invalid/changed: ETag changed"):
            source.fetch(0, 3)

    def test_requires_pinned_last_modified_on_every_range(self):
        date = "Wed, 21 Oct 2015 07:28:00 GMT"
        payload = b"123"
        pin = self.publisher("mvsec-data", payload, modified=date)
        source = restore.PublisherSource(**pin)
        self.addCleanup(source.session.close)
        self.assertEqual(source.fetch(0, 1), b"1")

        for response_pin in ({}, {"modified": "Thu, 22 Oct 2015 07:28:00 GMT"}):
            self.fixtures[pin["url"]] = (payload, response_pin)
            with self.subTest(response_pin=response_pin), self.assertRaisesRegex(
                restore.RestoreError, r"https://publisher\.invalid/mvsec-data: Last-Modified mismatch"
            ):
                source.fetch(1, 2)
        self.assertEqual((source.requests, source.bytes), (1, 1))

    def test_invalid_recording_and_fraction_are_offline(self):
        (self.manifests / "packets.json").write_text('{"mvsec": {}}')
        (self.manifests / "occupancy-packets.json").write_text("[]")
        for domain, name, fraction in [("mvsec", "../escape", None), ("mvsec", "x", "0.3"),
                                       ("m3ed", "x", "NaN"), ("esot", "x", "0.2"), ("human", "x", None)]:
            with self.subTest(domain=domain, name=name, fraction=fraction), self.assertRaises(restore.RestoreError):
                restore.restore(domain, name, self.root, fraction)
        self.assertEqual(self.seen, [])
        self.assertFalse(self.root.exists())

    def test_atomic_write_rejects_mismatch_and_never_overwrites_peer(self):
        path = self.root / "packet.npz"
        locked = restore.LockedFile(path, sha(b"correct"))
        with self.assertRaisesRegex(restore.RestoreError, "SHA-256 mismatch"):
            locked.publish(lambda stream: stream.write(b"incorrect"))
        self.assertEqual(list(self.root.iterdir()), [])

        def race(stream):
            stream.write(b"correct")
            path.write_bytes(b"peer result")

        with self.assertRaisesRegex(restore.RestoreError, "SHA-256 mismatch"):
            locked.publish(race)
        self.assertEqual(path.read_bytes(), b"peer result")
        self.assertEqual(list(self.root.iterdir()), [path])
        path.write_bytes(b"correct")
        self.assertEqual(locked.publish(lambda stream: stream.write(b"correct"))["status"], "verified_cache")
        self.assertTrue(locked.cached())


if __name__ == "__main__":
    unittest.main()
