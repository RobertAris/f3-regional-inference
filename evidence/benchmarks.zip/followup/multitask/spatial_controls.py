"""Score image-row priors on exactly the labeled sites in the archived requests."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.stats import spearmanr

from followup.multitask.data import paths
from followup.multitask.replay import ARCHIVE, iou, records


def labels(path, sha, key):
    with path.open("rb") as stream:
        if hashlib.file_digest(stream, "sha256").hexdigest() != sha:
            raise ValueError(f"Packet hash mismatch at {path}")
    with np.load(path, allow_pickle=False) as packet:
        return packet[key]


def semantic_prior(files, roster):
    counts = None
    for path in files:
        mask = labels(path, roster[path.name]["sha256"], "label")
        y, x = np.nonzero(mask < 11)
        indices = y * 11 + mask[y, x]
        histogram = np.bincount(indices, minlength=len(mask) * 11).reshape(-1, 11)
        counts = histogram if counts is None else counts + histogram
    by_row = counts.argmax(axis=1)
    by_row[counts.sum(axis=1) == 0] = counts.sum(axis=0).argmax()
    return by_row


def compare(root):
    roster = json.loads(Path(__file__).with_name("packets.json").read_text())
    archive = [row for name, row in records(ARCHIVE) if name.startswith("final/global/")]
    results = {}
    for domain in ("mvsec", "m3ed", "human", "day"):
        semantic = domain in ("human", "day")
        rows = {r["packet"]: r for r in archive if r["domain"] == domain}
        evaluation = paths(domain, "evaluation", root)
        if set(rows) != {p.name for p in evaluation}:
            raise ValueError(f"Unexpected evaluation roster for {domain}")
        if semantic:
            training = paths(domain, "development", root)
            prior = semantic_prior(training, roster[domain])
        packets = []
        for path in evaluation:
            row = rows[path.name]
            sha = roster[domain][path.name]["sha256"]
            if row["split"] != "evaluation" or row["sha256"] != sha:
                raise ValueError(f"Measurement and packet differ for {path.name}")
            target = labels(path, sha, "label" if semantic else "depth")
            mask = np.zeros(target.shape, dtype=bool)
            for x, y, w, h in row["boxes"]:
                mask[y:y+h, x:x+w] = True
            mask &= target < 11 if semantic else np.isfinite(target) & (target > 0)
            y, x = np.nonzero(mask)
            dense = row["arms"]["dense"]
            if len(y) != dense["n"]:
                raise ValueError(f"Labeled pixel count differs for {path.name}")
            result = {"file": path.name, "n": len(y)}
            if semantic:
                ids = 11 * target[y, x].astype(int) + prior[y]
                result["confusion"] = np.bincount(ids, minlength=121).reshape(11, 11).tolist()
            else:
                result["row_rho"] = float(spearmanr(y, 1 / target[y, x]).statistic)
                result["dense_rho"] = dense["rho"]
            packets.append(result)
        panel = {"n": sum(r["n"] for r in packets), "packets": packets}
        if semantic:
            panel["row_miou"] = iou(np.sum([r["confusion"] for r in packets], axis=0))
            panel["dense_miou"] = iou(np.sum([r["arms"]["dense"]["confusion"] for r in rows.values()], axis=0))
            panel["development"] = [p.name for p in training]
        else:
            for key in ("dense_rho", "row_rho"):
                panel[key] = float(np.mean([r[key] for r in packets]))
        results[domain] = panel
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, default=Path("datasets"))
    args = parser.parse_args()
    print(json.dumps(compare(args.data_root), indent=2, allow_nan=False))
