"""Regression checks for geometry, lookup, selection and scientific scoring."""

from types import SimpleNamespace
import unittest

import numpy as np
import torch

from followup.multitask.bench import roi_scores
from followup.multitask.feature_bench import disparity_mae, layouts
from query_f3.multitask.joint import validate
from query_f3.multitask.lookup import build_lookup
from query_f3.multitask.service import packet


class _Encoder(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.downsample_layers = torch.nn.ModuleList([torch.nn.Sequential(torch.nn.Conv2d(3, 3, 1))])
        self.multi_hash_encoder = torch.nn.Identity()


class ServiceTests(unittest.TestCase):
    def test_integer_event_lookup(self):
        enc = _Encoder()
        size = (8, 5)
        events = np.array([[-20000, 0, 0], [-15701, 7, 2], [-15701, 7, 2], [-1, 3, 4]], dtype="i4")
        table = build_lookup(enc, size)
        for rect in (None, (3, 2, 5, 3), (1, 1, 1, 1)):
            a = packet(events, size).grid(enc, rect)
            b = packet(events, size, table).grid(enc, rect)
            torch.testing.assert_close(a, b)

    def test_layouts_and_global_validation(self):
        events = np.array([[-2, 5, 6]], dtype="i4")
        for mode in ("dispersed", "clustered", "active"):
            boxes = layouts(events, (346, 260), 32, 16, mode)
            self.assertEqual(len(validate({"depth": boxes}, (346, 260))["depth"]), 16)
        with self.assertRaises(ValueError):
            validate({"depth": [(0, 0, 2, 0)]}, (2, 2))

    def test_no_depth_or_semantic_label_in_tile(self):
        logits = np.ones((2, 11, 3, 3), dtype="f")
        score = roi_scores(
            "semantics", logits, logits, np.full((4, 5), 255, dtype="u1"), [(1, 4, 3, 3)] * 2
        )
        self.assertEqual(score["n"], 0)
        self.assertEqual(score["label_agreement"], 1)
        self.assertEqual(score["max_abs"], 0)

    def test_abstention_and_disparity_bounds(self):
        score = disparity_mae(np.array([3.0, -1.0, 0.0, 0.0]), np.array([4.0, 50.0, 0.0, np.nan]))
        self.assertEqual((score["n"], score["valid_returns"], score["outside"]), (2, 1, 1))
        self.assertEqual((score["sum_error"], score["returned_sum_error"]), (51.0, 1.0))


if __name__ == "__main__":
    unittest.main()
