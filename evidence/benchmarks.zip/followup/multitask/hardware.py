"""Isolated memory, steady-state throughput, context reuse and joint-head timings."""

import argparse
import copy
import json
import resource
import threading
import time
from pathlib import Path

import numpy as np
import psutil
import torch

from followup.multitask.bench import environment, parser, setup, sync
from followup.multitask.data import DEV, load, paths
from followup.multitask.provenance import pin
from query_f3.binding import digest
from query_f3.inference.loaders.released_flow import load_head
from query_f3.multitask.attention import use_sdpa
from query_f3.multitask.fusion import FoldedSegformer
from query_f3.multitask.joint import prepare, query
from query_f3.multitask.lookup import build_lookup
from query_f3.multitask.models import load_global_head
from query_f3.multitask.service import FeatureService, active_regions, gather_yx, packet

LEGACY = ".local-history/four-branch-release-20261123/legacy-workspace/archive/binary-occupancy/project/checkpoints/flow"


def read_heads(opt, enc):
    heads = {}
    for t in opt.tasks:
        if t == "flow":
            heads[t] = load_head(
                opt.upstream,
                opt.flow_dir / "last.pth",
                opt.flow_dir / "flow_config.yaml",
                opt.weights,
                opt.device,
            )
        if t in ("depth", "semantics"):
            h = load_global_head(
                t,
                opt.models / f"{t}.pth",
                opt.weights,
                opt.upstream,
                opt.models / "segformer.json",
                opt.device,
            )
            if t == "semantics":
                use_sdpa(h, t)
                h.folded = FoldedSegformer(h)
            heads[t] = h
    return heads


def requests(events, size, tasks, count, extent, layout):
    boxes = active_regions(events, size, count, extent)
    rng = np.random.default_rng(91)
    if layout == "dispersed":
        boxes = [
            (
                int(rng.integers(size[0] - extent + 1)),
                int(rng.integers(size[1] - extent + 1)),
                extent,
                extent,
            )
            for _ in range(count)
        ]
    if layout == "clustered":
        boxes = [
            (
                min(size[0] - extent, size[0] // 3 + i % 4),
                min(size[1] - extent, size[1] // 3 + i // 4),
                extent,
                extent,
            )
            for i in range(count)
        ]
    # Different heads consume different locations, with partly overlapping boxes.
    return {
        t: [
            (
                int(np.clip(x + (j % 3) * extent // 2, 0, size[0] - w)),
                int(np.clip(y + (j // 3) * extent // 2, 0, size[1] - h)),
                w,
                h,
            )
            for x, y, w, h in boxes
        ]
        for j, t in enumerate(tasks)
    }


def to_host(out):
    return {t: torch.cat(v).float().contiguous().cpu().numpy() for t, v in out.items()}


def memory(device):
    process = psutil.Process()
    rss = process.memory_info().rss
    mps = torch.mps.driver_allocated_memory() if device == "mps" else 0
    live = torch.mps.current_allocated_memory() if device == "mps" else 0
    return rss, mps, live


@torch.inference_mode()
def run(opt):
    torch.set_num_threads(4)
    opt.task = "features"
    enc, _ = setup(opt)
    heads = read_heads(opt, enc)
    (file,) = [f for f in paths(opt.domain, opt.split, opt.data) if f.stem == opt.packet]
    size, ev, _, _, counts = load(opt.domain, file)
    events = ev["left"]
    sync(opt.device)
    setup_start = time.perf_counter()
    table = build_lookup(enc, size) if opt.lookup else None
    sync(opt.device)
    lookup_setup_ms = 1000 * (time.perf_counter() - setup_start) if opt.lookup else 0
    service = FeatureService()
    field_tasks = set(opt.tasks) <= {"features", "occupancy"}
    regional = opt.strategy != "dense"
    separate = opt.strategy in ("separate", "separate-batched")
    fast = opt.strategy in ("batched", "separate-batched")

    def request():
        return requests(events, size, opt.tasks, opt.count, opt.extent, opt.layout)

    def make(p, rs):
        if field_tasks and regional:
            # Batched regional suffix with a common packet-conditioned gain estimate.
            from query_f3.depth_context import prefix

            st, g = prefix(enc, p.grid(enc), (3,))[3]
            return service.projected.context(enc, None, st, g, 2, True, True)
        return prepare(enc, heads, p, rs, regional=regional, batched=fast)

    def consume(ctx, rs):
        if field_tasks and regional:
            from query_f3.multitask.service import merged_suffix

            tiles = list(dict.fromkeys(box for boxes in rs.values() for box in boxes))
            v = merged_suffix(enc, ctx, tiles)
            d = dict(zip(tiles, v.split(1), strict=True))
            return {
                t: [(enc.pred(d[b]) if t == "occupancy" else d[b]).transpose(2, 3) for b in boxes]
                for t, boxes in rs.items()
            }
        return query(enc, heads, ctx, rs, regional=regional, batched=fast)

    def fresh():
        rs = request()
        if separate:
            out = {}
            for task in rs:
                own = {task: rs[task]}
                out.update(consume(make(packet(events, size, table), own), own))
            return to_host(out)
        return to_host(consume(make(packet(events, size, table), rs), rs))

    def elapsed(fn):
        sync(opt.device)
        start = time.perf_counter()
        v = fn()
        sync(opt.device)
        return 1000 * (time.perf_counter() - start), v

    sync(opt.device)
    if opt.device == "mps":
        torch.mps.empty_cache()
    baseline = memory(opt.device)
    peak = list(baseline)
    stop = threading.Event()

    def watch():
        while not stop.is_set():
            for i, m in enumerate(memory(opt.device)):
                peak[i] = max(peak[i], m)
            stop.wait(0.002)

    observer = threading.Thread(target=watch, daemon=True)
    observer.start()
    try:
        first, value = elapsed(fresh)
        for i, m in enumerate(memory(opt.device)):
            peak[i] = max(peak[i], m)
    finally:
        stop.set()
        observer.join()
    finite = {k: bool(np.isfinite(v).all()) for k, v in value.items()}
    reference = {}
    boxes = request()
    # Compare both implementations with the original eager, unfolded task heads.
    eager = heads.copy()
    if "semantics" in heads:
        eager["semantics"] = load_global_head(
            "semantics",
            opt.models / "semantics.pth",
            opt.weights,
            opt.upstream,
            opt.models / "segformer.json",
            opt.device,
        )
    ctx = prepare(enc, eager, packet(events, size), boxes, regional=False)
    dense = to_host(query(enc, eager, ctx, boxes, regional=False))
    del ctx, eager
    for k, v in value.items():
        delta = v.astype("d") - dense[k]
        reference[k] = dict(
            relative_rms=float(
                np.sqrt((delta**2).mean()) / max(np.sqrt(np.mean(dense[k].astype("d") ** 2)), 1e-12)
            ),
            max_abs=float(np.abs(delta).max()),
        )
    del dense
    fresh_ms = []
    sync(opt.device)
    start = time.perf_counter()
    for _ in range(opt.repeats):
        duration, _ = elapsed(fresh)
        fresh_ms.append(duration)
    pps = opt.repeats / (time.perf_counter() - start)
    if separate:
        caches = {t: make(packet(events, size, table), {t: boxes[t]}) for t in boxes}

        def cached():
            return to_host({t: consume(caches[t], {t: boxes[t]})[t] for t in boxes})
    else:
        cache = make(packet(events, size, table), boxes)

        def cached():
            return to_host(consume(cache, boxes))

    cached_ms = [elapsed(cached)[0] for _ in range(opt.repeats)]
    result = dict(
        domain=opt.domain,
        packet=file.name,
        events=counts,
        size=size,
        sha256=digest(file),
        requested=boxes,
        lookup_setup_ms=lookup_setup_ms,
        lookup_bytes=table.numel() * 4 if opt.lookup else 0,
        tasks=opt.tasks,
        layout=opt.layout,
        strategy=opt.strategy,
        lookup=opt.lookup,
        device=opt.device,
        first_ms=first,
        fresh_ms=fresh_ms,
        cached_ms=cached_ms,
        serial_packets_per_s=pps,
        finite=finite,
        agreement=reference,
        memory=dict(
            baseline=baseline,
            peak=peak,
            sample_interval_ms=2,
            units="bytes; columns RSS, MPS driver allocation, MPS active tensors",
        ),
        env=environment(opt.device),
        provenance=pin(opt.upstream),
    )
    opt.out.parent.mkdir(parents=True, exist_ok=True)
    with opt.out.open("x") as f:
        json.dump(result, f, allow_nan=False, separators=(",", ":"))
        f.write("\n")
    print(opt.out.name, round(np.median(fresh_ms), 1), flush=True)


if __name__ == "__main__":
    p = parser()
    p.add_argument("--tasks", nargs="+", required=True)
    p.add_argument(
        "--strategy",
        choices=("dense", "regional", "separate", "batched", "separate-batched"),
        required=True,
    )
    p.add_argument("--layout", choices=("active", "dispersed", "clustered"), default="active")
    p.add_argument("--packet", required=True)
    p.add_argument("--flow-dir", type=Path, default=Path(LEGACY))
    run(p.parse_args())
