"""Restore locked perception packets from publisher data, with JSON provenance on stdout.

Run as ``python -m followup.multitask.restore``. The data root is the same
one the benchmarks use. Keep it on a filesystem that supports hard links
so verified temporary files can be published atomically without overwrites.
"""
import argparse
from contextlib import ExitStack
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
import hashlib
import io
import json
import os
from pathlib import Path
import tempfile
import zipfile

import cv2
import h5py
import hdf5plugin  # Register the publisher HDF5 filters before opening files.
import numpy as np
import requests
import yaml

from followup.multitask.ranges import ByteFile, Source, directory, member
from query_f3.binding import digest

HERE = Path(__file__).resolve().parent
FOLDERS = {
    "dsec": "f3-stereo-fusion",
    "mvsec": "f3-stereo-transfer",
    "m3ed": "f3-opponent-stereo",
    "esot": "temporal/windows",
}
SIDES = ("left", "right")
DSEC_SIZE = (640, 480)
MVSEC_SIZE = (346, 260)
M3ED_SIZE = (1280, 720)
DSEC_COARSE = {
    "url": "https://download.ifi.uzh.ch/rpg/DSEC/train_coarse/train_events.zip",
    "size": 131892069895,
    "etag": '"1eb5614607-5ce8da57f604c"',
}
MVSEC_CAL_SHA = {
    "indoor_flying": "2bc61565a2e53af174c7afc956c9148dea96c55a765b95f06e558e7d726d1f94",
    "outdoor_day": "b5a5c370623beb01608e5b6c789a1a2d3065efcc36bb9b6c59584f14308a16c3",
    "outdoor_night": "6953c59a25182a26120d2d86a00820cbcaa078b2c80a6f69a9eb14eb5061784f",
}


class RestoreError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise RestoreError(message)


def check_hash(actual, expected, description):
    require(actual == expected, f"SHA-256 mismatch for {description}: expected {expected}, got {actual}")


@dataclass(frozen=True)
class LockedFile:
    path: Path
    sha256: str
    size: int | None = None

    def verify(self, path):
        require(path.is_file(), f"Expected a regular file at {path}")
        if self.size is not None:
            require(path.stat().st_size == self.size, f"Size mismatch for {path}: expected {self.size} bytes")
        check_hash(digest(path), self.sha256, str(self.path))

    def cached(self):
        if self.path.exists() or self.path.is_symlink():
            self.verify(self.path)
            return True
        return False

    def publish(self, write):
        """Return a receipt for a verified file, including when a peer won the race."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix=".restore-", dir=self.path.parent) as staging:
            temp = Path(staging) / self.path.name
            with temp.open("wb") as stream:
                write(stream)
            self.verify(temp)
            try:
                os.link(temp, self.path)
            except FileExistsError:
                self.verify(self.path)
                return self.receipt("verified_cache")
        return self.receipt("restored")

    def receipt(self, status):
        return {"file": str(self.path), "sha256": self.sha256, "status": status}


def save_packet(target, arrays, compressed=True):
    save = np.savez_compressed if compressed else np.savez
    return target.publish(lambda stream: save(stream, **arrays))


class PublisherSource(Source):
    def __init__(self, url, size, etag=None, modified=None):
        super().__init__(url, size, etag, modified)
        if modified is not None:
            self.session.hooks["response"].append(self._verify_last_modified)

    def _verify_last_modified(self, response, **kwargs):
        if response.status_code != 206:
            return
        actual = response.headers.get("Last-Modified")
        if actual != self.modified:
            # The hook runs before Source enters the response context.
            response.close()
            received = "missing header" if actual is None else repr(actual)
            raise ValueError(f"Last-Modified mismatch: expected {self.modified!r}, got {received}")

    def fetch(self, start, length):
        try:
            return super().fetch(start, length)
        except (ValueError, OSError, requests.RequestException) as exc:
            raise RestoreError(f"{self.url}: {exc}") from exc


def ranged(stack, pin, access):
    src = PublisherSource(pin["url"], pin["size"], pin.get("etag"), pin.get("modified"))
    evidence = dict(pin, method="range")
    access.append(evidence)
    stack.callback(src.session.close)
    stack.callback(lambda: evidence.update(bytes_read=src.bytes, requests=src.requests))
    return src, evidence


def open_hdf5(stack, stream):
    stack.enter_context(stream)
    return stack.enter_context(h5py.File(stream, "r"))


def download(url, stream, size=None):
    count = 0
    with requests.get(url, headers={"Accept-Encoding": "identity"}, stream=True, timeout=(15, 65)) as response:
        response.raise_for_status()
        require(response.status_code == 200, f"Expected a complete response from {url}")
        for chunk in response.iter_content(chunk_size=1024**2):
            count += len(chunk)
            require(size is None or count <= size, f"Response from {url} exceeds the pinned {size} bytes")
            stream.write(chunk)
    require(size is None or count == size, f"Expected {size} bytes from {url}, got {count}")
    return count


def window_bounds(timestamps, start, end):
    require(start < end and np.all(timestamps[1:] >= timestamps[:-1]), "Invalid event window or unordered timestamps")
    return np.searchsorted(timestamps, (start, end))


def native_window(dataset, first, last, start, end, timestamps):
    """Verify a pinned slice using the events immediately outside its ends."""
    require(0 <= first <= last <= len(dataset), f"Invalid native event indices {first}:{last}")
    origin = max(0, first - 1)
    block = dataset[origin:min(last + 1, len(dataset))]
    times = timestamps(block)
    lo, hi = window_bounds(times, start, end)
    require((origin + lo, origin + hi) == (first, last),
            f"Native event indices {first}:{last} do not span [{start}, {end})")
    return times[lo:hi], block[lo:hi]


def event_rows(times, xy, polarity, end, size):
    require(np.all(xy >= 0) and np.all(xy < size)
            and (xy.dtype.kind in "iu" or np.all(xy == np.trunc(xy))),
            f"Invalid event coordinates for sensor {size}")
    return np.column_stack((times - end, xy, polarity)).astype("i4")


def camera_matrix(intrinsics):
    fx, fy, cx, cy = intrinsics
    return np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1]], dtype="d")


def dsec_calibration(doc, maps):
    arrays = {}
    width, height = DSEC_SIZE
    intrinsics = doc["intrinsics"]
    for side in SIDES:
        names = [name for name, spec in intrinsics.items() if spec["camera_type"] == "event"
                 and spec["camera_location"] == side and not spec["is_rectified"]]
        require(len(names) == 1, f"Expected one native DSEC {side} event camera")
        name = names[0]
        j = int(name.removeprefix("cam"))
        base, rect = intrinsics[name], intrinsics[f"camRect{j}"]
        require(tuple(base["resolution"]) == DSEC_SIZE and base["distortion_model"] == "radtan"
                and rect["camera_type"] == "event" and rect["is_rectified"], f"Unexpected DSEC {side} camera")
        k, p = (camera_matrix(c["camera_matrix"]) for c in (base, rect))
        dist = np.asarray(base["distortion_coeffs"], "d")
        rotation = np.asarray(doc["extrinsics"][f"R_rect{j}"], "d")
        mx, my = cv2.initUndistortRectifyMap(k, dist, rotation, p, DSEC_SIZE, cv2.CV_32FC1)
        official = maps[side]
        require(official.shape == (height, width, 2), f"Unexpected DSEC {side} rectification map shape")
        y, x = np.mgrid[:height:4, :width:4]
        coords = np.column_stack((x.ravel(), y.ravel())).astype("d")
        direct = cv2.undistortPoints(coords[:, None, :], k, dist, R=rotation, P=p).reshape(-1, 2)
        require(np.max(np.abs(direct - official[y, x].reshape(-1, 2))) < .02,
                f"DSEC {side} calibration disagrees with the official rectification map")
        arrays[f"inverse_{side}_x"] = mx
        arrays[f"inverse_{side}_y"] = my
        arrays[f"forward_{side}"] = official.astype("f")
    return arrays


def dsec_events(h5, indices, cut):
    offset = int(h5["t_offset"][()])
    first, last = indices
    group = h5["events"]
    times, _ = native_window(group["t"], first, last, cut - 20000 - offset, cut - offset,
                             lambda values: values.astype("i8"))
    selected = slice(first, last)
    xy = np.column_stack((group["x"][selected], group["y"][selected]))
    pol = group["p"][selected]
    require(np.isin(pol, [0, 1]).all(), "Invalid DSEC polarity")
    return event_rows(times + offset, xy, pol, cut, DSEC_SIZE)


def rebuild_dsec(recording, pins, missing, cal, outputs, access):
    with ExitStack() as stack:
        coarse, coarse_access = ranged(stack, DSEC_COARSE, access)
        entries = directory(coarse)
        coarse_access["members"] = []
        events, maps = {}, {}
        for side in SIDES:
            eye, _ = ranged(stack, pins[f"events_{side}.zip"], access)
            eye_entries = directory(eye)
            filenames = (["events.h5"] if missing else []) + (["rectify_map.h5"] if cal else [])
            for filename in filenames:
                target = entries[f"{recording}/events/{side}/{filename}"]
                original = eye_entries[filename]
                require((target.file_size, target.CRC) == (original.file_size, original.CRC),
                        f"DSEC coarse and individual ZIP members disagree at {target.filename}")
                stream, details = member(coarse, target, block=262144)
                coarse_access["members"].append(details)
                handle = open_hdf5(stack, stream)
                if filename == "events.h5":
                    events[side] = handle
                else:
                    maps[side] = handle["rectify_map"][()]
        if cal:
            source, _ = ranged(stack, pins["calibration.zip"], access)
            with zipfile.ZipFile(io.BytesIO(source.fetch(0, source.size))) as archive:
                doc = yaml.safe_load(archive.read("cam_to_cam.yaml"))
            outputs.append(save_packet(cal, dsec_calibration(doc, maps)))
        if missing:
            source, _ = ranged(stack, pins["disparity_timestamps.txt"], access)
            times = np.loadtxt(io.BytesIO(source.fetch(0, source.size)), dtype="i8").reshape(-1)
            source, evidence = ranged(stack, pins["disparity_event.zip"], access)
            stream = stack.enter_context(ByteFile(source))
            archive = stack.enter_context(zipfile.ZipFile(stream))
            images = sorted((n for n in archive.namelist() if n.endswith(".png")), key=lambda n: int(Path(n).stem))
            require(len(images) == len(times) and len(set(images)) == len(images)
                    and np.all(times[1:] > times[:-1]), "Unexpected DSEC disparity frame index")
            evidence["members"] = []
            for target, row in missing.items():
                i = selected_index(len(times), row["q"], 100, row["total"], row["index"])
                cut = int(times[i]) + 10000
                require(int(times[i]) == row["timestamp"] and cut == row["cut"] and images[i] == row["png"],
                        f"DSEC disparity selection changed for {target.path.name}")
                image = cv2.imdecode(np.frombuffer(archive.read(images[i]), "u1"), cv2.IMREAD_UNCHANGED)
                evidence["members"].append(images[i])
                require(image is not None and image.dtype == np.uint16 and image.shape == DSEC_SIZE[::-1],
                        f"Unexpected DSEC disparity image {images[i]}")
                arrays = {"disparity_png": image}
                for side in SIDES:
                    arrays[side] = dsec_events(events[side], row["indices"][side], cut)
                outputs.append(save_packet(target, arrays))


def mvsec_calibration(setting, archive):
    arrays = {}
    width, height = MVSEC_SIZE
    doc = yaml.safe_load(archive.read(f"camchain-imucam-{setting}.yaml"))
    for j, side in enumerate(SIDES):
        cam = doc[f"cam{j}"]
        require(tuple(cam["resolution"]) == MVSEC_SIZE and cam["distortion_model"] == "equidistant",
                f"Unexpected MVSEC {side} camera")
        k = camera_matrix(cam["intrinsics"])
        dist = np.asarray(cam["distortion_coeffs"], "d")
        r, p = (np.asarray(cam[key], "d") for key in ("rectification_matrix", "projection_matrix"))
        arrays[f"P_{side}"] = p
        mx, my = cv2.fisheye.initUndistortRectifyMap(k, dist, r, p[:, :3], MVSEC_SIZE, cv2.CV_32FC1)
        arrays[f"inverse_{side}_x"] = mx
        arrays[f"inverse_{side}_y"] = my
        maps = [np.loadtxt(io.BytesIO(archive.read(f"{setting}_{side}_{axis}_map.txt"))) for axis in "xy"]
        official = np.stack(maps, axis=-1)
        require(official.shape == (height, width, 2), f"Unexpected MVSEC {side} rectification map shape")
        y, x = np.mgrid[:height:5, :width:5]
        coords = np.column_stack((x.ravel(), y.ravel())).astype("d")
        direct = cv2.fisheye.undistortPoints(coords[:, None, :], k, dist, R=r, P=p[:, :3]).reshape(-1, 2)
        require(np.max(np.abs(direct - official[y, x].reshape(-1, 2))) < .01,
                f"MVSEC {side} calibration disagrees with the official rectification map")
        arrays[f"forward_{side}"] = official.astype("f")
    p1, p2 = arrays["P_left"], arrays["P_right"]
    require(np.allclose(p1[:, :3], p2[:, :3]) and np.isclose(p1[0, 3], 0) and p2[0, 3] < 0,
            "Unexpected MVSEC stereo projection matrices")
    return arrays


def mvsec_events(cam, row, cut):
    events = cam["events"]
    require(events.shape == (row["n"], 4), "MVSEC event source shape changed")
    # The reader trims to 20 ms after loading this locked 50 ms source packet.
    times, selected = native_window(events, row["start"], row["end"], cut - 50000, cut,
                                    lambda block: np.rint(block[:, 2] * 1e6).astype("i8"))
    pol = selected[:, 3]
    require(np.isin(pol, [-1, 0, 1]).all() and not ((pol < 0).any() and (pol == 0).any())
            and np.unique(pol).tolist() == row["polarity_values"], "MVSEC polarity changed")
    return event_rows(times, selected[:, :2], pol > 0, cut, MVSEC_SIZE)


def rebuild_mvsec(setting, pins, missing, cal, outputs, access):
    if cal:
        url = f"https://visiondata.cis.upenn.edu/mvsec/{setting}/{setting}_calib.zip"
        sha256 = MVSEC_CAL_SHA[setting]
        with tempfile.SpooledTemporaryFile(max_size=8 * 1024**2) as stream:
            size = download(url, stream)
            stream.seek(0)
            check_hash(hashlib.file_digest(stream, "sha256").hexdigest(), sha256, url)
            with zipfile.ZipFile(stream) as archive:
                arrays = mvsec_calibration(setting, archive)
        access.append({"url": url, "sha256": sha256, "bytes_read": size, "method": "download"})
        outputs.append(save_packet(cal, arrays))
    if not missing:
        return
    with ExitStack() as stack:
        data, gt = (open_hdf5(stack, ByteFile(ranged(stack, pins[key], access)[0])) for key in ("data", "gt"))
        depth = gt["davis/left/depth_image_rect"]
        times = gt["davis/left/depth_image_rect_ts"][()].reshape(-1)
        require(depth.shape == (len(times), *MVSEC_SIZE[::-1]) and np.isfinite(times).all()
                and np.all(times[1:] > times[:-1]), "Unexpected MVSEC depth frame index")
        for target, row in missing.items():
            i = selected_index(len(times), row["q"], 100, row["frames"], row["index"])
            timestamp = int(np.rint(times[i] * 1e6))
            cut = timestamp + 10000
            require((timestamp, cut) == (row["ts_us"], row["cut_us"]),
                    f"MVSEC depth selection changed for {target.path.name}")
            arrays = {"depth": np.asarray(depth[i], "f")}
            for side in SIDES:
                arrays[side] = mvsec_events(data[f"davis/{side}"], row["events"][side], cut)
            outputs.append(save_packet(target, arrays))


def m3ed_calibration(cam, side):
    cal = cam["calib"]
    k = np.asarray(cal["intrinsics"][()], "d")
    dist = np.asarray(cal["distortion_coeffs"][()], "d")
    transform = cal["T_to_prophesee_left"][()]
    require(tuple(cal["resolution"][()]) == M3ED_SIZE and cal["distortion_model"][()] == b"radtan"
            and k.shape == dist.shape == (4,) and np.isfinite(k).all() and np.isfinite(dist).all()
            and (k[:2] > 0).all() and transform.shape == (4, 4) and np.isfinite(transform).all(),
            f"Invalid M3ED {side} calibration")
    if side == "left":
        require(np.allclose(transform, np.eye(4), atol=1e-7), "Unexpected M3ED left transform")
    return {f"K_{side}": k, f"dist_{side}": dist, f"T_{side}": transform}


def m3ed_events(cam, start, end):
    stamps, locator = cam["t"], cam["ms_map_idx"]
    count = len(stamps)
    require(all(cam[key].shape == (count,) for key in ("t", "x", "y", "p"))
            and all(cam[key].dtype.kind in "iu" for key in ("t", "x", "y", "ms_map_idx"))
            and locator.ndim == 1, "Unexpected M3ED event fields")
    i, j = start // 1000, (end + 999) // 1000
    require(0 <= i <= j < len(locator), "M3ED window outside millisecond index")
    offsets = locator[i:j + 1].astype("i8")
    low, high = int(offsets[0]), int(offsets[-1])
    require(0 <= low <= high <= count and np.all(offsets[1:] >= offsets[:-1]), "Invalid M3ED event offsets")
    origin = max(0, low - 1)
    times = stamps[origin:min(high + 1, count)].astype("i8")
    require((times >= 0).all() and (low == 0 or times[0] < start)
            and (high == count or times[-1] >= end), "M3ED index does not bracket the window")
    first, last = window_bounds(times, start, end)
    selected = slice(origin + first, origin + last)
    xy = np.column_stack((cam["x"][selected], cam["y"][selected]))
    pol = cam["p"][selected]
    require(np.isin(pol, [0, 1]).all(), "Invalid M3ED polarity")
    return event_rows(times[first:last], xy, pol, end, M3ED_SIZE)


def rebuild_m3ed(pins, missing, outputs, access):
    with ExitStack() as stack:
        handles = {}
        for key in ("data", "depth_gt"):
            pin = pins[key]
            source, _ = ranged(stack, pin, access)
            handle = open_hdf5(stack, ByteFile(source, block=262144))
            version = handle.attrs.get("version")
            if isinstance(version, bytes):
                version = version.decode("utf-8", errors="replace")
            require(version == pin["release"], f"Unexpected M3ED release {version!r} at {source.url} /@version")
            handles[key] = handle
        gt = handles["depth_gt"]
        times, poses, depth = (gt[key] for key in ("ts", "Cn_T_C0", "depth/prophesee/left"))
        n = len(times)
        require(times.shape == (n,) and times.dtype.kind in "iu" and poses.shape == (n, 4, 4)
                and depth.shape == (n, *M3ED_SIZE[::-1]), "Unexpected M3ED depth/pose/timestamp shapes")
        cams = {side: handles["data"][f"prophesee/{side}"] for side in SIDES}
        calibration = {}
        for side, cam in cams.items():
            calibration.update(m3ed_calibration(cam, side))
        for target, row in missing.items():
            i = selected_index(n, row["j"], 10, row["n_depth"], row["idx"])
            timestamp = int(times[i])
            require(timestamp == row["t"], f"M3ED depth selection changed for {target.path.name}")
            arrays = dict(calibration, depth=depth[i].astype("f"))
            for side, cam in cams.items():
                arrays[side] = m3ed_events(cam, timestamp - 10000, timestamp + 10000)
                require(len(arrays[side]) == row["events"][side], f"M3ED {side} event count changed")
            outputs.append(save_packet(target, arrays))


def esot_packets(path):
    import aedat

    for packet in aedat.Decoder(str(path)):
        events = packet.get("events")
        if events is not None and len(events):
            yield events


def esot_windows(packets, source_sha):
    first = last = None
    for events in packets():
        lo, hi = int(events["t"][0]), int(events["t"][-1])
        require(last is None or lo >= last, "Out-of-order ESOT packets")
        if first is None:
            first = lo
        last = hi
    require(first is not None and (last - first) // 40000 >= 24, "ESOT source cannot supply 24 windows")
    anchors = np.linspace(first + 20000, last - 20000, 24).round().astype(np.int64)
    require(np.all(np.diff(anchors) >= 40000), "Overlapping ESOT windows")
    parts = [[] for _ in anchors]
    for events in packets():
        times = events["t"].astype(np.int64)
        first_anchor = np.searchsorted(anchors, times[0] - 20000, side="right")
        last_anchor = np.searchsorted(anchors, times[-1] + 20000, side="right")
        require(np.all(times[1:] >= times[:-1]), "Out-of-order ESOT events")
        for k in range(first_anchor, last_anchor):
            anchor = anchors[k]
            i, j = np.searchsorted(times, [anchor - 20000, anchor + 20000])
            if i < j:
                selected = events[i:j]
                parts[k].append(np.column_stack((times[i:j] - anchor, selected["x"],
                                                  selected["y"], selected["on"])).astype(np.int32))
    arrays = {"anchors": anchors, "source_sha": source_sha}
    for k, part in enumerate(parts):
        arrays[f"w{k}"] = np.concatenate(part) if part else np.empty((0, 4), np.int32)
    return arrays


def rebuild_esot(root, row, outputs, access):
    target = LockedFile(root / FOLDERS["esot"] / row["file"], row["packet_sha256"])
    if target.cached():
        outputs.append(target.receipt("verified_cache"))
        return
    source_folder = "esot500" if row["sensor"] == "L" else "temporal/H"
    filename = row["name"] + ".aedat4"
    url = f"{row['base']}/aedat4/{filename}"
    raw = LockedFile(root / source_folder / filename, row["sha256"], row["bytes"])
    if raw.cached():
        receipt = raw.receipt("verified_cache")
        bytes_read = 0
    else:
        receipt = raw.publish(lambda stream: download(url, stream, raw.size))
        bytes_read = raw.size
    access.append(dict(receipt, url=url, size=raw.size, bytes_read=bytes_read))
    outputs.append(save_packet(target, esot_windows(lambda: esot_packets(raw.path), raw.sha256), compressed=False))


def selected_index(count, quantile, scale, pinned_count, pinned_index):
    index = (count - 1) * quantile // scale
    require(count == pinned_count and 0 <= index < count and index == pinned_index,
            f"Source frame count or selection changed: {count} frames, index {index}")
    return index


def fraction_index(domain, fraction):
    """Accept decimal fractions, integer percentages and M3ED's tenths indices."""
    try:
        value = Decimal(str(fraction))
    except InvalidOperation as exc:
        raise RestoreError(f"Invalid fraction {fraction!r}") from exc
    require(value.is_finite(), f"Invalid fraction {fraction!r}")
    if value in (20, 50, 80):
        value /= 100
    elif domain == "m3ed" and value in (2, 5, 8):
        value /= 10
    require(value in (Decimal("0.2"), Decimal("0.5"), Decimal("0.8")), "Fraction must be 0.2, 0.5 or 0.8")
    return int(value * (10 if domain == "m3ed" else 100))


def restore(domain, recording, data_root, fraction=None):
    require(domain in FOLDERS, f"Unknown domain {domain!r}")
    root = Path(data_root)
    manifest = HERE / ("occupancy-packets.json" if domain == "esot" else "packets.json")
    content = manifest.read_bytes()
    roster = json.loads(content)
    outputs, access = [], []
    if domain == "esot":
        require(fraction is None, "ESOT recordings always restore all 24 windows")
        rows = [row for row in roster if recording in (row["name"], Path(row["file"]).stem)]
        require(len(rows) == 1, f"Unknown or ambiguous locked ESOT recording {recording!r}")
        rebuild_esot(root, rows[0], outputs, access)
    else:
        row_key = "j" if domain == "m3ed" else "q"
        selected = fraction_index(domain, fraction) if fraction is not None else None
        rows = {name: entry for name, entry in roster[domain].items() if entry["recording"] == recording
                and (selected is None or entry["row"][row_key] == selected)}
        require(rows, f"Unknown locked {domain} recording or fraction for {recording!r}")
        first = next(iter(rows.values()))
        folder = root / FOLDERS[domain]
        setting = recording.rstrip("0123456789") if domain == "mvsec" else recording
        missing = {}
        for filename, entry in sorted(rows.items()):
            target = LockedFile(folder / filename, entry["sha256"])
            if target.cached():
                outputs.append(target.receipt("verified_cache"))
            else:
                missing[target] = entry["row"]
        cal = None
        if "cal_sha256" in first:
            cal = LockedFile(folder / (setting + "-cal.npz"), first["cal_sha256"])
            if cal.cached():
                outputs.append(cal.receipt("verified_cache"))
                cal = None
        if missing or cal:
            pins = first["objects"]
            if domain == "dsec":
                rebuild_dsec(recording, pins, missing, cal, outputs, access)
            elif domain == "mvsec":
                rebuild_mvsec(setting, pins, missing, cal, outputs, access)
            else:
                rebuild_m3ed(pins, missing, outputs, access)
    return {"domain": domain, "recording": recording, "fraction": fraction,
            "manifest": manifest.name, "manifest_sha256": hashlib.sha256(content).hexdigest(),
            "outputs": outputs, "sources": access}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.split("\n", 1)[0])
    parser.add_argument("--domain", choices=FOLDERS, required=True)
    parser.add_argument("--recording", required=True, help="locked recording name (ESOT also accepts sensor_name)")
    parser.add_argument("--data-root", type=Path, required=True, help="dataset root used by the benchmarks")
    parser.add_argument("--fraction", help="0.2, 0.5 or 0.8 (defaults to all locked packets for the recording)")
    options = parser.parse_args(argv)
    try:
        receipt = restore(options.domain, options.recording, options.data_root, options.fraction)
    except (ValueError, OSError, KeyError, RuntimeError, zipfile.BadZipFile, yaml.YAMLError) as exc:
        parser.exit(1, f"restore {options.domain}/{options.recording}: {exc}\n")
    print(json.dumps(receipt, sort_keys=True))


if __name__ == "__main__":
    main()
