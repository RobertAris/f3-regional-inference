"""Locate sampled decoder crossovers on identical fixed packets and query layouts."""

import copy
import json
import time

import numpy as np
import torch

from followup.multitask.bench import environment, parser, setup, sync, host
from followup.multitask.data import load, paths
from followup.multitask.feature_bench import layouts
from followup.multitask.provenance import pin
from query_f3.binding import digest
from query_f3.multitask.attention import use_sdpa
from query_f3.multitask.batched_decoders import fast_depth_regions, fast_seg_regions
from query_f3.multitask.decoders import depth_context, seg_context
from query_f3.multitask.fusion import FoldedSegformer
from query_f3.multitask.lookup import build_lookup
from query_f3.multitask.models import dense_output
from query_f3.multitask.service import encoder_field, gather_yx, packet


@torch.inference_mode()
def run(opt):
    torch.set_num_threads(4)
    enc, head = setup(opt)
    enc16 = copy.deepcopy(enc).half()
    half = copy.deepcopy(head).half()
    if opt.task == "semantics":
        head, half = (use_sdpa(h, opt.task) for h in (head, half))
        for m in (head, half):
            m.folded = FoldedSegformer(m)
    (file,) = [f for f in paths(opt.domain, opt.split, opt.data) if f.stem == opt.packet]
    size, ev, _, _, counts = load(opt.domain, file)
    events = ev["left"]
    table = build_lookup(enc, size) if opt.lookup else None
    modes = ["dense", "batched", "dense-half", "batched-half"]
    results = []
    rng = np.random.default_rng(419)
    for extent in (8, 32, 96):
        for count in (1, 4, 16, 64):
            for layout in ("dispersed", "clustered"):

                def call(mode):
                    boxes = layouts(events, size, extent, count, layout)
                    grid = packet(events, size, table).grid(enc)
                    trunk, h = (enc16, half) if mode.endswith("-half") else (enc, head)
                    field = encoder_field(trunk, grid.to(next(trunk.parameters()).dtype)).transpose(2, 3)
                    if mode.startswith("batched"):
                        ctx, regions = (
                            (depth_context, fast_depth_regions)
                            if opt.task == "depth"
                            else (seg_context, fast_seg_regions)
                        )
                        tiles = regions(h, ctx(h, field), boxes)
                    else:
                        if opt.task == "semantics":
                            states = h.segformer(field, output_hidden_states=True).hidden_states
                            native = h.folded(states, field.shape[-2:])
                        else:
                            native = dense_output(opt.task, h, field)
                        tiles = gather_yx(native, boxes)
                    return host(tiles)

                ref = call("dense")
                arms = {}
                for mode in modes:
                    output = call(mode)
                    finite = bool(np.isfinite(output).all())
                    arms[mode] = dict(
                        finite=finite,
                        ms=[],
                        relative_rms=(
                            float(
                                np.linalg.norm((output - ref).astype("d").ravel())
                                / max(1e-12, np.linalg.norm(ref.astype("d").ravel()))
                            )
                            if finite
                            else None
                        ),
                    )
                for _ in range(opt.repeats):
                    for mode in rng.permutation(modes):
                        sync(opt.device)
                        start = time.perf_counter()
                        call(mode)
                        sync(opt.device)
                        arms[mode]["ms"].append(1000 * (time.perf_counter() - start))
                results.append(dict(count=count, extent=extent, layout=layout, arms=arms))
    out = dict(
        task=opt.task,
        domain=opt.domain,
        packet=file.name,
        sha256=digest(file),
        size=size,
        events=counts,
        lookup=opt.lookup,
        rows=results,
        env=environment(opt.device),
        provenance=pin(opt.upstream),
    )
    opt.out.parent.mkdir(parents=True, exist_ok=True)
    with opt.out.open("x") as f:
        json.dump(out, f, allow_nan=False, separators=(",", ":"))
        f.write("\n")
    print(opt.out.name, flush=True)


if __name__ == "__main__":
    p = parser()
    p.add_argument("--packet", required=True)
    run(p.parse_args())
