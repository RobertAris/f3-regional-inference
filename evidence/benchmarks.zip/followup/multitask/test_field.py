"""CPU checks for native batched field and flow suffixes."""

import unittest
from unittest.mock import patch

import torch
from torch import nn

from query_f3.depth_context import Context, prefix
from query_f3.engine import trace
from query_f3.norm_block import apply_block
from query_f3.quadrature.batch import batched_suffix


class Block(nn.Module):
    """Small ConvNeXtV2-style block with nonzero GRN parameters."""

    def __init__(self, channels, kernel):
        super().__init__()
        hidden = 2 * channels
        self.dwconv = nn.Conv2d(
            channels, channels, kernel, padding=kernel // 2, groups=channels
        )
        self.norm = nn.LayerNorm(channels)
        self.pwconv1 = nn.Linear(channels, hidden)
        self.act = nn.GELU()
        self.grn = nn.Module()
        self.grn.gamma = nn.Parameter(torch.linspace(0.1, 0.4, hidden))
        self.grn.beta = nn.Parameter(torch.linspace(-0.2, 0.1, hidden))
        self.pwconv2 = nn.Linear(hidden, channels)
        self.drop_path = nn.Identity()


class BatchedSuffixTest(unittest.TestCase):
    rectangles = (
        (0, 0, 4, 3), (37, 0, 4, 3), (0, 34, 4, 3), (37, 34, 4, 3),
        (17, 17, 4, 3), (19, 18, 4, 3), (17, 17, 4, 3),
    )
    single_pixels = ((0, 36, 1, 1), (40, 0, 1, 1), (20, 18, 1, 1))

    @classmethod
    def setUpClass(cls):
        cls.addClassCleanup(torch.set_num_threads, torch.get_num_threads())
        torch.set_num_threads(1)
        channels = 3
        with torch.random.fork_rng(devices=[]):
            torch.random.default_generator.manual_seed(421)
            cls.enc = nn.Module()
            cls.enc.downsample_layers = nn.ModuleList(
                nn.Conv2d(channels, channels, 1) for _ in range(3)
            )
            cls.enc.stages = nn.ModuleList(
                nn.Sequential(*(Block(channels, 7) for _ in range(count)))
                for count in (2, 1, 3)
            )
            cls.head = nn.Module()
            cls.head.decoder = nn.Sequential(*(Block(channels, 9) for _ in range(4)))
            cls.head.pred = nn.Conv2d(channels, 2, 1)
            grid = torch.randn(1, channels, 41, 37, dtype=torch.float64)

        cls.enc.double().eval().requires_grad_(False)
        cls.head.double().eval().requires_grad_(False)
        cls.blocks = [block for stage in cls.enc.stages for block in stage]
        cls.prefixes = prefix(cls.enc, grid, depths=range(1, 7))
        cls.field, _, cls.gains = trace(cls.enc, None, grid)
        cls.flow_field, cls.flow, cls.flow_gains = trace(cls.enc, cls.head, grid)

    def context(self, depth, *, flow=False):
        state, _ = self.prefixes[depth]
        return Context(depth, state, self.flow_gains if flow else self.gains)

    def assert_matches_crops(self, actual, dense, rects):
        expected = torch.cat([
            dense[..., x : x + width, y : y + height]
            for x, y, width, height in rects
        ])
        torch.testing.assert_close(actual, expected, rtol=1e-10, atol=1e-10)

    def test_field_matches_dense_at_every_split(self):
        for depth in range(1, 7):
            for rects in (self.rectangles, self.single_pixels):
                _, _, width, height = rects[0]
                with self.subTest(depth=depth, extent=(width, height)):
                    with patch("query_f3.quadrature.batch.apply_block", wraps=apply_block) as run:
                        field, flow = batched_suffix(self.enc, None, self.context(depth), rects)
                    self.assertIsNone(flow)
                    self.assert_matches_crops(field, self.field, rects)
                    self.assertEqual(run.call_count, 6 - depth)
                    for block_index, call in enumerate(run.call_args_list, start=depth):
                        halo = 3 * (6 - block_index)
                        self.assertIs(call.args[0], self.blocks[block_index])
                        self.assertIs(call.kwargs["fixed"], self.gains[block_index])
                        self.assertEqual(
                            call.args[1].shape[-2:], (width + 2 * halo, height + 2 * halo)
                        )

    def test_flow_matches_dense_at_legacy_splits(self):
        for depth in range(3, 7):
            with self.subTest(depth=depth):
                field, flow = batched_suffix(
                    self.enc, self.head, self.context(depth, flow=True), self.rectangles
                )
                self.assert_matches_crops(field, self.flow_field, self.rectangles)
                self.assert_matches_crops(flow, self.flow, self.rectangles)

    def test_invalid_rectangles(self):
        invalid = {
            "empty batch": [],
            "wrong arity": [(0, 0, 1)],
            "fractional coordinate": [(0.5, 0, 1, 1)],
            "negative origin": [(-1, 0, 1, 1)],
            "right overrun": [(40, 0, 2, 1)],
            "bottom overrun": [(0, 36, 1, 2)],
            "zero width": [(0, 0, 0, 1)],
            "negative height": [(0, 0, 1, -1)],
            "mixed extents": [(0, 0, 4, 3), (1, 1, 3, 4)],
        }
        for name, rects in invalid.items():
            with self.subTest(case=name), self.assertRaisesRegex(ValueError, "ROI"):
                batched_suffix(self.enc, None, self.context(3), rects)

    def test_invalid_field_context(self):
        state, _ = self.prefixes[6]
        for depth in (0, 7, 1.0):
            with self.subTest(depth=depth), self.assertRaisesRegex(ValueError, "from 1 to 6"):
                batched_suffix(self.enc, None, Context(depth, state, self.gains), self.single_pixels)

        for invalid_state in (state[0], state.expand(2, -1, -1, -1), state[..., :0]):
            with self.subTest(shape=invalid_state.shape), self.assertRaisesRegex(ValueError, "state"):
                ctx = Context(6, invalid_state, self.gains)
                batched_suffix(self.enc, None, ctx, self.single_pixels)

        invalid_gains = {
            "missing": None,
            "five": self.gains[:-1],
            "seven": [*self.gains, self.gains[-1]],
            "ten": self.flow_gains,
            "empty vector": [*self.gains[:-1], self.gains[-1][:0]],
            "matrix": [*self.gains[:-1], self.gains[-1][None]],
        }
        for name, gains in invalid_gains.items():
            with self.subTest(case=name), self.assertRaisesRegex(ValueError, "six fixed"):
                batched_suffix(self.enc, None, Context(6, state, gains), self.single_pixels)

    def test_flow_keeps_legacy_context_validation(self):
        for depth in (1, 2, 3.0, 7):
            with self.subTest(depth=depth), self.assertRaisesRegex(ValueError, "from 3 to 6"):
                ctx = Context(depth, self.prefixes[3][0], self.flow_gains)
                batched_suffix(self.enc, self.head, ctx, self.single_pixels)
        with self.assertRaisesRegex(ValueError, "ten fixed"):
            batched_suffix(self.enc, self.head, self.context(3), self.single_pixels)
