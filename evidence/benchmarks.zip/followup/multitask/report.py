"""Generate the published result tables and figures from the checksummed observations."""

import argparse
from itertools import groupby
from pathlib import Path
from statistics import median

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from followup.multitask.replay import ARCHIVE, HERE, records, summarize

ROOT = HERE.parents[1]
DOMAINS = {
    "mvsec": "MVSEC",
    "dsec": "DSEC",
    "m3ed": "M3ED",
    "human": "DSEC manual night",
    "day": "DSEC daytime pseudo-labels",
    "L": "ESOT low resolution",
    "H": "ESOT high resolution",
}
NAMES = {
    "dense": "Native dense FP32",
    "released": "Upstream dense FP32",
    "sdpa": "Dense SDPA",
    "half": "Dense FP16",
    "mixed": "FP16 encoder, FP32 head",
    "folded": "Folded dense FP32",
    "folded-half": "Folded dense FP16",
    "batched": "Full context, batched native tail FP32",
    "batched-half": "Batched native tail FP16",
    "exact-eager": "Full context, individual crops",
    "ordinary": "Ordinary coarse",
    "hybrid-batched": "Coarse field + native regions",
    "crop-input": "Cropped packet and head",
    "crop": "Cropped encoder",
    "raw-sgbm": "Event-count SGBM",
    "raw": "Event surface patch matcher",
    "zero": "Zero disparity",
    "history": "Past event frequency",
    "oracle-3-2": "Native GRNs at split 3",
    "plain-3-2": "Uncorrected preview, split 3",
}
ORDER = [
    "released",
    "dense",
    "sdpa",
    "folded",
    "mixed",
    "half",
    "folded-half",
    "oracle-3-2",
    "exact-eager",
    "batched",
    "batched-half",
    "regional-1-2",
    "regional-3-2",
    "regional-5-2",
    "plain-3-2",
    "hybrid-batched",
    "ordinary",
    "crop",
    "crop-input",
    "raw",
    "raw-sgbm",
    "zero",
    "history",
]


def label(mode):
    if mode.startswith("regional-"):
        return "Projected preview, split " + mode.split("-")[1]
    return NAMES.get(mode, mode)


def fmt(x, digits=2):
    return "—" if x is None else f"{x:.{digits}f}"


def table(headers, rows):
    return [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
        *["| " + " | ".join(map(str, r)) + " |" for r in rows],
        "",
    ]


def modes(row):
    return ((m, row["arms"][m]) for m in ORDER if m in row["arms"])


def accuracy(panels):
    lines = [
        "# Measurements by task",
        "",
        "Latency is the mean of recording means of per-packet median times, in milliseconds. Each packet uses three interleaved timing repeats on the M5 Max GPU. The finite column counts packets with finite outputs. Quality averages use the available finite observations. An em dash indicates an undefined or unmeasured quantity.",
        "",
    ]
    for key, row in panels.items():
        task, domain = key.split("/")
        lines += [
            f"## {task.capitalize()} on {DOMAINS[domain]}",
            "",
            f"{row['recordings']} recordings, {row['packets']} packets.",
            "",
        ]
        extra = {
            "features": ["Relative RMS (%)", "Worst relative RMS (%)"],
            "depth": ["Spearman ρ", "Defined ρ", "Normalized MAE", "Relative RMS (%)"],
            "semantics": ["mIoU (%)", "Pixel accuracy (%)", "Dense label agreement (%)", "Relative RMS (%)"],
            "occupancy": ["Log loss (bits)", "Brier score", "Dense logit RMSE"],
            "stereo": [
                "Disparity MAE (px)",
                "Within 1 px (%)",
                "Returned / valid",
                "Returned-only MAE",
                "Same as dense (%)",
            ],
        }[task]
        data = []
        for mode, a in modes(row):
            rms = fmt(100 * a["relative_rms"], 5) if "relative_rms" in a else "—"
            if task == "features":
                v = [rms, fmt(100 * a["worst_relative_rms"], 5)]
            elif task == "depth":
                v = [
                    fmt(a.get("rho"), 4),
                    str(a.get("defined_rho_packets", 0)),
                    fmt(a.get("normalized_mae"), 4),
                    rms,
                ]
            elif task == "semantics":
                v = [
                    fmt(100 * a[k], 3) if k in a else "—"
                    for k in ("miou", "pixel_accuracy", "label_agreement")
                ] + [rms]
            elif task == "occupancy":
                v = [fmt(a.get(k), 5) for k in ("bits", "brier", "logit_rmse")]
            else:
                v = [
                    fmt(a.get("mae"), 3),
                    fmt(100 * a["within1"], 2),
                    f"{a['returned']} / {a['n']}",
                    fmt(a["returned_mae"], 3),
                    fmt(100 * a["dense_match_agreement"]),
                ]
            data.append([label(mode), fmt(a.get("ms")), f"{a['finite']}/{a['packets']}", *v])
        lines += table(["Method", "ms", "Finite", *extra], data)
        if task == "depth":
            lines += [
                f"Whole-frame dense mean ρ {fmt(row['whole_rho'], 4)}. Regional accuracy uses the union of the event-selected boxes.",
                "",
            ]
        if task == "semantics":
            lines += [
                f"Whole-frame dense mIoU {fmt(100 * row['whole_miou'])}%. Constant road on the same queries {fmt(100 * row['constant_road_miou'])}%. The class mean excludes classes absent from both truth and prediction.",
                "",
            ]
        if task == "stereo":
            a = row["arms"]["dense"]
            lines += [
                f"{a['outside']} of {a['n']} labeled queries exceed the 48 px search range. MAE includes these queries. The SGBM search extends through 63 px. Abstentions receive zero disparity for the common-support MAE. Agreement covers every selected site, including sites without ground truth.",
                "",
            ]
        if task == "occupancy":
            lines += [
                f"Occupied bins comprise {fmt(100 * row['arms']['dense']['positive_rate'])}%. The largest difference between upstream whole-image and gathered 1 × 1 logits is {row['released_whole_worst_abs']:.3g}.",
                "",
            ]
        primary = "batched" if task in ("depth", "semantics") else "regional-3-2"
        a = row["arms"][primary]["vs_fastest_dense"]
        ci = a.get("interval95")
        interval = (
            f" (recording-group bootstrap 95% interval {ci[0]:.1f}% to {ci[1]:.1f}%)"
            if ci
            else " (one route group)"
        )
        lines += [
            f"{label(primary)} time saved against the fastest dense configuration finite on every packet, {label(row['fastest_finite_dense'])}, is {a['time_saved_percent']:.1f}%{interval}. Negative values mean longer latency. This descriptive comparator imposes no downstream-accuracy threshold.",
            "",
        ]
    return lines


def sweep_rows(grids, head=False):
    output = []
    for key, rs in sorted(grids.items()):
        for (extent, layout), rows in groupby(
            sorted(rs, key=lambda r: (r["extent"], r["layout"], r["count"])),
            key=lambda r: (r["extent"], r["layout"]),
        ):
            ratios = []
            for r in rows:
                a = r["arms"]
                reg = "batched" if head else "regional-3-2"
                ratios.append(fmt(median(a[reg]["ms"]) / median(a["dense"]["ms"]), 3))
            output.append([key, extent, layout, *ratios])
    return output


def systems(hw, grid, density, lookup, heads):
    out = [
        "## Sampled crossover",
        "",
        "Numbers are regional / native dense FP32 latency. Values below 1 favor regional execution. Each row holds packet, query extent and placement fixed while count increases. Nonmonotone rows retain every observed value. Each geometry uses one packet per resolution.",
        "",
    ]
    out += table(["Feature domain", "Square side", "Layout", "1", "4", "16", "64"], sweep_rows(grid))
    out += table(["Head / domain", "Square side", "Layout", "1", "4", "16", "64"], sweep_rows(heads, True))
    out += [
        "## Fixed-packet density and lookup",
        "",
        "The density experiment uniformly subsamples events before proposal selection. The location can therefore change with density. The table reports fresh-request medians.",
        "",
    ]
    out += table(
        [
            "DSEC fraction retained",
            "Dense FP32 ms",
            "Dense FP16 ms",
            "Split 3 ms",
            "Split 3 relative RMS (%)",
        ],
        [
            [
                k.split("-")[1],
                fmt(median(a["dense"]["ms"])),
                fmt(median(a["half"]["ms"])),
                fmt(median(a["regional-3-2"]["ms"])),
                fmt(100 * a["regional-3-2"]["relative_rms"], 3),
            ]
            for k, a in sorted(density.items())
        ],
    )
    out += table(
        ["Resident lookup", "Table MiB", "Setup ms", "Dense FP32 ms", "Dense FP16 ms", "Split 3 ms"],
        [
            [
                k,
                fmt(a["bytes"] / 2**20, 1),
                fmt(a["setup_ms"]),
                *[fmt(median(a["arms"][m]["ms"])) for m in ("dense", "half", "regional-3-2")],
            ]
            for k, a in sorted(lookup.items())
        ],
    )
    out += [
        "## Fresh requests, cached requests and memory",
        "",
        "Each row uses an isolated process and resident weights. Throughput is a timed sequence of serial fresh requests on the same input contents with the packet context rebuilt each time. Cached requests reuse that packet's context. Reported peaks are sampled at 2 ms and include loaded weights. RSS and Metal driver allocation overlap in unified memory. CPU rows have no Metal allocation. Both standalone MPS flow rows time the same dense flow head. Compare joint-dense with joint-batched for the cost of regional decoding on a shared field.",
        "",
    ]
    out += table(
        [
            "Configuration",
            "Fresh ms",
            "Cached ms",
            "Packets/s",
            "Peak RSS MiB",
            "Peak driver MiB",
            "Peak active tensor MiB",
        ],
        [
            [
                name,
                fmt(median(d["fresh_ms"])),
                fmt(median(d["cached_ms"]) if "cached_ms" in d else None),
                fmt(d["serial_packets_per_s"]),
                *[fmt(n / 2**20, 1) if n is not None else "—" for n in d["memory"]["peak"]],
            ]
            for name, d in sorted(hw.items())
        ],
    )
    return out


def figure(panels, grids, path):
    plt.rcParams.update(
        {"font.size": 8, "axes.spines.top": False, "axes.spines.right": False, "pdf.fonttype": 42}
    )
    fig, axes = plt.subplots(1, 2, figsize=(8.2, 3.15), layout="constrained")
    colors = {"mvsec": "#956029", "dsec": "#26796d", "m3ed": "#354e7d"}
    ax = axes[0]
    for domain, c in colors.items():
        a = panels["features/" + domain]["arms"]
        x = [a[f"regional-{k}-2"]["ms"] / a["half"]["ms"] for k in (1, 3, 5)]
        y = [100 * a[f"regional-{k}-2"]["relative_rms"] for k in (1, 3, 5)]
        ax.plot(x, y, "o-", c=c, label=DOMAINS[domain], ms=4)
        for xx, yy, k in zip(x, y, (1, 3, 5)):
            ax.annotate(str(k), (xx, yy), xytext=(3, 3), textcoords="offset points", fontsize=7)
    ax.axvline(1, c=".55", lw=0.8, ls="--")
    ax.set_yscale("log")
    ax.set_xlabel("Latency / dense FP16 latency")
    ax.set_ylabel("Relative feature RMS difference (%)")
    ax.legend(frameon=False)
    ax.set_title("Feature accuracy and native encoder split", loc="left", fontsize=10)
    ax = axes[1]
    for domain, c in colors.items():
        for style, layout in [("-", "dispersed"), ("--", "clustered")]:
            rows = sorted(
                (r for r in grids[domain] if r["extent"] == 32 and r["layout"] == layout),
                key=lambda r: r["count"],
            )
            ax.plot(
                [r["count"] for r in rows],
                [median(r["arms"]["merged-3-2"]["ms"]) / median(r["arms"]["half"]["ms"]) for r in rows],
                linestyle=style,
                marker=".",
                color=c,
            )
    ax.set_xscale("log", base=4)
    ax.set_xticks([1, 4, 16, 64], labels=["1", "4", "16", "64"])
    ax.axhline(1, c=".55", ls=":", lw=1)
    ax.set_xlabel("Requested 32 × 32 regions")
    ax.set_ylabel("Merged regional / dense FP16 latency")
    ax.set_title("Placement changes the crossover", loc="left", fontsize=10)
    from matplotlib.lines import Line2D

    ax.legend(
        handles=[
            Line2D([], [], c=".3", label="Dispersed"),
            Line2D([], [], c=".3", ls="--", label="Clustered"),
        ],
        frameon=False,
    )
    path.parent.mkdir(exist_ok=True, parents=True)
    fig.savefig(path, metadata={"CreationDate": None, "ModDate": None})
    plt.close(fig)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--archive", type=Path, default=ARCHIVE)
    p.add_argument("--check", action="store_true")
    args = p.parse_args()
    panels, hw, grid, density, lookup, heads = summarize(records(args.archive))
    content = "\n".join(accuracy(panels) + systems(hw, grid, density, lookup, heads)).rstrip() + "\n"
    tables = HERE / "tables.md"
    if args.check:
        if tables.read_text() != content:
            raise ValueError("Published tables differ from archive")
    else:
        tables.write_text(content)
        figure(panels, grid, ROOT / "paper/figures/feature-crossover.pdf")


if __name__ == "__main__":
    main()
