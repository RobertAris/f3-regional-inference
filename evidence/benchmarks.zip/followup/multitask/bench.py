"""Paired native-packet measurements of released F3 task services."""

import argparse
import copy
import hashlib
import json
import platform
from importlib.metadata import version
import subprocess
import time
from pathlib import Path

import cv2
import numpy as np
from scipy.stats import spearmanr
import torch
from torch.nn import functional as F

from followup.multitask.provenance import pin
from query_f3.binding import ROOT, digest
from query_f3.inference.loaders.published_f3 import load_published_f3
from query_f3.multitask.models import dense_output, load_global_head
from query_f3.multitask.service import (
    FeatureService,
    active_regions,
    encoder_field,
    gather_yx,
    global_regions,
    hybrid_field,
    packet,
)
from followup.multitask.data import load, paths

HERE = Path(__file__).resolve().parent
MODES = (
    "dense",
    "mixed",
    "folded",
    "folded-half",
    "sdpa",
    "half",
    "exact",
    "exact-eager",
    "exact-half",
    "ordinary",
    "crop",
    "crop-input",
    "hybrid",
    "hybrid-plain",
    "hybrid-1",
    "hybrid-5",
    "batched",
    "batched-half",
    "hybrid-batched",
)


def environment(device):
    return dict(
        torch=torch.__version__,
        numpy=np.__version__,
        python=platform.python_version(),
        platform=platform.platform(),
        device=device,
        threads=torch.get_num_threads(),
        packages={p: version(p) for p in ("transformers", "torchvision", "scipy", "psutil")},
        cpu=subprocess.check_output(["sysctl", "-n", "machdep.cpu.brand_string"], text=True).strip(),
    )


def setup(opt):
    enc = load_published_f3(opt.upstream, opt.weights, opt.device)
    enc.return_feat, enc.return_logits = True, False
    head = None
    if opt.task in ("semantics", "depth"):
        head = load_global_head(
            opt.task,
            opt.models / f"{opt.task}.pth",
            opt.weights,
            opt.upstream,
            opt.models / "segformer.json",
            opt.device,
        )
    return enc, head


def sync(device):
    if device == "mps":
        torch.mps.synchronize()


def host(tiles):
    return torch.cat(tiles).float().contiguous().cpu().numpy()


def semantic_scores(pred, gt):
    valid = (gt >= 0) & (gt < 11)
    ids = gt[valid].astype("i8") * 11 + pred.argmax(0)[valid]
    return dict(confusion=np.bincount(ids, minlength=121).reshape(11, 11).tolist(), n=int(valid.sum()))


def depth_scores(pred, gt):
    valid = np.isfinite(gt) & (gt > 0) & np.isfinite(pred)
    a, b = pred[valid], 1 / gt[valid]
    rho = None
    if len(a) > 1 and np.ptp(a) > 0 and np.ptp(b) > 0:
        rho = float(spearmanr(a, b).statistic)

    # Independent scale/shift normalization is standard for relative inverse depth.
    def standardized(v):
        centered = v - np.median(v)
        return centered / max(float(np.mean(np.abs(centered))), 1e-12)

    mae = float(np.mean(np.abs(standardized(a) - standardized(b)))) if len(a) else None
    return dict(rho=rho, normalized_mae=mae, n=int(len(a)))


def roi_scores(task, preds, ref, gt, boxes):
    seen = np.zeros(gt.shape, bool)
    truth, vals, refs = [], [], []
    for value, base, (x, y, w, h) in zip(preds, ref, boxes, strict=True):
        region = seen[y : y + h, x : x + w]
        rows, cols = region.shape
        fresh = ~region
        truth.append(gt[y : y + h, x : x + w][fresh])
        vals.append(value[:, :rows, :cols][:, fresh])
        refs.append(base[:, :rows, :cols][:, fresh])
        region[:] = True
    truth = np.concatenate(truth)
    vals, refs = np.concatenate(vals, 1), np.concatenate(refs, 1)
    # Agreement covers all requested native pixels including the unlabeled bottom strip.
    delta = np.concatenate([(v - b).astype("d").ravel() for v, b in zip(preds, ref, strict=True)])
    scale = np.sqrt(np.mean(np.concatenate([b.astype("d").ravel() for b in ref]) ** 2))
    out = dict(
        rms=float(np.sqrt(np.mean(delta**2))),
        max_abs=float(np.abs(delta).max()),
        relative_rms=float(np.sqrt(np.mean(delta**2)) / max(scale, 1e-12)),
    )
    if task == "semantics":
        out.update(
            semantic_scores(vals, truth),
            label_agreement=float(
                np.mean(
                    np.concatenate(
                        [(v.argmax(0) == b.argmax(0)).ravel() for v, b in zip(preds, ref, strict=True)]
                    )
                )
            ),
        )
    else:
        out.update(depth_scores(vals[0], truth))
    return out


def blind_baseline(task, label, boxes):
    # A constant road label is a common scene prior for driving semantics.
    if task == "semantics":
        mask = np.zeros(label.shape, dtype=bool)
        for x, y, w, h in boxes:
            mask[y : y + h, x : x + w] = True
        target = label[mask]
        valid = target < 11
        indices = target[valid].astype("i8") * 11 + 5
        return dict(
            confusion=np.bincount(indices, minlength=121).reshape(11, 11).tolist(), n=int(valid.sum())
        )
    return None


def global_call(task, enc, head, enc16, head16, events, size, mode, count, extent, service, split):
    boxes = active_regions(events, size, count, extent)
    p = packet(events, size, getattr(service, "table", None))
    if mode == "crop-input":
        from query_f3.engine import halo

        tiles = []
        for x, y, w, h in boxes:
            a, b, c, d = halo((x, y, w, h), size, 32)
            field = encoder_field(enc, p.grid(enc, (a, b, c, d))).transpose(2, 3)
            prediction = dense_output(task, head, field)
            tiles.append(prediction[..., y - b : y - b + h, x - a : x - a + w])
        return host(tiles)
    if mode.startswith("hybrid"):
        k = int(mode[-1]) if mode[-1].isdigit() else split
        projected = mode != "hybrid-plain"
        f = hybrid_field(
            enc, p, boxes, k, preview=service.projected if projected else service.plain, projected=projected
        )
    else:
        grid = p.grid(enc)
        if mode in ("half", "exact-half", "folded-half", "mixed", "batched-half"):
            f = encoder_field(enc16, grid.half())
            if mode != "mixed":
                head = head16
            else:
                f = f.float()
        else:
            f = encoder_field(enc, grid)
    strategy = {
        "exact-eager": "exact",
        "sdpa": "dense",
        "mixed": "dense",
        "half": "dense",
        "exact-half": "exact",
        "hybrid": "exact",
    }.get(mode, mode)
    if mode.startswith("hybrid"):
        strategy = "exact"
    if mode.startswith("folded"):
        field = f.transpose(2, 3)
        states = head.segformer(field, output_hidden_states=True).hidden_states
        out = gather_yx(head.folded(states, field.shape[-2:]), boxes)
    elif mode in ("batched", "batched-half", "hybrid-batched"):
        from query_f3.multitask.decoders import depth_context, seg_context
        from query_f3.multitask.batched_decoders import fast_depth_regions, fast_seg_regions

        prepare, regions = (
            (depth_context, fast_depth_regions) if task == "depth" else (seg_context, fast_seg_regions)
        )
        out = regions(head, prepare(head, f.transpose(2, 3)), boxes)
    else:
        out = global_regions(task, head, f.transpose(2, 3), boxes, strategy)
    return host(out)


def run_globals(opt, enc, head):
    from query_f3.multitask.attention import use_sdpa

    fast = use_sdpa(copy.deepcopy(head), opt.task)
    enc16, head16 = copy.deepcopy(enc).half(), use_sdpa(copy.deepcopy(head).half(), opt.task)
    if opt.task == "semantics":
        from query_f3.multitask.fusion import FoldedSegformer

        for model in (fast, head16):
            model.folded = FoldedSegformer(model)
    else:
        opt.modes = [m for m in opt.modes if not m.startswith("folded")]
    service = FeatureService()
    for file in paths(opt.domain, opt.split, opt.data):
        if opt.only_recording and file.stem.rsplit("-", 1)[0] != opt.only_recording:
            continue
        if opt.one and not file.stem.endswith(("-5", "-50")):
            continue
        size, ev, truth, _, counts = load(opt.domain, file)
        e = ev["left"]
        setup_ms = 0.0
        if opt.lookup and not hasattr(service, "table"):
            from query_f3.multitask.lookup import build_lookup

            sync(opt.device)
            start = time.perf_counter()
            service.table = build_lookup(enc, size)
            sync(opt.device)
            setup_ms = 1000 * (time.perf_counter() - start)
        boxes = active_regions(e, size, opt.count, opt.extent)
        out = opt.out / f"{opt.task}-{opt.domain}-{file.stem}.json"
        if out.exists():
            raise FileExistsError(out)
        p = packet(e, size)
        field = encoder_field(enc, p.grid(enc))
        dense = dense_output(opt.task, head, field.transpose(2, 3)).float().cpu().numpy()[0]
        ref = np.stack([dense[:, y : y + h, x : x + w] for x, y, w, h in boxes])
        if opt.task == "semantics":
            whole = semantic_scores(dense[:, : truth.shape[0]], truth)
        else:
            whole = depth_scores(dense[0], truth)
        del dense, field

        def call(mode):
            return global_call(
                opt.task,
                enc,
                head
                if mode in ("dense", "exact-eager")
                or (opt.task == "depth" and mode in ("mixed", "batched", "hybrid-batched"))
                else fast,
                enc16,
                head16,
                e,
                size,
                mode,
                opt.count,
                opt.extent,
                service,
                opt.depth_split,
            )

        rng = np.random.default_rng(
            int.from_bytes(hashlib.sha256(file.stem.encode()).digest()[:4], "little")
        )
        arms = {}
        for mode in rng.permutation(opt.modes):
            value = call(mode)
            finite = bool(np.isfinite(value).all())
            arms[mode] = dict(
                finite=finite, ms=[], **(roi_scores(opt.task, value, ref, truth, boxes) if finite else {})
            )
        for _ in range(opt.repeats):
            for mode in rng.permutation(opt.modes):
                sync(opt.device)
                start = time.perf_counter()
                value = call(mode)
                sync(opt.device)
                arms[mode]["ms"].append((time.perf_counter() - start) * 1000)
        payload = dict(
            task=opt.task,
            domain=opt.domain,
            split=opt.split,
            packet=file.name,
            sha256=digest(file),
            size=size,
            original_events=counts["left"],
            used_events=len(e),
            boxes=boxes,
            arms=arms,
            dense_whole=whole,
            constant=blind_baseline(opt.task, truth, boxes),
            environment=environment(opt.device),
            lookup=opt.lookup,
            lookup_setup_ms=setup_ms,
            lookup_bytes=(service.table.numel() * 4 if opt.lookup else 0),
            protocol=digest(HERE / "protocol.md"),
            code=digest(__file__),
            depth_split=opt.depth_split,
        )
        payload["provenance"] = pin(opt.upstream)
        out.write_text(json.dumps(payload, allow_nan=False, separators=(",", ":")) + "\n")
        print(file.stem, {m: round(np.median(a["ms"]), 1) for m, a in arms.items()}, flush=True)


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--task", choices=["depth", "semantics", "features", "stereo"], required=True)
    p.add_argument("--domain", required=True)
    p.add_argument("--split", choices=["development", "evaluation"], default="development")
    p.add_argument("--upstream", type=Path, default=ROOT.parent / "fast-feature-fields")
    p.add_argument(
        "--weights", type=Path, default=ROOT / "checkpoints/f3/patchff_fullcardaym3ed_small_20ms.pth"
    )
    p.add_argument("--models", type=Path, default=ROOT / "checkpoints/multitask")
    p.add_argument("--data", type=Path, default=ROOT / "datasets")
    p.add_argument("--device", choices=["mps", "cpu"], default="mps")
    p.add_argument("--modes", nargs="+", default=list(MODES), choices=MODES)
    p.add_argument("--depth-split", type=int, default=3)
    p.add_argument("--count", type=int, default=4)
    p.add_argument("--extent", type=int, default=48)
    p.add_argument("--repeats", type=int, default=3)
    p.add_argument("--lookup", action="store_true")
    p.add_argument("--only-recording", help="Run one named recording in this split")
    p.add_argument("--one", action="store_true", help="Only use each recording's middle packet")
    p.add_argument("--out", type=Path, required=True)
    return p


@torch.inference_mode()
def main():
    opt = parser().parse_args()
    opt.out.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(4)
    cv2.setNumThreads(1)
    if not paths(opt.domain, opt.split, opt.data):
        raise ValueError("Empty packet roster")
    enc, head = setup(opt)
    if head is None:
        raise ValueError("Use feature_bench for sparse feature tasks")
    run_globals(opt, enc, head)


if __name__ == "__main__":
    main()
