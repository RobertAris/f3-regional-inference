"""Time-selected, calibrated evaluation packets. Labels never enter query selection."""

import json
from pathlib import Path

import numpy as np

from query_f3.binding import ROOT, digest

FOLDERS = {
    "m3ed": "f3-opponent-stereo",
    "mvsec": "f3-stereo-transfer",
    "dsec": "f3-stereo-fusion",
    "human": "multitask",
    "day": "multitask",
}
DEV = {
    "m3ed": "car_forest_into_ponds_long",
    "mvsec": "indoor_flying1",
    "dsec": "interlaken_00_g",
    "human": "zurich_city_09_a",
    "day": "zurich_city_02_a",
}
SIZES = {
    "m3ed": (1280, 720),
    "mvsec": (346, 260),
    "dsec": (640, 480),
    "human": (640, 480),
    "day": (640, 480),
}


def paths(domain, split, root=ROOT / "datasets"):
    folder = root / FOLDERS[domain]
    names = sorted(json.loads(Path(__file__).with_name("packets.json").read_text())[domain])
    selected = [
        folder / n for n in names if (n.rsplit("-", 1)[0] == DEV[domain]) == (split == "development")
    ]
    if not selected or not all(f.is_file() for f in selected):
        raise FileNotFoundError(f"Incomplete {domain}/{split} roster in {folder}")
    return selected


def rectify(e, table, size):
    coords = np.rint(table[e[:, 2], e[:, 1]]).astype("i4")
    ok = ((coords >= 0) & (coords < size)).all(1)
    result = e[ok].copy()
    result[:, 1:3] = coords[ok]
    return result


def load(domain, path):
    name = path.stem.rsplit("-", 1)[0]
    receipt = json.loads(Path(__file__).with_name("packets.json").read_text())[domain][path.name]
    if digest(path) != receipt["sha256"]:
        raise ValueError(f"Packet hash mismatch at {path}")
    size = SIZES[domain]
    with np.load(path, allow_pickle=False) as z:
        events = {s: z[s] for s in ("left", "right") if s in z}
        label = (
            z["label"]
            if domain in ("human", "day")
            else z["disparity_png"] / 256
            if domain == "dsec"
            else z["depth"]
        )
    disparity = label if domain == "dsec" else None
    if domain in ("mvsec", "dsec"):
        stem = name.rstrip("0123456789") if domain == "mvsec" else name
        calfile = path.parent / (stem + "-cal.npz")
        if digest(calfile) != receipt["cal_sha256"]:
            raise ValueError(f"Calibration hash mismatch at {calfile}")
        with np.load(calfile, allow_pickle=False) as cal:
            events = {
                s: rectify(e[e[:, 0] >= -20000], cal["forward_" + s], size) for s, e in events.items()
            }
            if domain == "mvsec":
                with np.errstate(invalid="ignore", divide="ignore"):
                    disparity = -cal["P_right"][0, 3] / label + cal["P_left"][0, 2] - cal["P_right"][0, 2]
    counts = {s: len(e) for s, e in events.items()}
    for s, e in events.items():
        if len(e) and (e[:, 0].min() < -20000 or e[:, 0].max() >= 0 or (np.diff(e[:, 0]) < 0).any()):
            raise ValueError(path)
        if len(e) > 800000:
            events[s] = e[np.linspace(0, len(e) - 1, 800000, dtype=np.int64)]
    return size, events, label, disparity, counts
