"""Isolated fresh stereo requests with process RSS and MPS allocator sampling."""

import copy
import json
import threading
import time

import numpy as np
import torch

from followup.multitask.bench import environment, parser, setup, sync
from followup.multitask.data import paths, load
from followup.multitask.feature_bench import descriptors, raw_sgbm
from followup.multitask.hardware import memory
from followup.multitask.provenance import pin
from followup.multitask.stereo import boxes, match, raw_field, select_points
from query_f3.binding import digest
from query_f3.multitask.service import FeatureService, gather_xy


@torch.inference_mode()
def run(opt):
    torch.set_num_threads(4)
    engine = FeatureService()
    mode = opt.method
    if mode not in ("raw", "raw-sgbm"):
        enc, _ = setup(opt)
        half = copy.deepcopy(enc).half() if mode == "half" else None
    (file,) = [f for f in paths(opt.domain, opt.split, opt.data) if f.stem == opt.packet]
    size, events, _, _, counts = load(opt.domain, file)

    def fresh():
        pts = select_points(events["left"], size, count=opt.count)
        a, b = boxes(pts)
        if mode == "raw-sgbm":
            dense = raw_sgbm(events, size)
            return np.array([dense[y, x] for x, y in pts])
        if mode == "raw":
            l, r = (
                gather_xy(raw_field(events[side], size), rs)
                for side, rs in zip(("left", "right"), (a, b), strict=True)
            )
        else:
            l, r = (
                descriptors(engine, enc, half, events[side], size, rs, mode)
                for side, rs in zip(("left", "right"), (a, b), strict=True)
            )
        return match(l, r).float().cpu().numpy()

    sync(opt.device)
    if opt.device == "mps":
        torch.mps.empty_cache()
    before = memory(opt.device)
    peak = list(before)
    stop = threading.Event()

    def watch():
        while not stop.is_set():
            for i, v in enumerate(memory(opt.device)):
                peak[i] = max(v, peak[i])
            stop.wait(0.002)

    th = threading.Thread(target=watch, daemon=True)
    th.start()
    try:
        value = fresh()
        sync(opt.device)
        for i, v in enumerate(memory(opt.device)):
            peak[i] = max(peak[i], v)
    finally:
        stop.set()
        th.join()
    measured = []
    start = time.perf_counter()
    for _ in range(opt.repeats):
        t = time.perf_counter()
        fresh()
        sync(opt.device)
        measured.append((time.perf_counter() - t) * 1000)
    rate = opt.repeats / (time.perf_counter() - start)
    payload = dict(
        task="stereo",
        method=mode,
        packet=file.name,
        sha256=digest(file),
        size=size,
        events=counts,
        valid=bool(np.isfinite(value).all()),
        fresh_ms=measured,
        serial_packets_per_s=rate,
        memory=dict(baseline=before, peak=peak, sample_interval_ms=2),
        env=environment(opt.device),
        provenance=pin(opt.upstream),
    )
    opt.out.parent.mkdir(parents=True, exist_ok=True)
    with opt.out.open("x") as f:
        json.dump(payload, f, separators=(",", ":"), allow_nan=False)
        f.write("\n")
    print(opt.out.name, flush=True)


if __name__ == "__main__":
    p = parser()
    p.add_argument("--method", choices=["regional-3-2", "dense", "half", "raw", "raw-sgbm"], required=True)
    p.add_argument("--packet", required=True)
    run(p.parse_args())
