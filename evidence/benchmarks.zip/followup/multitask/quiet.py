"""Run a timed command while watching for another local accelerator workload on macOS."""

from pathlib import Path
import plistlib
import re
import subprocess
import sys
import time

import psutil


def gpu_jobs():
    clients = plistlib.loads(
        subprocess.check_output(["ioreg", "-ar", "-c", "AGXDeviceUserClient", "-d", "1"])
    )
    jobs = set()
    for client in clients:
        creator = client.get("IOUserClientCreator", "")
        if not client.get("CommandQueueCount"):
            continue
        match = re.match(r"pid (\d+), (.*)", creator, re.I)
        if match and re.search(
            r"python|llama|mlx|train|torch|blender|julia|tensorflow|whisper",
            match[2],
            re.I,
        ):
            jobs.add(int(match[1]))
    return jobs


def main():
    if sys.platform != "darwin":
        raise SystemExit("This compute-sharing monitor requires macOS IOKit")
    marker = Path(sys.argv[1])
    if gpu_jobs():
        marker.touch()
        print("External compute client already has a Metal command queue", flush=True)
        return 75
    proc = subprocess.Popen(sys.argv[2:])
    while True:
        try:
            return proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            jobs = gpu_jobs()
            if jobs:
                try:
                    own = {
                        proc.pid,
                        *(p.pid for p in psutil.Process(proc.pid).children(recursive=True)),
                    }
                except psutil.NoSuchProcess:
                    own = {proc.pid}
                if jobs - own:
                    marker.touch()
                    print(
                        "External Metal compute client joined; discarding this timed attempt",
                        flush=True,
                    )
                    proc.terminate()
                    proc.wait()
                    return 75


if __name__ == "__main__":
    sys.exit(main())
