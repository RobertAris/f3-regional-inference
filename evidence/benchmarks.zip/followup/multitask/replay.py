"""Recompute the multi-task tables from per-packet measurements without model weights."""

import argparse
from collections import defaultdict
from contextlib import nullcontext
import hashlib
import json
from pathlib import Path
from statistics import mean, median
import zipfile
import subprocess
from itertools import product

import numpy as np

HERE = Path(__file__).resolve().parent
ARCHIVE = HERE / "measurements.zip"
SOURCE_ARCHIVE = HERE / "measured-sources.zip"
ARCHIVED_REVISIONS = {
    "f6ebd5159dfdd02dd7babfd086f0b16dafe577d1",
    "6d0eacd460c943ff958daae4924c89b3b8c828cf",
}
DEV = {
    "dsec": "interlaken_00_g",
    "mvsec": "indoor_flying1",
    "m3ed": "car_forest_into_ponds_long",
    "human": "zurich_city_09_a",
    "day": "zurich_city_02_a",
}


def records(archive):
    with zipfile.ZipFile(archive) as z:
        checks = json.loads(z.read("manifest.json"))
        if len(z.namelist()) != len(checks) + 1 or set(z.namelist()) != set(checks) | {"manifest.json"}:
            raise ValueError("Unexpected measurement members")
        rows = []
        for name, sha in checks.items():
            buf = z.read(name)
            if hashlib.sha256(buf).hexdigest() != sha:
                raise ValueError(name)
            rows.append((name, json.loads(buf)))
        return rows


def iou(cm):
    a = np.asarray(cm, dtype="i8")
    union = a.sum(0) + a.sum(1) - a.diagonal()
    return float(np.mean(a.diagonal()[union > 0] / union[union > 0])) if np.any(union > 0) else None


def paired(times, reference, domain):
    names = sorted(set(times) & set(reference))
    if not names:
        return {}
    # Equal recording weights. Resample whole settings when multiple recordings belong to one.
    by_group = defaultdict(list)
    for name in names:
        g = name
        if domain == "human":
            g = "zurich_city_09"
        elif domain == "mvsec" and name.startswith("indoor_flying"):
            g = "indoor_flying"
        elif domain == "m3ed":
            g = name.split("_", 1)[0]  # acquisitions on the same physical platform
        by_group[g].append((times[name], reference[name]))
    groups = list(by_group.values())

    def effect(sets):
        all_pairs = np.asarray([p for group in sets for p in group])
        return float(100 * (1 - all_pairs[:, 0].sum() / all_pairs[:, 1].sum()))

    result = {"time_saved_percent": effect(groups), "recordings": len(names), "clusters": len(groups)}
    if len(groups) >= 2:
        rng = np.random.default_rng(2917)
        data = np.array([np.sum(group, axis=0) for group in groups])
        samples = data[rng.integers(0, len(groups), (4000, len(groups)))].sum(1)
        result["interval95"] = np.quantile(100 * (1 - samples[:, 0] / samples[:, 1]), [0.025, 0.975]).tolist()
    return result


def aggregate(rows, task, domain):
    samples = defaultdict(list)
    whole = []
    for doc in rows:
        if task == "occupancy":
            rec = doc["record"]["name"]
            arms = doc["arms"]
        else:
            rec = doc["packet"].rsplit("-", 1)[0]
            arms = doc["arms"] if task in ("semantics", "depth") else doc["rows"][0]["arms"]
        samples[rec].append(arms)
        if "dense_whole" in doc:
            whole.append(doc["dense_whole"])
    modes = set(next(iter(samples.values()))[0])
    if any(set(a) != modes for runs in samples.values() for a in runs):
        raise ValueError(f"Method set changed within {domain} {task}")
    output = {"recordings": len(samples), "packets": len(rows), "arms": {}}
    if whole and task == "semantics":
        output["whole_miou"] = iou(np.sum([s["confusion"] for s in whole], axis=0))
    elif whole:
        output["whole_rho"] = mean(s["rho"] for s in whole if s["rho"] is not None)
    if task == "semantics":
        output["constant_road_miou"] = iou(np.sum([d["constant"]["confusion"] for d in rows], axis=0))
    if task == "occupancy":
        output["released_whole_worst_abs"] = max(d["released_whole_logit_max_abs"] for d in rows)
    timings = {}
    for mode in sorted(modes):
        all_arms = [a[mode] for runs in samples.values() for a in runs]
        finite = [a for a in all_arms if a["finite"]]
        if any(not np.isfinite(v) or v <= 0 for a in all_arms for v in a["ms"]):
            raise ValueError("Invalid latency")
        metric = dict(finite=len(finite), packets=len(all_arms))
        # Timings include non-finite runs; quality statistics state finite-coverage explicitly.
        times = {
            r: mean(median(a[mode]["ms"]) for a in runs)
            for r, runs in samples.items()
            if all(a[mode]["ms"] for a in runs)
        }
        timings[mode] = times
        if times:
            metric.update(ms=mean(times.values()), serial_rate_from_latency=1000 / mean(times.values()))
        for k in (
            "relative_rms",
            "rho",
            "normalized_mae",
            "label_agreement",
            "bits",
            "brier",
            "logit_rmse",
        ):
            values = [a[k] for a in finite if a.get(k) is not None]
            if values:
                metric[k] = mean(values)
                if k == "rho":
                    metric["defined_rho_packets"] = len(values)
                if k == "relative_rms":
                    metric["worst_relative_rms"] = max(values)
        if any("max_abs" in a for a in finite):
            metric["worst_abs"] = max(a["max_abs"] for a in finite)
        if task == "depth":
            metric["valid_pixels"] = sum(a.get("n", 0) for a in finite)
        if task == "occupancy":
            metric["positive_rate"] = (
                sum(a["occupied"] for a in finite) / sum(a["n"] for a in finite) if finite else None
            )
        if any("confusion" in a for a in finite):
            cm = np.sum([a["confusion"] for a in finite], axis=0)
            metric.update(miou=iou(cm), pixels=int(cm.sum()), pixel_accuracy=float(np.trace(cm) / cm.sum()))
        if task == "stereo" and finite:
            n = sum(a["n"] for a in finite)
            if n:
                byrec = []
                for runs in samples.values():
                    usable = [a[mode] for a in runs if a[mode]["finite"]]
                    support = sum(a["n"] for a in usable)
                    if support:
                        byrec.append(sum(a["sum_error"] for a in usable) / support)
                metric.update(
                    n=n,
                    mae=sum(a["sum_error"] for a in finite) / n,
                    recording_mae=mean(byrec),
                    within1=sum(a["within1"] for a in finite) / n,
                    outside=sum(a["outside"] for a in finite),
                    returned=sum(a["valid_returns"] for a in finite),
                    returned_mae=sum(a["returned_sum_error"] for a in finite)
                    / max(1, sum(a["valid_returns"] for a in finite)),
                    dense_match_agreement=sum(a["same"] for a in finite)
                    / max(1, sum(len(a["estimates"]) for a in finite)),
                )
        output["arms"][mode] = metric
    for mode, metric in output["arms"].items():
        if mode != "dense" and "dense" in timings and metric["finite"] == len(rows):
            metric.update(paired(timings[mode], timings["dense"], domain))
    dense_modes = [
        m
        for m in ("dense", "released", "half", "sdpa", "mixed", "folded", "folded-half")
        if m in timings and output["arms"][m]["finite"] == len(rows)
    ]
    fastest = min(dense_modes, key=lambda m: output["arms"][m]["ms"])
    output["fastest_finite_dense"] = fastest
    for mode, metric in output["arms"].items():
        if timings[mode] and metric["finite"] == len(rows):
            metric["vs_fastest_dense"] = paired(timings[mode], timings[fastest], domain)
    return output


def summarize(items):
    manifest = json.loads((HERE / "packets.json").read_text())
    occ = json.loads((HERE / "occupancy-packets.json").read_text())
    groups = defaultdict(list)
    hardware = {}
    grid = {}
    density = {}
    lookup = {}
    head_grid = {}
    for filename, d in items:
        parts = Path(filename).parts
        if parts[0] != "final":
            continue
        family = parts[1]
        if "provenance" not in d or not d["provenance"].get("revision"):
            raise ValueError("Final record lacks measured code revision: " + filename)
        if family in ("stereo", "feature", "global", "occupancy"):
            task = d.get("task", "occupancy")
            domain = d.get("domain", d.get("record", {}).get("sensor"))
            if d["split"] != "evaluation":
                raise ValueError(filename)
            groups[task, domain].append(d)
        elif family in ("hardware", "stereo-memory"):
            hardware[Path(filename).stem] = d
        elif family == "head-grid":
            head_grid[d["task"] + "/" + d["domain"]] = d["rows"]
        elif family == "crossover":
            grid[d["domain"]] = d["rows"]
        elif family.startswith("density-"):
            density[family] = d["rows"][0]["arms"]
        elif family == "lookup":
            lookup[d["domain"]] = dict(
                arms=d["rows"][0]["arms"],
                setup_ms=d["lookup_setup_ms"],
                bytes=int(np.prod(d["size"])) * 20 * 8 * 4,
            )
        else:
            raise ValueError("Unknown measurement panel: " + filename)
    expected = {
        "features": ("mvsec", "dsec", "m3ed"),
        "stereo": ("mvsec", "dsec"),
        "depth": ("mvsec", "m3ed"),
        "semantics": ("human", "day"),
        "occupancy": ("L", "H"),
    }
    panels = {}
    for task, domains in expected.items():
        for domain in domains:
            rows = groups[task, domain]
            if task == "occupancy":
                want = {r["file"] for r in occ if r["split"] == "evaluation" and r["sensor"] == domain}
                have = [r["record"]["file"] for r in rows]
                if any(r["record"] not in occ for r in rows):
                    raise ValueError("Unknown occupancy source")
            else:
                want = {f for f in manifest[domain] if f.rsplit("-", 1)[0] != DEV[domain]}
                have = [r["packet"] for r in rows]
                if any(r["sha256"] != manifest[domain][r["packet"]]["sha256"] for r in rows):
                    raise ValueError("Packet identity changed")
            if len(have) != len(want) or set(have) != want:
                raise ValueError(f"Incomplete {task}/{domain}: {set(want) - set(have)}")
            panels[task + "/" + domain] = aggregate(rows, task, domain)
    hw_names = {
        f"{dev}-{task}-{mode}"
        for dev in ("cpu", "mps")
        for task in ("features", "semantics", "depth")
        for mode in ("dense", "regional" if task == "features" else "batched")
    }
    hw_names.update(f"mps-{t}-{m}" for t in ("flow", "occupancy") for m in ("dense", "regional"))
    hw_names.update("joint-" + m for m in ("dense", "batched", "separate-batched"))
    hw_names.update("stereo-" + m for m in ("dense", "half", "raw", "raw-sgbm", "regional-3-2"))
    if (
        set(hardware) != hw_names
        or set(lookup) != {"mvsec", "dsec", "m3ed"}
        or set(density) != {"density-0.1", "density-0.5", "density-1"}
    ):
        raise ValueError(f"Incomplete hardware panel: {hw_names - set(hardware)}")
    if set(grid) != set(lookup) or set(head_grid) != {"semantics/dsec", "depth/mvsec", "depth/m3ed"}:
        raise ValueError("Incomplete crossover panel")
    configs = set(product((8, 32, 96), (1, 4, 16, 64), ("clustered", "dispersed")))
    for rows in [*grid.values(), *head_grid.values()]:
        if len(rows) != len(configs) or {(r["extent"], r["count"], r["layout"]) for r in rows} != configs:
            raise ValueError("Incomplete crossover grid")
    return panels, hardware, grid, density, lookup, head_grid


def pack(directory, archive):
    content = {}
    for folder, label in (
        ("locked", "final"),
        ("development", "development/main"),
        ("head-development", "development/splits"),
        ("batched-development", "development/batching"),
        ("pilot", "development/pilot"),
    ):
        for file in sorted((directory / folder).rglob("*.json")):
            if any(p.startswith(".") for p in file.relative_to(directory).parts):
                continue
            name = label + "/" + str(file.relative_to(directory / folder))
            content[name] = file.read_bytes()
    summarize([(name, json.loads(buf)) for name, buf in content.items()])
    manifest = {name: hashlib.sha256(buf).hexdigest() for name, buf in content.items()}
    content["manifest.json"] = json.dumps(manifest, sort_keys=True).encode()
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, buf in sorted(content.items()):
            z.writestr(zipfile.ZipInfo(name), buf, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def verify_source(items):
    observed = set()
    for name, d in items:
        if not name.startswith("final/"):
            continue
        p = d["provenance"]
        digest = hashlib.sha256(json.dumps(p["source"], sort_keys=True).encode()).hexdigest()
        if digest != p["source_sha256"]:
            raise ValueError("Inconsistent source pin: " + name)
        revision = p["revision"]
        pair = revision, digest
        if pair in observed:
            continue
        source_archive = (
            zipfile.ZipFile(SOURCE_ARCHIVE) if revision in ARCHIVED_REVISIONS else nullcontext()
        )
        with source_archive as sources:
            for file, wanted in p["source"].items():
                if sources is None:
                    data = subprocess.check_output(["git", "show", f"{revision}:{file}"], cwd=HERE)
                else:
                    data = sources.read(f"{revision}/{file}")
                if hashlib.sha256(data).hexdigest() != wanted:
                    raise ValueError("Source did not match recorded revision: " + file)
        observed.add(pair)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--archive", type=Path, default=ARCHIVE)
    p.add_argument("--pack", type=Path, help="Archive a completed records directory")
    p.add_argument("--json", type=Path, help="Write the recomputed accuracy summary")
    p.add_argument(
        "--verify-source",
        "--verify-git",
        action="store_true",
        help="Verify measured source hashes against the archived sources or Git",
    )
    args = p.parse_args()
    if args.pack:
        pack(args.pack, args.archive)
    items = records(args.archive)
    if args.verify_source:
        verify_source(items)
    panels, hw, grid, _, _, head_grid = summarize(items)
    if args.json:
        args.json.write_text(json.dumps(panels, indent=2, allow_nan=False) + "\n")
    else:
        saved = json.loads((HERE / "summary.json").read_text())
        if saved != panels:
            raise ValueError("Summary differs from measurements")
    for key, row in panels.items():
        print(f"{key:19s} {row['recordings']:2d} recordings  {row['packets']:2d} packets")
    print(f"{len(hw)} hardware configurations; {len(grid) + len(head_grid)} crossover grids verified")


if __name__ == "__main__":
    main()
