# Reproduce the perception experiments

## Saved evidence

From the repository root, install NumPy, then run:

```sh
python -m followup.multitask.replay --verify-source
```

The archive contains raw synchronized timings, sample identities, query counts, predictions or confusion/error sufficient statistics, environment and source hashes. The per-record summaries include the development experiments. The replay uses only the final records for the published tables. The [measured source files](measured-sources.zip) are indexed by their original revision and checked against the SHA-256 digests in the records. Install Matplotlib to run `python -m followup.multitask.report --check` or regenerate the figure with `python -m followup.multitask.report`.

## Data and model setup

Use Python 3.13 and the [pinned packages](requirements.txt). Fetch the upstream F3 revision and the encoder, flow, depth, segmentation and architecture files described in the [inference instructions](../../docs/inference.md). Generated packets stay local. The [packet roster](packets.json) contains selection times, ground-truth identities, source revisions, calibration and file digests. The [occupancy roster](occupancy-packets.json) pins the original AEDAT4 files and extracted windows.

```sh
python -m pip install -r followup/multitask/requirements.txt
python -m followup.multitask.restore --domain dsec --recording interlaken_00_g --data-root datasets
python -m followup.multitask.restore --domain mvsec --recording indoor_flying1 --data-root datasets
python -m followup.multitask.restore --domain m3ed --recording car_forest_into_ponds_long --data-root datasets
python -m followup.multitask.restore --domain esot --recording animal2 --data-root datasets
python -m followup.multitask.semantic_data
```

For a complete panel restore every recording listed in the roster. The following shell loop reads the names from the checked-in files. The semantic command restores all eight semantic takes.

```sh
python - <<'PY' | while read -r domain recording; do
import json
from pathlib import Path
d = Path("followup/multitask")
r = json.loads((d / "packets.json").read_text())
for domain in ("mvsec", "m3ed", "dsec"):
    for name in sorted({entry["recording"] for entry in r[domain].values()}):
        print(domain, name)
for entry in json.loads((d / "occupancy-packets.json").read_text()):
    print("esot", entry["name"])
PY
  python -m followup.multitask.restore --domain "$domain" --recording "$recording" --data-root datasets || exit 1
done
```

A fresh reconstruction recovered a DSEC disparity packet and calibration, an M3ED depth packet and an ESOT window file byte for byte. ESOT used the pinned local AEDAT4 source. The MVSEC publisher's Google Drive download quota prevented a fresh HDF5 range read during verification. All MVSEC experiments used previously acquired, hash-verified packets. The loader accepts verified packet caches and rejects different content. Semantic input acquisition decoded the publisher labels and regenerated all 24 semantic packets. [Restoration receipts](restoration.json) · [MVSEC downloads](https://daniilidis-group.github.io/mvsec/download/) · [DSEC](https://dsec.ifi.uzh.ch/) · [M3ED](https://m3ed.io/) · [ESOT500](https://huggingface.co/datasets/sii-pi-lab/ESOT500)

## Fresh measurements

The [source archive](measured-sources.zip) contains the exact files used for the feature, stereo, occupancy and field-geometry measurements (`f6ebd51`) and for the global heads, combined service and head-geometry measurements (`6d0eacd`). Those names identify the original measurements. Use an empty output directory for new measurements. All published timings used one M5 Max.

To rerun the original code, unpack both snapshots into a temporary directory. The scheduler records a Git revision for every new run. Register each extracted snapshot locally so the verifier can resolve that revision when it checks new records.

```sh
snapshots=$(mktemp -d)
unzip -q followup/multitask/measured-sources.zip -d "$snapshots"
for source_dir in "$snapshots"/*; do
  git -C "$source_dir" init -q
  git -C "$source_dir" add followup query_f3
  git -C "$source_dir" -c user.name=Reproduction -c user.email=local@example.invalid commit -qm "Measured source snapshot"
  git fetch --quiet --no-tags "$source_dir" HEAD
done
field_source="$snapshots/f6ebd5159dfdd02dd7babfd086f0b16dafe577d1"
head_source="$snapshots/6d0eacd460c943ff958daae4924c89b3b8c828cf"
```

To benchmark a modification, commit it in the extracted source directory and fetch its new HEAD into the replay checkout using the same fetch command.

Set `F3_UPSTREAM`, `F3_ENCODER`, `F3_HEADS`, `F3_FLOW` and `F3_DATA` to absolute local paths. The head directory contains `depth.pth`, `semantics.pth` and `segformer.json`. The flow directory contains `last.pth` and `flow_config.yaml`. For example, measure the transformer heads using the released configurations:

```sh
python -m followup.multitask.run global --measurement-root "$head_source" \
  --data "$F3_DATA" --upstream "$F3_UPSTREAM" --weights "$F3_ENCODER" \
  --models "$F3_HEADS" --flow-dir "$F3_FLOW" --output "$PWD/followup/multitask/records/new/locked"
```

Use the same head source for `hardware` and `head-grid`. Use `--measurement-root "$field_source"` for `features`, `stereo`, `occupancy` and `field-grid`. Each panel writes JSON; supply a new archive path to pack and replay a fresh suite. The published development observations remain in the distributed archive. A fresh archive can also contain new development observations in the same named subdirectories.

```sh
python -m followup.multitask.replay --pack followup/multitask/records/new --archive /tmp/f3-measurements.zip --json /tmp/f3-summary.json --verify-source
```

The time on a request includes region selection, event accumulation, network computation, synchronized host retrieval and, for stereo, matching. Data decoding, calibration, persistent model loading and resolution-table construction precede the timed request. Each accuracy panel fixes its recording split before evaluation and interleaves the method order within packet. The provenance JSON records the effective code and configuration. Run the regression tests with:

```sh
python -m unittest discover -s followup/multitask -p 'test_*.py'
```
