"""Compare native regional descriptors and their use in sparse stereo search."""

import copy
import hashlib
import json
import time

import cv2
import numpy as np
import torch

from followup.multitask.bench import environment, parser, setup, sync
from followup.multitask.data import load, paths
from followup.multitask.provenance import pin
from query_f3.binding import digest
from query_f3.multitask.service import FeatureService, active_regions, packet, gather_xy


def descriptors(service, enc, enc16, e, size, rects, mode):
    split, stride = 3, 2
    if mode.startswith(("regional-", "plain-", "oracle-", "merged-")):
        mode, k, s = mode.split("-")
        split, stride = int(k), int(s)
    return service.query(
        enc,
        packet(e, size, getattr(service, "table", None)),
        rects,
        "dense" if mode == "half" else mode,
        split=split,
        stride=stride,
        low=enc16 if mode == "half" else None,
    )


def disparity_mae(pred, gt):
    valid = np.isfinite(gt) & (gt > 0)
    # The dense SGBM comparator can abstain. Report coverage and score a
    # specified zero-disparity fallback on the complete common target set.
    returned = valid & (pred >= 0)
    error = np.abs(np.where(pred[valid] >= 0, pred[valid], 0) - gt[valid])
    return dict(
        n=int(valid.sum()),
        outside=int(np.count_nonzero(valid & (gt > 48))),
        valid_returns=int(returned.sum()),
        returned_sum_error=float(np.abs(pred[returned] - gt[returned]).sum()),
        sum_error=float(error.sum()),
        within1=int((error <= 1).sum()),
    )


def raw_sgbm(e, size):
    w, h = size

    def image(events):
        ids = events[:, 2].astype("i8") * w + events[:, 1]
        vals = np.bincount(ids, minlength=w * h).reshape(h, w)
        return np.uint8(np.minimum(255, 64 * np.log1p(vals)))

    alg = cv2.StereoSGBM_create(
        minDisparity=0,
        numDisparities=64,
        blockSize=5,
        P1=8 * 25,
        P2=32 * 25,
        uniquenessRatio=5,
        mode=cv2.STEREO_SGBM_MODE_SGBM_3WAY,
    )
    return alg.compute(image(e["left"]), image(e["right"])).astype("f") / 16


def layouts(events, size, extent, count, layout):
    if layout == "active":
        return active_regions(events, size, count, extent)
    w, h = size
    if layout == "dispersed":
        rng = np.random.default_rng(412)
        return [
            (int(rng.integers(w - extent + 1)), int(rng.integers(h - extent + 1)), extent, extent)
            for _ in range(count)
        ]
    cx, cy = w // 2 - extent // 2, h // 2 - extent // 2
    return [(cx + i % 4, cy + i // 4, extent, extent) for i in range(count)]


@torch.inference_mode()
def run(opt):
    torch.set_num_threads(4)
    cv2.setNumThreads(1)
    opt.out.mkdir(parents=True, exist_ok=True)
    enc, _ = setup(opt)
    enc16 = copy.deepcopy(enc).half()
    service = FeatureService()
    for file in paths(opt.domain, opt.split, opt.data):
        if opt.recording and file.stem.rsplit("-", 1)[0] != opt.recording:
            continue
        if opt.one and not file.stem.endswith(("-5", "-50")):
            continue
        size, e, _, gt, counts = load(opt.domain, file)
        rng = np.random.default_rng(
            int.from_bytes(hashlib.sha256(file.stem.encode()).digest()[:4], "little")
        )
        setup_ms = 0.0
        if opt.lookup and (not hasattr(service, "table") or tuple(service.table.shape[:2]) != size):
            from query_f3.multitask.lookup import build_lookup

            sync(opt.device)
            start = time.perf_counter()
            service.table = build_lookup(enc, size)
            sync(opt.device)
            setup_ms = 1000 * (time.perf_counter() - start)
        if opt.keep < 1:
            e = {k: v[np.linspace(0, len(v) - 1, int(len(v) * opt.keep), dtype="i8")] for k, v in e.items()}
        rows = []
        configs = [(opt.count, opt.extent, "active")]
        if opt.sweep:
            configs = [
                (c, w, l) for w in (8, 32, 96) for c in (1, 4, 16, 64) for l in ("dispersed", "clustered")
            ]
        for count, extent, layout in configs:
            if opt.task == "features":

                def call(mode):
                    rs = layouts(e["left"], size, extent, count, layout)
                    return (
                        descriptors(service, enc, enc16, e["left"], size, rs, mode)
                        .float()
                        .contiguous()
                        .cpu()
                        .numpy()
                    )

                modes = (
                    ["dense", "half", "released", "ordinary", "crop", *opt.policies]
                    if not opt.sweep
                    else ["dense", "half", *opt.policies]
                )
                # Oracle includes dense normalization work; report accuracy only.
                if not opt.sweep:
                    modes.append("oracle-3-2")
                boxes = layouts(e["left"], size, extent, count, layout)
                ref = call("released")
                scale = np.sqrt(np.mean(ref.astype("d") ** 2))
                truth = None
            else:
                from followup.multitask.stereo import select_points, boxes as support, match, raw_field

                def call(mode):
                    pts = select_points(e["left"], size, count=count)
                    if not len(pts):
                        return np.empty(0, dtype="f")
                    a, b = support(pts)
                    if mode == "raw-sgbm":
                        result = raw_sgbm(e, size)
                        return np.asarray([result[y, x] for x, y in pts])
                    if mode == "zero":
                        return np.zeros(len(pts), "f")
                    if mode == "raw":
                        left = gather_xy(raw_field(e["left"], size), a)
                        right = gather_xy(raw_field(e["right"], size), b)
                    else:
                        left = descriptors(service, enc, enc16, e["left"], size, a, mode)
                        right = descriptors(service, enc, enc16, e["right"], size, b, mode)
                    return match(left, right).float().cpu().numpy()

                boxes = np.asarray(select_points(e["left"], size, count=count)).reshape(-1, 2)
                truth = gt[boxes[:, 1], boxes[:, 0]] if len(boxes) else np.empty(0)
                modes = ["dense", "half", "crop", "ordinary", "raw", "raw-sgbm", "zero", *opt.policies]
                ref = call("dense")
            arms = {}
            for mode in rng.permutation(modes):
                val = call(mode)
                finite = bool(np.isfinite(val).all())
                arms[mode] = {"finite": finite, "ms": []}
                if finite:
                    if opt.task == "features":
                        delta = val.astype("d") - ref
                        arms[mode].update(
                            relative_rms=float(np.sqrt(np.mean(delta**2)) / max(scale, 1e-12)),
                            max_abs=float(np.abs(delta).max()),
                        )
                    else:
                        arms[mode].update(
                            disparity_mae(val, truth),
                            same=int((val == ref).sum()),
                            estimates=val.tolist(),
                            invalid=int((val < 0).sum()),
                        )
            timed = [m for m in modes if not m.startswith("oracle")]
            for _ in range(opt.repeats):
                for mode in rng.permutation(timed):
                    sync(opt.device)
                    start = time.perf_counter()
                    call(mode)
                    sync(opt.device)
                    arms[mode]["ms"].append(1000 * (time.perf_counter() - start))
            row = dict(
                count=count, extent=extent, layout=layout, coordinates=np.asarray(boxes).tolist(), arms=arms
            )
            if truth is not None:
                row["gt"] = [float(v) if np.isfinite(v) and v > 0 else None for v in truth]
            rows.append(row)
        payload = dict(
            task=opt.task,
            domain=opt.domain,
            split=opt.split,
            packet=file.name,
            sha256=digest(file),
            size=size,
            keep=opt.keep,
            lookup=opt.lookup,
            lookup_setup_ms=setup_ms,
            events=counts,
            used={k: len(v) for k, v in e.items()},
            environment=environment(opt.device),
            code=digest(__file__),
            rows=rows,
        )
        dest = opt.out / f"{opt.task}-{opt.domain}-{file.stem}.json"
        payload["provenance"] = pin(opt.upstream)
        with dest.open("x") as f:
            json.dump(payload, f, allow_nan=False, separators=(",", ":"))
            f.write("\n")
        print(dest.name, flush=True)


if __name__ == "__main__":
    p = parser()
    p.add_argument(
        "--policies", nargs="+", default=["regional-1-2", "regional-3-2", "regional-5-2", "plain-3-2"]
    )
    p.add_argument("--recording")
    p.add_argument("--keep", type=float, choices=[0.1, 0.5, 1.0], default=1.0)
    p.add_argument("--sweep", action="store_true")
    run(p.parse_args())
