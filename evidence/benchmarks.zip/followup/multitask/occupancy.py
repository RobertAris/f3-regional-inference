"""Score twenty released future-occupancy logits at native event-selected sites."""

import argparse
import copy
import json
import time
from pathlib import Path

import numpy as np
import torch

from followup.multitask.bench import HERE, environment, parser, setup, sync
from followup.multitask.feature_bench import descriptors
from followup.multitask.provenance import pin
from query_f3.binding import ROOT, digest
from query_f3.multitask.service import FeatureService, active_regions, packet


def labels(events, size, rects):
    output = []
    for x, y, w, h in rects:
        t, xx, yy = events[:, :3].T
        mask = (xx >= x) & (xx < x + w) & (yy >= y) & (yy < y + h) & (t >= 0) & (t < 20000)
        array = np.zeros((20, w, h), dtype="f")
        array[t[mask] // 1000, xx[mask] - x, yy[mask] - y] = 1
        output.append(array)
    return np.stack(output)


def scores(logits, target, mask):
    z = logits.transpose(0, 2, 3, 1)[mask].astype("d")
    y = target.transpose(0, 2, 3, 1)[mask]
    p = 1 / (1 + np.exp(-np.clip(z, -80, 80)))
    return dict(
        n=int(y.size),
        occupied=int(y.sum()),
        bits=float(np.mean(np.logaddexp(0, z) - y * z) / np.log(2)),
        brier=float(np.mean((p - y) ** 2)),
    )


@torch.inference_mode()
def run(opt):
    enc, _ = setup(opt)
    enc16 = copy.deepcopy(enc).half()
    torch.set_num_threads(4)
    service = FeatureService()
    opt.out.mkdir(exist_ok=True, parents=True)
    roster = json.loads((HERE / "occupancy-packets.json").read_text())
    for row in roster:
        if row["split"] != opt.split:
            continue
        size = (346, 260) if row["sensor"] == "L" else (1280, 720)
        path = opt.data / "temporal/windows" / row["file"]
        if digest(path) != row["packet_sha256"]:
            raise ValueError(path)
        with np.load(path, allow_pickle=False) as z:
            ev = z["w12"]
        past = ev[ev[:, 0] < 0]
        if len(past) > 800000:
            past = past[np.linspace(0, len(past) - 1, 800000, dtype="i8")]
        boxes = active_regions(past, size, opt.count, opt.extent)
        truth = labels(ev, size, boxes)
        seen = np.zeros(size, bool)
        masks = []
        for x, y, w, h in boxes:
            masks.append(~seen[x : x + w, y : y + h].copy())
            seen[x : x + w, y : y + h] = True
        mask = np.stack(masks)
        modes = [
            "released",
            "dense",
            "half",
            "crop",
            "ordinary",
            "regional-1-2",
            "regional-3-2",
            "regional-5-2",
            "history",
        ]

        def predict(mode):
            rs = active_regions(past, size, opt.count, opt.extent)
            if mode == "history":
                mirrored = past.copy()
                mirrored[:, 0] = -1 - mirrored[:, 0]
                count = labels(mirrored, size, rs).sum(1, keepdims=True)
                p = (count + 0.5) / 21
                return np.repeat(np.log(p / (1 - p)), 20, 1)
            f = descriptors(service, enc, enc16, past, size, rs, mode)
            # 1x1 projection commutes with extraction.
            return (enc16 if mode == "half" else enc).pred(f).float().cpu().numpy()

        ref = predict("released")
        rng = np.random.default_rng(183)
        arms = {}
        for m in modes:
            value = predict(m)
            finite = bool(np.isfinite(value).all())
            arms[m] = dict(finite=finite, ms=[])
            if finite:
                arms[m].update(
                    scores(value, truth, mask), logit_rmse=float(np.sqrt(np.mean((value - ref) ** 2)))
                )
        for _ in range(opt.repeats):
            for m in rng.permutation(modes):
                sync(opt.device)
                start = time.perf_counter()
                predict(m)
                sync(opt.device)
                arms[m]["ms"].append(1000 * (time.perf_counter() - start))
        # Independent upstream whole-logit forward also checks the 1x1 gather identity.
        enc.w, enc.h = size
        enc.return_logits = True
        q = torch.from_numpy(packet(past, size).ev).to(opt.device)
        full, _ = enc(q, torch.tensor([len(q)], device=q.device))
        oracle = np.stack(
            [
                full[0, x : x + w, y : y + h, :].permute(2, 0, 1).float().cpu().numpy()
                for x, y, w, h in boxes
            ]
        )
        enc.return_logits = False
        whole_max = float(np.max(np.abs(oracle - ref)))
        result = dict(
            released_whole_logit_max_abs=whole_max,
            record=row,
            split=opt.split,
            size=size,
            count=len(past),
            boxes=boxes,
            arms=arms,
            environment=environment(opt.device),
            code=digest(__file__),
        )
        result["provenance"] = pin(opt.upstream)
        with (opt.out / ("occupancy-" + path.stem + ".json")).open("x") as f:
            json.dump(result, f, separators=(",", ":"), allow_nan=False)
            f.write("\n")
        print(path.name, flush=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data", type=Path, default=ROOT / "datasets")
    p.add_argument("--upstream", type=Path, default=ROOT.parent / "fast-feature-fields")
    p.add_argument(
        "--weights", type=Path, default=ROOT / "checkpoints/f3/patchff_fullcardaym3ed_small_20ms.pth"
    )
    p.add_argument("--device", choices=("mps", "cpu"), default="mps")
    p.add_argument("--split", choices=("development", "evaluation"), required=True)
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--count", type=int, default=4)
    p.add_argument("--extent", type=int, default=48)
    p.add_argument("--repeats", type=int, default=3)
    p.set_defaults(task="occupancy")
    run(p.parse_args())
