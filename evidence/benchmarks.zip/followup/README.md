# Benchmarks

| Experiment | What it measures |
|---|---|
| [Feature and optical-flow requests](precision_policy/) | Fresh-packet latency against six dense implementations, with and without the fidelity screen |
| [Individual regions](region_fidelity/) | Error on all 430 flow regions and a dense-normalization check on the three packets with corner failures |
| [Perception benchmarks](multitask/tables.md) | Feature fidelity, downstream task accuracy, shared requests, memory and the effect of region geometry |

The original flow timing calculation reads the [earlier precision measurements](precision/) and [source records](records/) to verify packet identities. To check the results from a clone or repeat a model benchmark, see the [reproduction instructions](../docs/reproduction.md).
