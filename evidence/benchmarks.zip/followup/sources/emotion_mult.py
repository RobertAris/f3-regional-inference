"""Resume the final E-MOTION source with a per-object disk range cache."""
import hashlib,json,time
from pathlib import Path
import requests
from . import emotion

class CachedRanges(emotion.Ranges):
    def fetch(self,a,b):
        directory=emotion.BASE/'mult-ranges'/self.sha
        directory.mkdir(exist_ok=True,parents=True)
        path=directory/f'{a}-{b}.bin';tag=directory/'etag'
        if path.exists():
            payload=path.read_bytes()
            if len(payload)!=b-a or not tag.exists():raise IOError('incomplete persistent range')
            self.etag=tag.read_text();return payload
        # Initial six completed captures plus the conservative upper bound of 300 MiB
        # on the stopped capture leave room within the registered 2 GiB transfer budget.
        if sum(x.stat().st_size for x in directory.glob('*.bin'))+b-a>400*1024**2:raise ValueError('cached per-object transfer ceiling')
        for attempt in range(5):
            try:
                with self.session.get(self.url,headers={'Range':f'bytes={a}-{b-1}','Accept-Encoding':'identity'},timeout=(15,75),stream=True) as r:
                    r.raise_for_status()
                    if r.status_code!=206 or r.headers.get('Content-Range')!=f'bytes {a}-{b-1}/{self.size}':raise IOError('incorrect HTTP range')
                    etag=r.headers['ETag']
                    if tag.exists() and tag.read_text()!=etag:raise ValueError('remote object changed')
                    payload=r.content
                    if len(payload)!=b-a:raise IOError('short range')
                    tag.write_text(etag);self.etag=etag;self.bytes+=len(payload);self.calls+=1
                    pending=path.with_suffix('.pending');pending.write_bytes(payload);pending.replace(path);return payload
            except (requests.RequestException,OSError):
                if attempt==4:raise
                time.sleep(1+attempt)
def run():
    emotion.Ranges=CachedRanges;emotion.run('mult_1')
    p=emotion.BASE/'mult_1.json';obj=json.loads(p.read_text());obj['recovery_reader']=emotion.digest(Path(__file__))
    obj['recovery']='The original per-object 150 MiB cap was reached. A disk-backed range reader verifies and retains immutable chunks within the existing campaign limit.'
    obj['total_successful_source_bytes']=sum(x.stat().st_size for x in (emotion.BASE/'mult-ranges').glob('*/*.bin'))
    p.write_text(json.dumps(obj,indent=2)+'\n')
if __name__=='__main__':run()
