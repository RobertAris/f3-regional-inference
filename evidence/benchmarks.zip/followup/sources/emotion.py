"""Bounded HTTP ranges against the authors' immutable public E-MOTION release."""
import io,json,re,time,hashlib
from pathlib import Path
from collections import OrderedDict
import numpy as np
import h5py,hdf5plugin,requests
from query_f3.binding import ROOT,digest
REV='8c364021cc14f48e778a55ce36188eea9c899ca1'
BASE=ROOT/'datasets/f3-next-emotion'
NAMES=('looping_moving','rot_normal_1','transl_fast_1','square_traj_2','cracker_box','drone_normal_2','mult_1')
class Ranges(io.RawIOBase):
    def __init__(self,url):
        self.url=url;self.session=requests.Session();h=self.session.head(url,allow_redirects=False,timeout=30);h.raise_for_status()
        self.size=int(h.headers['x-linked-size']);self.sha=h.headers['x-linked-etag'].strip('"')
        if not re.fullmatch('[a-f0-9]{64}',self.sha):raise ValueError('unbound LFS source')
        self.pos=0;self.cache=OrderedDict();self.bytes=0;self.calls=0;self.etag=None
    def readable(self):return True
    def seekable(self):return True
    def seek(self,off,whence=0):
        self.pos=(0,self.pos,self.size)[whence]+off
        if self.pos<0:raise ValueError('negative seek')
        return self.pos
    def tell(self):return self.pos
    def fetch(self,a,b):
        if not 0<=a<b<=self.size or b-a>100*1024**2:raise ValueError(('unbounded read',a,b))
        if self.bytes+b-a>150*1024**2:raise ValueError('per object capture transfer ceiling')
        for attempt in range(5):
            try:
                r=self.session.get(self.url,headers={'Range':f'bytes={a}-{b-1}','Accept-Encoding':'identity'},timeout=(15,75),stream=True)
                with r:
                    r.raise_for_status()
                    if r.status_code!=206 or r.headers.get('content-range')!=f'bytes {a}-{b-1}/{self.size}':raise ValueError(('range mismatch',a,b,r.status_code,r.headers.get('content-range')))
                    hdr=next((p.headers for p in r.history if 'x-linked-etag' in p.headers),None)
                    if not hdr or hdr['x-linked-etag'].strip('"')!=self.sha or int(hdr['x-linked-size'])!=self.size:raise ValueError('HF revision or LFS object changed')
                    etag=r.headers['ETag']
                    if self.etag is not None and etag!=self.etag:raise ValueError('CDN identity changed')
                    self.etag=etag;payload=r.content
                    if len(payload)!=b-a:raise IOError('short range')
                    self.bytes+=len(payload);self.calls+=1;return payload
            except (requests.RequestException,OSError):
                if attempt==4:raise
                time.sleep(1+attempt)
    def readinto(self,buf):
        n=min(len(buf),self.size-self.pos)
        if n<=0:return 0
        a=self.pos;b=a+n
        if n>=128*1024:
            data=self.fetch(a,b)
        else:
            base=(a//65536)*65536;end=min(self.size,max(base+65536,b));key=(base,end)
            if key not in self.cache:
                self.cache[key]=self.fetch(base,end)
                if len(self.cache)>80:self.cache.popitem(last=False)
            data=self.cache[key][a-base:b-base]
        buf[:n]=data;self.pos=b;return n
    def identity(self):return dict(url=self.url,size=self.size,sha256=self.sha,cdn_etag=self.etag,bytes=self.bytes,requests=self.calls)
def window(ev,rel0,rel1,ms):
    a=max(0,int(rel0)//1000-1);b=min(len(ms)-1,int(rel1)//1000+2)
    l=max(0,int(ms[a])-1);r=min(len(ev['t']),int(ms[b])+1)
    t=ev['t'][l:r].astype('int64')
    if not len(t) or np.any(np.diff(t)<0) or t[0]>=rel0 or t[-1]<rel1:raise ValueError(('incorrect ms index',l,r,rel0,rel1,t[:1],t[-1:]))
    i,j=np.searchsorted(t,[rel0,rel1])
    x=ev['x'][l+i:l+j];y=ev['y'][l+i:l+j]
    return np.column_stack((t[i:j]-rel1,x,y)).astype('i4')
def run(n):
    BASE.mkdir(exist_ok=True,parents=True);dest=BASE/(n+'.npz');rec=BASE/(n+'.json')
    if rec.exists():
        assert json.loads(rec.read_text())['packet']==digest(dest);return
    url=f'https://huggingface.co/datasets/ivangr3/e-motion/resolve/{REV}/{n}'
    a,b=Ranges(url+'/events.h5'),Ranges(url+'/gt.h5');arrays={};rows=[]
    with h5py.File(a,'r') as events,h5py.File(b,'r') as gt:
        ev=events['left/events'];offset=int(ev.attrs['t_offset']);ms=ev['ms_to_idx'][:]
        stamps=np.rint(gt['time_stamps'][:].flatten()*1e6).astype('i8')
        if not (np.diff(stamps)>0).all():raise ValueError('non-increasing label time')
        ids=np.flatnonzero((stamps>=stamps[0]+100000)&(stamps<=stamps[-1]-100000))
        for j,q in enumerate((1,3,5,7,9)):
            f=ids[(len(ids)-1)*q//10];t=int(stamps[f]);e=window(ev,t-offset-10000,t-offset+10000,ms)
            uv=gt['left/optical_flow'][f];dep=gt['left/depth'][f]
            if uv.shape!=(720,1280,2) or dep.shape!=(720,1280):raise ValueError(('geometry',uv.shape,dep.shape))
            if (e[:,1:]<0).any() or (e[:,1:]>=np.array([1280,720])).any():raise ValueError('event coordinates')
            arrays.update({f'w{j}':e,f'velocity{j}':uv,f'valid{j}':dep>0,f't{j}':np.int64(t)})
            rows.append(dict(frame=int(f),gt_us=t,events=len(e),valid=int((dep>0).sum()),zero_valid=int(((dep>0)&(uv==0).all(2)).sum())))
    tmp=dest.with_suffix('.pending.npz');np.savez_compressed(tmp,**arrays);tmp.replace(dest)
    rec.write_text(json.dumps(dict(name=n,revision=REV,source=[a.identity(),b.identity()],rows=rows,packet=digest(dest),code=digest(Path(__file__)),units='instantaneous pixels/second',role='publisher train'),indent=2)+'\n')
    print(n,rows[0],a.bytes+b.bytes,flush=True)
if __name__=='__main__':
    for name in NAMES:run(name)
