"""Acquire and select publisher-training EVIMO SfM members with byte-bound ranges."""
import hashlib,json,os,shutil,tarfile,time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import requests
from query_f3.binding import ROOT,digest
URL='https://obj.umiacs.umd.edu/evimo2v2npz/npz_samsung_mono_sfm.tar.gz'
ETAG='c50bcf002182d7b7dc982b843a4b18a1-45'
LENGTH=10417922576
BASE=ROOT/'datasets/f3-next-samsung'
TAKES={**{f'scene_0{g}_0{j}':str(g) for g in (4,5) for j in range(5)},
       **{f'scene7_0{j}':'7' for j in (0,2,3)}, **{f'scene8_0{j}':'8' for j in (1,3,4)}}
KEEP={'dataset_info.npz','dataset_depth.npz','dataset_mask.npz','dataset_events_t.npy','dataset_events_xy.npy'}
def get():
    BASE.mkdir(exist_ok=True,parents=True);archive=BASE/'samsung_sfm.tar.gz'
    if archive.exists():
        if archive.stat().st_size!=LENGTH:raise ValueError('unexpected completed archive size')
        return archive
    parts=BASE/'parts';parts.mkdir(exist_ok=True)
    step=32*1024**2
    def fetch(start):
        stop=min(start+step,LENGTH);p=parts/f'{start:012}.bin'
        if p.exists() and p.stat().st_size==stop-start:return p
        for attempt in range(5):
            try:
                with requests.get(URL,headers={'Range':f'bytes={start}-{stop-1}','If-Match':f'"{ETAG}"','Accept-Encoding':'identity'},stream=True,timeout=(15,90)) as r:
                    r.raise_for_status()
                    if r.status_code!=206 or r.headers['Content-Range']!=f'bytes {start}-{stop-1}/{LENGTH}' or r.headers['ETag'].strip('"')!=ETAG:raise ValueError('object or range changed')
                    tmp=p.with_suffix('.part')
                    with tmp.open('wb') as f:
                        for block in r.iter_content(2**20):f.write(block)
                    if tmp.stat().st_size!=stop-start:raise IOError('short range')
                    tmp.replace(p);return p
            except (OSError,requests.RequestException):
                if attempt==4:raise
                time.sleep(1+attempt)
    with ThreadPoolExecutor(max_workers=4) as pool:
        for i,p in enumerate(pool.map(fetch,range(0,LENGTH,step))):
            if i%32==0:print(i+1,'ranges verified',flush=True)
    tmp=archive.with_suffix('.assembling')
    with tmp.open('wb') as out:
        for p in sorted(parts.glob('*.bin')):
            with p.open('rb') as f:shutil.copyfileobj(f,out,4*2**20)
    if tmp.stat().st_size!=LENGTH:raise ValueError('incomplete assembly')
    tmp.replace(archive)
    for p in parts.glob('*.bin'):p.unlink()
    return archive
def extract():
    archive=get();manifest=[]
    with tarfile.open(archive,'r|gz') as tar:
        for m in tar:
            p=Path(m.name)
            if len(p.parts)!=5 or p.parts[:3]!=('samsung_mono','sfm','train') or not m.isfile() or p.name not in KEEP:continue
            take,fragment=p.parent.name.rsplit('_',1)
            if take not in TAKES:continue
            dst=BASE/'train'/p.parent.name/p.name;dst.parent.mkdir(exist_ok=True,parents=True)
            if not dst.exists() or dst.stat().st_size!=m.size:
                tmp=dst.with_suffix('.part')
                with tmp.open('wb') as out:shutil.copyfileobj(tar.extractfile(m),out,2**20)
                tmp.replace(dst)
            manifest.append(dict(member=m.name,sha=digest(dst),bytes=m.size))
    roster={}
    for take,group in TAKES.items():
        candidates=sorted(p.name for p in (BASE/'train').glob(take+'_*') if p.is_dir())
        if not candidates:raise ValueError('publisher roster missing '+take)
        n=candidates[0]
        if {p.name for p in (BASE/'train'/n).iterdir()}!=KEEP:raise ValueError('missing source arrays for '+n)
        roster[n]=group
    record=dict(source=URL,bytes=LENGTH,etag=ETAG,sha256=digest(archive),roster=roster,members=manifest)
    (BASE/'sources.json').write_text(json.dumps(record,indent=2)+'\n');print('checked',len(roster),'takes',len(set(roster.values())),'scenes',flush=True)
if __name__=='__main__':extract()
