"""Generate genuine 100 ms Samsung displacements with the pinned EVIMO geometry."""
import importlib.util,json,tempfile
from pathlib import Path
import numpy as np
from numpy.lib import npyio,_npyio_impl
from query_f3.binding import digest
from query_f3.external import sources
from .samsung import BASE
def run():
    pin=json.loads((BASE/'sources.json').read_text())
    if not hasattr(npyio,'zipfile_factory'):npyio.zipfile_factory=_npyio_impl.zipfile_factory
    sources.source();script=sources.BASE/'vendor/evimo_flow.py';assert digest(script)==sources.FLOW_SHA
    sp=importlib.util.spec_from_file_location('evimo_flow_samsung',script);official=importlib.util.module_from_spec(sp);sp.loader.exec_module(official)
    out=BASE/'packets';out.mkdir(exist_ok=True)
    for n,group in pin['roster'].items():
        folder=BASE/'train'/n;file=out/(n+'.npz');receipt=out/(n+'.json')
        if receipt.exists():
            assert json.loads(receipt.read_text())['sha']==digest(file);continue
        info=folder/'dataset_info.npz';meta=np.load(info,allow_pickle=True)['meta'].item()
        t=np.load(folder/'dataset_events_t.npy',mmap_mode='r');xy=np.load(folder/'dataset_events_xy.npy',mmap_mode='r')
        assert len(t)==len(xy) and np.all(t[1:]>=t[:-1]);first=meta['frames'][0]['id']
        lo=float(t[0])+.010;hi=min(float(t[-1])-.010,max(v['ts'] for v in meta['full_trajectory'] if 'cam' in v)-.100)
        arrays={};rows=[]
        with np.load(folder/'dataset_depth.npz') as depth,np.load(folder/'dataset_mask.npz') as masks,tempfile.TemporaryDirectory() as tmp:
            td=Path(tmp);(td/info.name).symlink_to(info);stamps={}
            dd=set(depth.files);mm=set(masks.files)
            for f in meta['frames']:
                k=str(f['id']-first).zfill(10)
                if 'cam' in f and lo<=f['cam']['ts']<=hi and 'depth_'+k in dd and 'mask_'+k in mm:stamps[k]=float(f['cam']['ts'])
            ks=[list(stamps)[(len(stamps)-1)*i//10] for i in (1,3,5,7,9)]
            assert len(set(ks))==5
            depths={'depth_'+k:depth['depth_'+k] for k in ks}
            np.savez(td/'dataset_depth.npz',**depths);np.savez(td/'dataset_mask.npz',**{'mask_'+k:masks['mask_'+k] for k in ks})
            official.convert(str(td),.100,quiet=True,showflow=False,format='evimo2v2')
            with np.load(td/'dataset_flow.npz') as gt:
                for j,(k,left,right) in enumerate(zip(ks,gt['t'],gt['t_end'],strict=True)):
                    assert abs(left-stamps[k])<1e-6 and abs(right-left-.100)<1e-8
                    a,b=np.searchsorted(t,[left-.01,left+.01]);cut=int(round((left+.01)*1e6))
                    offset=np.rint(t[a:b].astype('d')*1e6).astype('i8')-cut
                    good=(offset>=-20000)&(offset<0);e=np.column_stack((offset[good],xy[a:b][good])).astype('i4')
                    uv=gt['flow_'+k];valid=np.isfinite(uv).all(2)&(depths['depth_'+k]>0)
                    h,w=valid.shape;assert e.shape[1]==3 and np.all((e[:,1:]>=0)&(e[:,1:]<[w,h]))
                    y,x=np.where(valid)
                    arrays.update({f'w{j}':e,f'xy{j}':np.column_stack((x,y)).astype('i2'),f'gt{j}':uv[y,x].astype('f'),f'dt{j}':np.int64(100000)})
                    rows.append(dict(key=k,events=len(e),valid=len(x),left=float(left),right=float(right),size=[w,h]))
        temp=file.with_suffix('.pending.npz');np.savez_compressed(temp,**arrays);temp.replace(file)
        receipt.write_text(json.dumps(dict(name=n,group=group,sha=digest(file),rows=rows,source=digest(BASE/'sources.json'),code=digest(Path(__file__)),generator=sources.FLOW_SHA),indent=2)+'\n');print(n,[r['size'] for r in rows[:1]],flush=True)
if __name__=='__main__':run()
