"""Standalone NumPy-only verification of primary effects from archived measurements."""
import argparse,hashlib,json,zipfile
from pathlib import Path
import numpy as np

def check(path):
    with zipfile.ZipFile(path) as z:
        read=lambda name:json.loads(z.read(name))
        checks=read('MANIFEST.json')
        assert set(z.namelist())==set(checks)|{'MANIFEST.json'} and len(set(z.namelist()))==len(z.namelist())
        for n,h in checks.items():assert hashlib.sha256(z.read(n)).hexdigest()==h,n
        independent=read('runs/f3-independent/summary.json');groups={};samples=[];rng=np.random.default_rng(731)
        for ds,cohort in independent['recordings'].items():
            rates=[]
            for n in cohort:
                a=read(f'runs/f3-independent/scores/{n}.json')['windows']
                rates.append([np.sqrt(np.mean([np.array(w['by_roi'][arm])[:,0] for w in a])) for arm in ('tile','phase')])
            a=np.array(rates);groups[ds]=1-a[:,0].mean()/a[:,1].mean()
            draw=a[rng.integers(len(a),size=(20000,len(a)))].mean(1);samples.append(1-draw[:,0]/draw[:,1])
        np.testing.assert_allclose(np.mean(list(groups.values())),independent['primary']['estimate'],rtol=1e-11)
        np.testing.assert_allclose(np.quantile(np.mean(samples,0),[.025,.975]),independent['primary']['ci'])
        original=read('runs/f3-new-study/query/confirmation/summary.json');arm=original['method'];phase=original['primary_control']
        e=original['recordings']['esot'];vals=np.array([[r[arm]['field_rms'],r[phase]['field_rms']] for r in e.values()])
        np.testing.assert_allclose(1-vals[:,0].mean()/vals[:,1].mean(),original['primary_field']['estimate'])
        current=read('runs/f3-precision-flow/summary.json');vals=[]
        for n in current['recordings']:
            ws=read(f'runs/f3-precision-flow/scores/{n}.json')['windows']
            pick=[w['rows']['5-tile4'] for w in ws];g=[r['motion'] for r in pick];N=sum(v['n'] for v in g)
            timings=ws[2]['times_ms']
            vals.append([sum(v['sum_epe']-v['sum_dense'] for v in g)/N,np.sqrt(np.mean([r['flow_mse'] for r in pick])),np.median(timings['5-tile4']),min(np.median(timings[k]) for k in ('dense','dense-matched'))])
        a=np.array(vals);pt=a.mean(0);np.testing.assert_allclose([pt[0],pt[1],1-pt[2]/pt[3]],[current['point'][k] for k in ('delta','flow','speed')])
        j=np.random.default_rng(731).integers(len(a),size=(20000,len(a)));np.testing.assert_allclose(np.quantile(a[j,0].mean(1),.95),current['percentiles_025_950_975']['delta'][1])
        final=read('runs/f3-final-panel/summary.json');m=final['candidate']
        for domain,result in final['domains'].items():
            cluster={};all_rows={}
            preview_modes = ('scale@5/2/0/0', 'scale@5/2/1/0', 'scale@5/2/0/1', 'scale@5/2/1/1')
            preview_by_group = {}
            for n in result['captures']:
                d=read(f'runs/f3-final-panel/scores/{domain}/{n}.json');ws=[w for w in d['windows'] if w];rows=[w['rows'][m] for w in ws]
                flow_rms = [
                    np.sqrt(np.mean([window['rows'][mode]['flow_mse'] for window in ws]))
                    for mode in preview_modes
                ]
                preview_by_group.setdefault(d['group'], []).append(flow_rms)
                gt=np.sum([r['gt'] for r in rows],axis=0);times=d['windows'][2]['ms']
                control=final['control'];modes=[m,control,'6-local','cubic@5/2/1/1']
                point=[]
                for k in modes:
                    rr=[w['rows'][k] for w in ws];ng,ep,de,zz=np.sum([v['gt'] for v in rr],0)
                    point.append([ep/ng,de/ng,zz/ng,np.sqrt(np.mean([v['flow_mse'] for v in rr])),np.sqrt(np.mean([v['field_mse'] for v in rr])),np.sqrt(np.mean([v['field_mse'] for v in rr])/np.mean([v['field_sig'] for v in rr])),np.median(times[k]),min(np.median(times[t]) for t in ('dense','dense-matched'))])
                all_rows.setdefault(d['group'],[]).append(point)
                cluster.setdefault(d['group'],[]).append([(gt[1]-gt[2])/gt[0] if gt[0] else np.nan,np.sqrt(np.mean([r['flow_mse'] for r in rows])),np.median(times[m]),min(np.median(times[k]) for k in ('dense','dense-matched'))])
            preview = np.mean([np.mean(values, axis=0) for values in preview_by_group.values()], axis=0)
            np.testing.assert_allclose(preview, [result['means'][mode]['flow'] for mode in preview_modes])
            print(f"{domain} flow RMS (ordinary, native first, projected, both): "
                  + ", ".join(f"{value:.3f}" for value in preview) + " px")
            b=np.array([np.mean(v,0) for v in cluster.values()]);pt=b.mean(0)
            obj=lambda x:np.nan if x is None else x
            np.testing.assert_allclose([pt[0],pt[1],1-pt[2]/pt[3]],[obj(result['point'][k]) for k in ('delta','flow','speed')],equal_nan=True)
            j=np.random.default_rng(731).integers(len(b),size=(20000,len(b)));np.testing.assert_allclose(np.quantile(b[j,0].mean(1),.95),obj(result['bounds']['delta'][1]),equal_nan=True)
            group_data=np.array([np.mean(v,0) for v in all_rows.values()])
            def contrast(arr):
                # Last axes are method and metric, first optional axis is bootstrap.
                c,p,l,b=np.moveaxis(arr,-2,0)
                return dict(delta=c[...,0]-c[...,1],dense_minus_zero=c[...,1]-c[...,2],speed=1-c[...,6]/c[...,7],
                    flow=c[...,3],field=c[...,5],phase_gain=1-c[...,3]/p[...,3],phase_field_gain=1-c[...,4]/p[...,4],
                    phase_epe_delta=c[...,0]-p[...,0],phase_speed=1-c[...,6]/p[...,6],crop_epe_gain=l[...,0]-c[...,0],
                    crop_epe_relative=1-c[...,0]/l[...,0],crop_time_ratio=c[...,6]/l[...,6],crop_fidelity_gain=1-c[...,3]/l[...,3])
            for k,v in contrast(group_data.mean(0)).items():np.testing.assert_allclose(v,result['point'][k],atol=2e-12)
            for k,v in contrast(group_data[j].mean(1)).items():np.testing.assert_allclose(np.quantile(v,[.025,.95,.975]),result['bounds'][k],atol=2e-12)
            np.testing.assert_allclose(group_data.mean(0)[3,[0,3,6]],[result['means']['cubic@5/2/1/1'][k] for k in ('epe','flow','ms')],atol=2e-12)
        print('Manifest and primary recording/scene estimates verified for all four studies.')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive',nargs='?',type=Path,default=Path(__file__).with_name('measurement-records.zip'));check(p.parse_args().archive)
