import torch
import torch.nn.functional as F
from query_f3.scale.kernel import projected_kernel

def run():
    torch.manual_seed(1108);torch.set_num_threads(1)
    for kx,ky,sx,sy in [(7,9,1,1),(7,7,2,2),(9,7,4,2),(5,9,2,3)]:
        w=torch.randn(3,1,kx,ky,dtype=torch.double);v=projected_kernel(w,sx,sy)
        assert v.shape==(3,1,2*((kx//2+sx-1)//sx)+1,2*((ky//2+sy-1)//sy)+1)
        torch.testing.assert_close(v.sum((2,3)),w.sum((2,3)),atol=1e-12,rtol=1e-12)
        x=torch.randn(1,3,13,17,dtype=torch.double)
        # Exact fine grid defined by linearly interpolating the coarse nodes.
        full=F.interpolate(x,size=(1+12*sx,1+16*sy),mode='bilinear',align_corners=True)
        ref=F.conv2d(full,w,padding=(kx//2,ky//2),groups=3)[:,:,::sx,::sy]
        approx=F.conv2d(x,v,padding=(v.shape[2]//2,v.shape[3]//2),groups=3)
        torch.testing.assert_close(ref[:,:,3:-3,3:-3],approx[:,:,3:-3,3:-3],atol=1e-11,rtol=1e-11)
    print('Bilinear pullback matches native depthwise responses, anisotropic stride and kernels, constant response preserved')
if __name__=='__main__':run()
