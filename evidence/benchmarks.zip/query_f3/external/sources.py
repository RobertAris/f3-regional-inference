"""Retrieve the pinned EVIMO flow generator used for the Samsung packet adapter."""
from pathlib import Path
import requests
from query_f3.binding import ROOT, digest
BASE=ROOT/'datasets/query-f3-evimo'
CODE='8897c6d9aa18384f9746b89b565d09cc7d8a059f'
FLOW_SHA='f734e306dc19751ab22d2b1170be845278cd8a3210956bbc3bf8e4c23de76b45'
def source():
    vendor=BASE/'vendor';vendor.mkdir(exist_ok=True,parents=True);p=vendor/'evimo_flow.py'
    if not p.exists():
        r=requests.get(f'https://raw.githubusercontent.com/better-flow/evimo/{CODE}/tools/evimo_flow.py',timeout=30);r.raise_for_status();p.write_bytes(r.content)
    if digest(p)!=FLOW_SHA:raise ValueError('publisher generator changed')
